import React, { useState, useEffect, Suspense } from 'react'

// ** Router Import
import Router from './router/Router'

// ** Routes & Default Routes
import { getRoutes } from './router/routes'

// ** Hooks Imports
import { useLayout } from '@hooks/useLayout'
import CustomizationWrap from './views/Components/SuperLeadz/CustomizationWrap'
import PermissionWrapper from './configs/PermissionWrapper'
import '@styles/react/libs/flatpickr/flatpickr.scss'

const App = () => {
  const [allRoutes, setAllRoutes] = useState([])

  // ** Hooks
  const { layout } = useLayout()


  useEffect(() => {
    setAllRoutes(getRoutes(layout))
  }, [layout])


  return (
    <CustomizationWrap>
      <PermissionWrapper>
        <Suspense fallback={null}>
          <Router allRoutes={allRoutes} />
        </Suspense>
      </PermissionWrapper>
    </CustomizationWrap>
  )
}

export default App
