import React from 'react'
import { Info } from 'react-feather'
import { Card, CardBody } from 'reactstrap'

const CardCom = ({ icon, title, data, info}) => {
    return (
        <Card>
            <CardBody>
                <div className='icon'>
                    {icon ? icon : ""}
                </div>
                <div className="d-flex mt-2 justify-content-between align-items-end">
                    <h4 style={{ borderBottom: '0px dotted lightgray', whiteSpace: 'nowrap', paddingRight: '10px'}} title={info} className='mt- position-relative cursor-default'>
                        {title ? title : ""} </h4>
                    <h4 title={data} className='m-0' style={{ fontSize: '3rem', cursor:"default", overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'}}>
                        {data ? data : "0"}
                    </h4>
                </div>
                
            </CardBody>
        </Card>
    )
}

export default CardCom