import React, { useState } from 'react'
import Wrapper from './Wrapper'
import { Activity } from 'react-feather'

// import Wrapper from './Wrapper'
// import { SuperLeadzBaseURL } from '../../../../assets/auth/jwtService'
// import axios from 'axios'
// import { useParams } from 'react-router-dom'

const Rules = () => {
    // const { id } = useParams()
    // useEffect(() => {
    //     const url = new URL(`${SuperLeadzBaseURL}/api/v1/pop_up_analytics/?shop=maapro.myshopify.com&app=superleadz&theme_id=${id}`)

    //     axios({
    //         method: "GET",
    //         url
    //     })
    //         .then((response) => {
    //             const theme = response.data.theme_json
    //             const custom_theme = JSON.parse(theme[0].custom_theme)
    //             setTitle(custom_theme.pages)

    //         })
    //         .catch((err) => {
    //             console.log(err)
    //         })
    // }, [])

    const [SelectedDate, setSelectedDate] = useState('option1')
    const [SelectedDay, setSelectedDay] = useState('option1')
    const [spend, setSpend] = useState('20')
    const [second, setSeconds] = useState('option1')

    console.log(spend, second, setSpend)

    const handleDateChange = (event) => {
        setSelectedDate(event.target.value)
    }

    const handleDayChange = (event) => {
        setSelectedDay(event.target.value)
    }

    const handleSecondChange = (event) => {
        setSeconds(event.target.value)
    }

    return (
        <>
            <Wrapper />
            <div className=' mt-2 '>
                <div>
                    <div className='d-flex'>
                        <div>

                            <Activity size={25} color='red' />
                        </div>
                        <div className=' ms-3'>
                            <h5>Display frequency</h5>
                            <div>
                                <input type='radio' id="#" name="#" value="#" />
                                <label>Do not limit</label>
                            </div>
                            <div>
                                <input type='radio' id="#" name="#" value="#" />
                                <label>Do not limit</label>
                            </div>
                            <div>
                                <input type='radio' id="#" name="#" value="#" />
                                <label>Do not limit</label>
                            </div>
                            <div className='d-flex'>
                                <div>
                                    <input type='radio' id="#" name="#" value="#" />
                                    <label>Do not limit</label>
                                </div>
                                <div>
                                    <select id="mySelect" style={{ borderRadius: "25px", width: "3vw" }} value={setSelectedDate} onChange={handleDateChange}>
                                        <option value="option1">1</option>
                                        <option value="option2">2</option>
                                        <option value="option3">3</option>
                                    </select>
                                </div>
                                <div>
                                    <select id="mySelect" style={{ borderRadius: "25px", width: "4vw" }} value={handleDayChange} onChange={handleDayChange}>
                                        <option value="option1">Days</option>
                                        <option value="option2">Months</option>
                                        <option value="option3">Year</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr />
                <div>
                    <div className='d-flex'>
                        <div>

                            <Activity size={25} color='red' />
                        </div>
                        <div className=' ms-3'>
                            <h5>When to display</h5>
                            <div>
                                <input type='radio' id="#" name="#" value="#" />
                                <label>Immediately</label>
                            </div>
                            <div>
                                <input type='radio' id="#" name="#" value="#" />
                                <label>When All Conditions are met</label>
                            </div>
                            <div>
                                <input type='radio' id="#" name="#" value="#" />
                                <label>When any Condition is met</label>
                            </div>
                            <div className='d-flex'>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                    <label class="form-check-label" for="flexSwitchCheckDefault">Spend on the page</label>
                                </div>
                                <div>
                                    <select id="mySelect" style={{ borderRadius: "25px", width: "3vw" }} value={setSelectedDate} onChange={handleDateChange}>
                                        {/* <option value="option1">1</option>
                                        <option value="option2">2</option>
                                        <option value="option3">3</option> */}
                                    </select>
                                </div>
                                <div>
                                    <select id="mySelect" style={{ borderRadius: "25px", width: "5vw" }} value={handleSecondChange} onChange={handleSecondChange}>
                                        <option value="option1">Seconds</option>
                                        <option value="option2">Minuts</option>
                                    </select>
                                </div>
                            </div>
                            <div className='d-flex'>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                    <label class="form-check-label" for="flexSwitchCheckDefault">Spend on the Website</label>
                                </div>
                                <div>
                                    <select id="mySelect" style={{ borderRadius: "25px", width: "3vw" }} value={setSelectedDate} onChange={handleDateChange}>
                                        {/* <option value="option1">1</option>
                                        <option value="option2">2</option>
                                        <option value="option3">3</option> */}
                                    </select>
                                </div>
                                <div>
                                    <select id="mySelect" style={{ borderRadius: "25px", width: "5vw" }} value={handleSecondChange} onChange={handleSecondChange}>
                                        <option value="option1">Seconds</option>
                                        <option value="option2">Minuts</option>
                                    </select>
                                </div>
                            </div>
                            <div className='d-flex'>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                    <label class="form-check-label" for="flexSwitchCheckDefault">Read the page by</label>
                                </div>
                                <div>
                                    <select id="mySelect" style={{ borderRadius: "25px", width: "3vw" }} value={setSelectedDate} onChange={handleDateChange}>
                                        {/* <option value="option1">1</option>
                                        <option value="option2">2</option>
                                        <option value="option3">3</option> */}
                                    </select>
                                </div> <p>%</p>
                            </div>
                            <div className='d-flex'>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                    <label class="form-check-label" for="flexSwitchCheckDefault">Visited</label>
                                </div>
                                <div>
                                    <select id="mySelect" style={{ borderRadius: "25px", width: "3vw" }} value={setSelectedDate} onChange={handleDateChange}>
                                        {/* <option value="option1">1</option>
                                        <option value="option2">2</option>
                                        <option value="option3">3</option> */}
                                    </select>
                                </div> <p>Pages</p>
                            </div>
                            <div className='d-flex'>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                    <label class="form-check-label" for="flexSwitchCheckDefault">Not active on the page</label>
                                </div>
                                <div>
                                    <select id="mySelect" style={{ borderRadius: "25px", width: "3vw" }} value={setSelectedDate} onChange={handleDateChange}>
                                        {/* <option value="option1">1</option>
                                        <option value="option2">2</option>
                                        <option value="option3">3</option> */}
                                    </select>
                                </div>
                                <div>
                                    <select id="mySelect" style={{ borderRadius: "25px", width: "5vw" }} value={handleSecondChange} onChange={handleSecondChange}>
                                        <option value="option1">Seconds</option>
                                        <option value="option2">Minuts</option>
                                    </select>
                                </div>
                            </div>
                            <div className='d-flex'>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                    <label class="form-check-label" for="flexSwitchCheckDefault">Exit Intent</label>
                                </div>
                            </div>
                            <h5 className='mt-2'>When to Stop displaying</h5>
                            <div className='d-flex'>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                    <label class="form-check-label" for="flexSwitchCheckDefault">After</label>
                                </div>
                                <div>
                                    <select id="mySelect" style={{ borderRadius: "25px", width: "3vw" }} value={setSelectedDate} onChange={handleDateChange}>
                                        {/* <option value="option1">1</option>
                                        <option value="option2">2</option>
                                        <option value="option3">3</option> */}
                                    </select>
                                </div> <p>Seconds, in case of no interaction with the widget</p>
                            </div>
                            <div className="form-check form-switch">
                                <input className="d-none form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                <p>The condition canceled when a user hovers the widget</p>
                            </div>
                            <div className='d-flex'>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                    <label class="form-check-label" for="flexSwitchCheckDefault">After closing</label>
                                </div>
                                <div>
                                    <select id="mySelect" style={{ borderRadius: "25px", width: "3vw" }} value={setSelectedDate} onChange={handleDateChange}>
                                        {/* <option value="option1">1</option>
                                        <option value="option2">2</option>
                                        <option value="option3">3</option> */}
                                    </select>
                                </div> <p>times</p>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault" />
                                <label class="form-check-label" for="flexSwitchCheckDefault">After subcription</label>
                            </div>
                            <div>
                                <input type='radio' id="#" name="#" value="#" />
                                <label>From any widget</label>
                            </div>
                            <div>
                                <input type='radio' id="#" name="#" value="#" />
                                <label>From this widget</label>
                            </div>
                        </div>
                    </div>
                </div>
                <hr />
                <div>
                    <div className='d-flex'>
                        <div>

                            <Activity size={25} color='red' />
                        </div>
                        <div className=' ms-3'>
                            <h5>Annoyance Safeguard</h5>
                            <div>
                                <p>What to do with this widget if:</p>
                            </div>
                            <div className='ms-2'>
                                <p>-Another widget has to be displayed together with this one</p>
                                <p>-Another widget is displayed on the screen</p>
                                <p>-Another widget has been displayed recently</p>
                            </div>
                            <div>
                                <p style={{ color: 'red' }}>How it works</p>
                            </div>
                            <div>
                                <div>
                                    <input type='radio' id="#" name="#" value="#" />
                                    <label>Show</label>
                                </div>
                                <div>
                                    <input type='radio' id="#" name="#" value="#" />
                                    <label>Show in sequence using Slient Interval</label>
                                </div>
                                <div>
                                    <input type='radio' id="#" name="#" value="#" />
                                    <label>Don't show during the current session</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Rules