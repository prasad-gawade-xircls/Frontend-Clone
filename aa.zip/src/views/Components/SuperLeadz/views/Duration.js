import React from 'react'
import Wrapper from './Wrapper'

const Duration = () => {
    return (
        <>
            <Wrapper />
        </>
    )
}

export default Duration