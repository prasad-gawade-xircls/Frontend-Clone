import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Card, CardBody, Col, Row } from 'reactstrap'
import { SuperLeadzBaseURL } from '../../../assets/auth/jwtService'
import Spinner from '../DataTable/Spinner'

const CampaignWiseData = ({campaignData}) => {

    const [isLoading, setIsLoading] = useState(true)
    const [data, setData] = useState({
        impression: "",
        conversion: "",
        conversion_rate: "",
        engaged: "",
        ctr: "",
        revenue: "",
        immediatelyClosed: "",
        leads: "",
        offer_sent: "",
        redirected: ""
    })

    console.log(data)

    const getData = () => {
        // const form_data = new FormData()
        // form_data.append('theme_id', campaignData.id)
        axios.get(`${SuperLeadzBaseURL}/api/v1/pop_up_analytics/?theme_id=${campaignData.id}`)
        .then((resp) => {
            console.log(resp)
            const updatedData = {
                impression: resp?.data?.data?.pop_up_view,
                conversion: resp?.data?.data?.conversion,
                conversion_rate: resp?.data?.data?.conversion_rate,
                engaged: resp?.data?.data?.clicks,
                ctr: (resp?.data?.data?.clicks && resp?.data?.data?.pop_up_view) ? Number(resp?.data?.data?.clicks / resp?.data?.data?.pop_up_view * 100).toFixed(2) : 0,
                revenue: resp?.data?.data?.Revenue,
                immediatelyClosed: resp?.data?.data?.pop_up_closed,
                leads: resp?.data?.data?.total_leads,
                offer_sent: resp?.data?.data?.offer_sent,
                redirected: resp?.data?.data?.offer_clicked
            }
            setData((preData) => ({
                ...preData,
                ...updatedData
            }))
            setIsLoading(false)
        })
        .catch((error) => {
            console.log(error)
            setIsLoading(false)
        })
    }

    useEffect(() => {
        getData()
    }, [])

    const RenderData = ({title, data}) => {
        return <>
            <Card>
                <CardBody>
                    <div className="d-flex justify-content-between align-items-center">
                        <h4 style={{ borderBottom: '0px dotted lightgray', fontSize: '18px', whiteSpace: 'nowrap', paddingRight: '10px' }} className='m-0 position-relative cursor-default'>
                            {title}
                        </h4>
                        <h4 className='m-0' title={data} style={{ fontSize: '2rem', cursor:"default", overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'}}>
                            {data}
                        </h4>
                    </div>
                </CardBody>
            </Card>
        </>
    }

    return (
        <>
            <Card>
                <CardBody>
                    {
                        isLoading ? <div className='d-flex justify-content-center align-items-center'><Spinner size={'30px'}/></div> : (
                            <>
                                <Row>
                                    <Col md="3">
                                        <RenderData title="Impressions" data={data?.impression} />
                                    </Col>
                                    <Col md="3">
                                        <RenderData title="Conversions" data={data?.conversion} />
                                    </Col>
                                    <Col md="3">
                                        <RenderData title="Conversion rate" data={`${data?.conversion_rate}%`} />
                                    </Col>
                                    <Col md="3">
                                        <RenderData title="Engaged" data={data?.engaged} />
                                    </Col>
                                    <Col md="3">
                                        <RenderData title="CTR" data={`${data?.ctr}%`} />
                                    </Col>
                                    <Col md="3">
                                        <RenderData title="Revenue" data={data?.revenue} />
                                    </Col>
                                    <Col md="3">
                                        <RenderData title="Immediately closed" data={data?.immediatelyClosed} />
                                    </Col>
                                    <Col md="3">
                                        <RenderData title="Leads" data={data?.leads} />
                                    </Col>
                                    <Col md="3">
                                        <RenderData title="Offers sent" data={data?.offer_sent} />
                                    </Col>
                                    <Col md="3">
                                        <RenderData title="Redirected" data={data?.redirected} />
                                    </Col>
                                </Row>
                            </>
                        )
                    }
                </CardBody>
            </Card>
        </>
    )
}

export default CampaignWiseData