import React from 'react'
import { ChevronRight } from 'react-feather'
import { useNavigate } from 'react-router-dom'

const Breadcrumb = () => {

    const stage = window.location.href.includes("TheAudience") ? 1 : window.location.href.includes("Editbutton") ? 2 : window.location.href.includes("Thebutton") ? 3 : window.location.href.includes("discount") ? 4 : ""
    // console.log("stage", stage)

    const navigate = useNavigate()
    return (
        <div className='d-flex align-items-center gap-3'>
            <div className="heading">
                <h2 className='m-0' style={{color: "black"}}> <b>4 SUPER SIMPLE STEPS! </b> </h2>
            </div>
            <nav className='bread_cumb_nav' aria-label="breadcrumb">
                <ol className="d-flex gap-2 align-items-center m-0 p-0" style={{listStyle: "none"}}>
                    <li className={`breadcrumb-nav ${stage === 1 ? "breadcrumb-active" : ""}`} onClick={() => navigate("/merchant/SuperLeadz/TheAudience/")} style={{cursor: "pointer"}}>The Audience</li>
                    <li><ChevronRight color={stage >= 1 ?  "#000" : "#5e5873"} size={15} /></li>
                    <li className={`breadcrumb-nav ${stage === 2 ? "breadcrumb-active" : ""}`}><a onClick={() => navigate("/merchant/SuperLeadz/Editbutton/")} style={{cursor: "pointer"}}>The Pop-up</a></li>
                    <li><ChevronRight color={stage >= 2 ?  "#000" : "#5e5873"} size={15} /></li>
                    <li className={`breadcrumb-nav ${stage === 3 ? "breadcrumb-active" : ""}`}><a onClick={() => navigate("/merchant/SuperLeadz/Thebutton/")} style={{cursor: "pointer"}}>The Button</a></li>
                    <li><ChevronRight color={stage >= 3 ?  "#000" : "#5e5873"} size={15} /></li>
                    <li className={`breadcrumb-nav ${stage === 4 ? "breadcrumb-active" : ""}`} onClick={() => navigate("/merchant/SuperLeadz/discount/")} style={{cursor: "pointer"}}>The Discount</li>
                </ol>
            </nav>

            
        </div>
    )
}

export default Breadcrumb