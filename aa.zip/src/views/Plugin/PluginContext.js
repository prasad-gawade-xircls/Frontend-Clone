import { createContext } from "react"

export const PluginHeader = createContext({})