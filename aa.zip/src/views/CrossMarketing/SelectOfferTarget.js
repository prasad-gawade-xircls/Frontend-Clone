import React from 'react'
import { Card, CardBody, Row } from 'reactstrap'

const SelectOfferTarget = () => {
  return (
    <>
      <Row>
        <Card>
            <CardBody>
                <h4>Select Offer for targeting</h4>
            </CardBody>
        </Card>
        

      </Row>
    </>
  )
}

export default SelectOfferTarget