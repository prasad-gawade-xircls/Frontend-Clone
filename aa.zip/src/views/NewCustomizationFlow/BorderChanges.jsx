import React, { useEffect, useState } from 'react'
import { Link2 } from 'react-feather'
import Select from 'react-select'
import { Modal } from 'reactstrap'
import CustomColorModifier from '../FormBuilder/FormBuilder(components)/CustomColorModifier'

const splitColor = (color, type) => {
    if (color.includes("rgb")) {
        return color.slice(type === "color" ? color.indexOf("rgb") : 0, type === "color" ? color.length : color.indexOf("rgb"))
    } else if (color.includes("hsl")) {
        return color.slice(type === "color" ? color.indexOf("hsl") : 0, type === "color" ? color.length : color.indexOf("hsl"))
    } else {
        return color.slice(type === "color" ? color.indexOf("#") : 0, type === "color" ? color.length : color.indexOf("#"))
    }
}

const getLinked = (obj) => {
    // let isLink = false
    try {
        return (parseFloat(obj?.borderTopLeftRadius) === parseFloat(obj?.borderTopRightRadius)) && (parseFloat(obj?.borderTopRightRadius) === parseFloat(obj?.borderBottomRightRadius)) && (parseFloat(obj?.borderBottomRightRadius) === parseFloat(obj?.borderBottomLeftRadius)) && (parseFloat(obj?.borderBottomLeftRadius) === parseFloat(obj?.borderTopLeftRadius))
    } catch (_) {
        return false
    }
}

const BorderChange = ({ styles, setStyles }) => {
    const [linked, setLinked] = useState(getLinked(styles))
    const [customColorModal, setCustomColorModal] = useState(false)
    const initialSize = splitColor((styles?.boxShadow && styles?.boxShadow !== "none") ? styles?.boxShadow : "0px 0px 0px 0px rgba(0,0,0,1)", "size")
    const [shadowSize, setShadowSize] = useState(initialSize?.includes("inset") ? initialSize?.split("inset")[1] : initialSize)
    const [shadowColor, setShadowColor] = useState({ color: splitColor((styles?.boxShadow && styles?.boxShadow !== "none") ? styles?.boxShadow : "0px 0px 0px 0px rgba(0,0,0,1)", "color"), borderColor: styles?.borderColor || "#000000" })
    const [colorType, setColorType] = useState("")
    const [shInset, setShInset] = useState(styles?.boxShadow?.includes("inset"))
    // console.log("BorderChange", styles)

    const borderTypes = [
        { value: 'none', label: 'None' },
        { value: 'full', label: 'Full' },
        { value: 'top', label: 'Top' },
        { value: 'right', label: 'Right' },
        { value: 'bottom', label: 'Bottom' },
        { value: 'left', label: 'Left' },
        { value: 'topbottom', label: 'Top Bottom' },
        { value: 'leftright', label: 'Left Right' }
    ]

    const borderStyles = [
        { value: 'solid', label: 'Solid' },
        { value: 'dashed', label: 'Dashed' },
        { value: 'dotted', label: 'Dotted' }
    ]

    const boxShadowOptions = [
        { value: '0px 0px 0px 0px', label: 'None' },
        { value: '0px 0px 10px 2.5px', label: 'Normal' },
        { value: '0px 0px 20px 5px', label: 'Medium' },
        { value: '0px 0px 30px 7.5px', label: 'Large' }
    ]

    // const [borderWidth, setBorderWidth] = useState(styles?.borderWidth)
    // const [borderColor, setBorderColor] = useState(styles?.borderColor)
    // const [borderStyle, setBorderStyle] = useState(styles?.borderStyle)

    // const [borderObj, setBorderObj] = useState({})
    const [lastValue, setLastValue] = useState(styles?.borderTopLeftRadius || "0px")

    // console.log(styles)

    const handleInputChange = (event) => {
        // if (numberRegex.test(parseFloat(event.target.value)) || parseFloat(event.target.value) === "") {
        setLastValue(`${parseFloat(event.target.value)}px`)
        if (linked) {
            setStyles({ ...styles, borderTopLeftRadius: `${parseFloat(event.target.value)}px`, borderTopRightRadius: `${parseFloat(event.target.value)}px`, borderBottomRightRadius: `${parseFloat(event.target.value)}px`, borderBottomLeftRadius: `${parseFloat(event.target.value)}px` })
        } else {
            setStyles({ ...styles, [event.target.name]: `${parseFloat(event.target.value)}px` })
        }
        // }
    }

    useEffect(() => {
        if (linked) {
            setStyles({ ...styles, borderTopLeftRadius: lastValue, borderTopRightRadius: lastValue, borderBottomRightRadius: lastValue, borderBottomLeftRadius: lastValue })
        }
    }, [linked])
    useEffect(() => {
        let borderWidth = styles?.defBorderWidth
        if (styles?.borderType === "none") {
            borderWidth = "0px"
        } else if (styles?.borderType === "full") {
            borderWidth = `${styles?.defBorderWidth} ${styles?.defBorderWidth} ${styles?.defBorderWidth} ${styles?.defBorderWidth}`
        } else if (styles?.borderType === "top") {
            borderWidth = `${styles?.defBorderWidth} 0px 0px 0px`
        } else if (styles?.borderType === "right") {
            borderWidth = `0px ${styles?.defBorderWidth} 0px 0px`
        } else if (styles?.borderType === "bottom") {
            borderWidth = `0px 0px ${styles?.defBorderWidth} 0px`
        } else if (styles?.borderType === "left") {
            borderWidth = `0px 0px 0px ${styles?.defBorderWidth}`
        } else if (styles?.borderType === "topbottom") {
            borderWidth = `${styles?.defBorderWidth} 0px ${styles?.defBorderWidth} 0px`
        } else if (styles?.borderType === "leftright") {
            borderWidth = `0px ${styles?.defBorderWidth}  0px ${styles?.defBorderWidth}`
        }
        setStyles({ ...styles, borderWidth })
    }, [styles?.defBorderWidth])

    useEffect(() => {
        setStyles({...styles, boxShadow: `${shInset ? "inset" : ""} ${shadowSize} ${shadowColor.color}`, borderColor: shadowColor.borderColor})
    }, [shadowSize, shadowColor.color, shadowColor.borderColor, shInset])

    return (
        <div>
            <div className='p-0 mx-0 my-1'>
                <div className='p-0 mb-2 justify-content-start align-items-center'>
                    <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Border:</span>
                    <Select value={borderTypes[borderTypes.findIndex($ => $.value === styles?.borderType)]} onChange={e => {
                        const newDefBorderWidth = styles?.defBorderWidth === "0px" ? "10px" : styles?.defBorderWidth
                        let borderWidth
                        if (e.value === "none") {
                            borderWidth = "0px"
                        } else if (e.value === "full") {
                            borderWidth = `${newDefBorderWidth} ${newDefBorderWidth} ${newDefBorderWidth} ${newDefBorderWidth}`
                        } else if (e.value === "top") {
                            borderWidth = `${newDefBorderWidth} 0px 0px 0px`
                        } else if (e.value === "right") {
                            borderWidth = `0px ${newDefBorderWidth} 0px 0px`
                        } else if (e.value === "bottom") {
                            borderWidth = `0px 0px ${newDefBorderWidth} 0px`
                        } else if (e.value === "left") {
                            borderWidth = `0px 0px 0px ${newDefBorderWidth}`
                        } else if (e.value === "topbottom") {
                            borderWidth = `${newDefBorderWidth} 0px ${newDefBorderWidth} 0px`
                        } else if (e.value === "leftright") {
                            borderWidth = ` 0px ${newDefBorderWidth} 0px ${newDefBorderWidth}`
                        }
                        setStyles({ ...styles, borderType: e.value, borderWidth, defBorderWidth: newDefBorderWidth })
                    }} options={borderTypes} />
                </div>
                {styles?.borderType !== "none" && <div className='p-0 mb-2 justify-content-start align-items-center'>
                    <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Border Style:</span>
                    <Select value={borderStyles[borderStyles?.findIndex($ => $.value === styles?.borderStyle)]} onChange={e => {
                        setStyles({ ...styles, borderStyle: e.value })
                    }} options={borderStyles} />
                </div>}
                {styles?.borderType !== "none" && <div className='p-0 mb-2 justify-content-start align-items-center'>
                    <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Border Color:</span>
                    <div className="p-1 w-100 border cursor-pointer rounded" style={{ backgroundColor: shadowColor?.borderColor }} onClick={() => {
                        setColorType("borderColor")
                        setCustomColorModal(!customColorModal)
                        }}></div>
                </div>}
                {styles?.borderType !== "none" && <div className='mb-2'>
                    <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Border Width: {styles?.defBorderWidth}</span>
                    <div className="p-0 justify-content-start align-items-center gap-2">
                        <input type='range' value={parseFloat(styles?.defBorderWidth)} className='w-100' onChange={e => {
                            setStyles({ ...styles, defBorderWidth: `${e.target.value}px` })
                        }} name="height" min="0" max="40" />
                    </div>
                </div>}
                <div className='d-flex flex-column text-start mb-2'>
                    <span className='fw-bolder text-black' style={{ fontSize: "0.75rem", marginBottom: '0.25rem' }}>Corner radius:</span>
                    <div className='match-height m-auto' style={{ aspectRatio: '1', gridTemplateColumns: '1fr 1fr 1fr', display: 'grid', width: '100%' }}>
                        <div style={{ aspectRatio: "1" }} className="p-0 m-0 d-flex justify-content-center align-items-center">
                            <input onChange={handleInputChange} value={parseFloat(styles?.borderTopLeftRadius)} name='borderTopLeftRadius' type="number" min="0" step="1" placeholder="0" className="form-control w-100" />
                        </div>
                        <div style={{ aspectRatio: "1" }}></div>
                        <div style={{ aspectRatio: "1" }} className="flex-grow-1 d-flex justify-content-center align-items-center">
                            <input onChange={handleInputChange} value={parseFloat(styles?.borderTopRightRadius)} name='borderTopRightRadius' type="number" min="0" step="1" placeholder="0" className="form-control" />
                        </div>
                        <div style={{ aspectRatio: "1" }}></div>
                        <div onClick={() => setLinked(!linked)} className="d-flex justify-content-center align-items-center">
                            <Link2 size={18} strokeWidth={2.5} style={{ transform: 'rotate(-45deg)', color: linked ? '#7367f0' : '' }} />
                        </div>
                        <div style={{ aspectRatio: "1" }}></div>
                        <div style={{ aspectRatio: "1" }} className="flex-grow-1 d-flex justify-content-center align-items-center">
                            <input onChange={handleInputChange} value={parseFloat(styles?.borderBottomLeftRadius)} name='borderBottomLeftRadius' type="number" min="0" step="1" placeholder="0" className="form-control" />
                        </div>
                        <div style={{ aspectRatio: "1" }}></div>
                        <div style={{ aspectRatio: "1" }} className="flex-grow-1 d-flex justify-content-center align-items-center">
                            <input onChange={handleInputChange} value={parseFloat(styles?.borderBottomRightRadius)} name='borderBottomRightRadius' type="number" min="0" step="1" placeholder="0" className="form-control" />
                        </div>
                    </div>
                </div>
                <div className='p-0 mb-2 justify-content-start align-items-center'>
                    <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Shadow:</span>
                    <Select value={styles?.boxShadow === "none" ? boxShadowOptions[boxShadowOptions?.findIndex($ => $.value === "0px 0px 0px 0px")] : boxShadowOptions[boxShadowOptions.findIndex($ => $.value === shadowSize)]} onChange={e => {
                        setShadowSize(e.value)
                    }} options={boxShadowOptions} />
                </div>
                <div className='p-0 mb-2 justify-content-start align-items-center'>
                    <span className='fw-bolder text-black mb-1' style={{ fontSize: "0.75rem" }}>Shadow Color:</span>
                    <div className="p-1 w-100 border cursor-pointer rounded" style={{ backgroundColor: shadowColor.color }} onClick={() => {
                        setColorType("color")
                        setCustomColorModal(!customColorModal)
                        }}></div>
                </div>
                <div className="form-check form-check-success mb-2 mx-0 p-0 d-flex align-items-center justify-content-between">
                    <label className='fw-bolder text-black form-check-label m-0 p-0' style={{ fontSize: "0.75rem" }}>Shadow Inset</label><input checked={shInset} onChange={(e) => {
                        setShInset(e.target.checked)
                    }} type="checkbox" className="form-check-input m-0" /></div>
            </div>
            <Modal onClick={() => setCustomColorModal(!customColorModal)} toggle={() => setCustomColorModal(!customColorModal)} className='hide-backdrop' isOpen={customColorModal} style={{ width: "300px", maxWidth: "90%", margin: "0px" }}>
                <CustomColorModifier styles={shadowColor} setStyles={setShadowColor} colorType={colorType} />
            </Modal>
        </div>
    )
}

export default BorderChange

// borderTopLeftRadius: "0px", borderTopRightRadius: "0px", borderBottomRightRadius: "0px", borderBottomLeftRadius