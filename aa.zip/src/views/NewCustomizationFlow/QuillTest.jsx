import React, { useEffect } from 'react'
import SunEditor from 'suneditor-react'

const QuillTest = () => {

    const SunEditorConfigBlock = {
        toolbarContainer: '#toolbar_container',
        mode: 'balloon-always',
        showPathLabel: false,
        charCounter: false,
        charCounterLabel: null,
        maxCharCount: null,
        fullPage: false,
        resizingBar: false,

        width: '5px',
        // minWidth: '10px',
        height: 'auto',
        // minHeight: '0px',
        maxHeight: 'auto',
        buttonList: [
            ['formatBlock', 'bold', 'underline', 'italic', 'strike', 'subscript', 'superscript', 'removeFormat'],
            ['fontColor', 'hiliteColor', 'outdent', 'indent', 'align', 'horizontalRule', 'list', 'lineHeight'],
            ['table', 'link', 'image', 'video', 'fullScreen', 'showBlocks', 'codeView', 'preview', 'print', 'save']
        ]
    }

    useEffect(() => {
        const selection = window.getSelection()

        console.log({selection})
    }, [])

    return (
        <div style={{height: "100vh"}}>
        <SunEditor
        setOptions={SunEditorConfigBlock}
        onChange={(content) => {
            console.log({content})
        }}
    />
<span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel nostrum omnis quisquam? Cumque deserunt soluta dolorum sapiente, quibusdam enim quas quasi placeat porro ratione ipsam.</span>
        </div>
    )
}

export default QuillTest