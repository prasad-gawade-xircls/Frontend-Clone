import React, { useContext, useEffect, useState } from 'react'
import { Crosshair, Edit, Image, Lock, Monitor, PlusCircle, Smartphone, Square, Tag, Target, Type, X, Trash2, Download, Star, Bold, Italic, Underline, Layout, XCircle, Columns, Disc, ChevronDown, Trash, ChevronUp, Copy, Percent, RotateCw, RotateCcw, MoreVertical, ArrowLeft, Home, MoreHorizontal, Edit2 } from 'react-feather'
import { AccordionBody, AccordionHeader, AccordionItem, Card, Container, Dropdown, DropdownItem, DropdownMenu, DropdownToggle, Modal, ModalBody, Row, UncontrolledAccordion, UncontrolledDropdown, Col } from 'reactstrap'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import pixels from "../../assets/images/superLeadz/pixels.png"
import PickerDefault from '../Components/Date-picker/NormalDatePicker'
import Select from 'react-select'
import BgModifier from '../FormBuilder/FormBuilder(components)/BgModifier'
import ModificationSection from '../FormBuilder/FormBuilder(components)/ModificationSection'
import axios from 'axios'
import InputChange from './InputChange'
import BorderChange from './BorderChanges'
import { elementStyles, commonObj, defaultObj } from './defaultStyles'
import chevronDown from "../../assets/images/superLeadz/chevron-down.svg"
import toast from 'react-hot-toast'
import CustomColorModifier from '../FormBuilder/FormBuilder(components)/CustomColorModifier'
// import theme3 from "../SuperLeadz/Customization/theme3.png"
// import theme4 from "../SuperLeadz/Customization/theme4.png"
import countries from '../NewFrontBase/Country'
import SunEditor from "suneditor-react"
import "suneditor/dist/css/suneditor.min.css"
import isEqual from "lodash.isequal"
import UndoRedo from '../../data/hooks/UndoRedo'
import { ThemesProvider } from '../../Helper/Context'
import { SuperLeadzBaseURL } from '../../assets/auth/jwtService'
import Spinner from '../Components/DataTable/Spinner'
import { getCurrentOutlet, xircls_url } from '../Validator'
import { Pagination, Navigation, Autoplay } from 'swiper'
import { Swiper, SwiperSlide } from 'swiper/react/swiper-react.js'
import 'swiper/swiper.min.css'
import 'swiper/modules/pagination/pagination.min.css'
import 'swiper/modules/navigation/navigation.min.css'
import 'swiper/modules/autoplay/autoplay.min.css'
import moment from 'moment/moment'
import ColabReg from "../../@core/assets/fonts/Colaborate/ColabReg.otf"
import ReturnOfferHtml, { defaultOfferStyles } from './ReturnOfferHtml'
import Editor from './Editor'

const CustomizationParent = () => {

    const themeLoc = useLocation()

    // const dateFormat = "%Y-%m-%d %H:%M:%S"

    const fontStyles = [
        { label: "Montserrat", value: `Montserrat` },
        { label: "Open Sans", value: `Open Sans` },
        { label: "Oswald", value: `Oswald` },
        { label: "Abril Fatface", value: `Abril Fatface` },
        { label: "Lato", value: `Lato` }
    ]

    const [isMobile, setIsMobile] = useState(false)

    const mobileCondition = isMobile ? "mobile_" : ""
    const mobileConditionRev = !isMobile ? "mobile_" : ""

    const { allThemes, selectedThemeId } = useContext(ThemesProvider)

    const allPreviews = [...allThemes]

    const navigate = useNavigate()
    const [mousePos, setMousePos] = useState({})
    const [finalObj, setFinalObj] = useState(themeLoc?.state?.custom_theme ? JSON.parse(themeLoc?.state?.custom_theme) : selectedThemeId !== "" ? { ...allPreviews[allPreviews?.findIndex($ => $?.theme_id === selectedThemeId)]?.object, campaignStartDate: moment(new Date()).format("YYYY-MM-DD HH:mm:ss") } : defaultObj)

    // const refObj = themeLoc?.state?.custom_theme ? JSON.parse(themeLoc?.state?.custom_theme) : selectedThemeId !== "" ? { ...allPreviews[allPreviews?.findIndex($ => $?.theme_id === selectedThemeId)]?.object } : defaultObj

    const [defColors, setDefColors] = useState(finalObj.defaultThemeColors || {})

    const [currColor, setCurrColor] = useState("primary")

    const [currPage, setCurrPage] = useState(finalObj?.[`${mobileCondition}pages`][0].id)

    // const [draftId, setDraftId] = useState("")

    // const [initial, setInitial] = useState(currPage === "button" ? finalObj.button : finalObj[`${mobileCondition}pages`][finalObj[`${mobileCondition}pages`].findIndex($ => $?.id === currPage)].values)

    // const { state: colWise, setState: setcolWise, index: docStateIndex, lastIndex: docStateLastIndex, goBack, goForward } = UndoRedo({ init: initial })
    const [colWise, setcolWise] = useState(currPage === "button" ? finalObj?.button : finalObj?.[`${mobileCondition}pages`]?.[finalObj?.[`${mobileCondition}pages`]?.findIndex($ => $?.id === currPage)]?.values)


    const [timeline, setTimeline] = useState([])
    const [timelineIndex, setTimelineIndex] = useState(0)
    const outletData = getCurrentOutlet()
    const visibleOnOptions = [
        { value: 'scroll', label: 'Scroll' },
        { value: 'delay', label: 'Delay' },
        { value: 'button_click', label: 'Button Click' }
    ]

    const pagesSelection = [
        { value: 'all_pages', label: 'All Pages' },
        { value: 'home_page', label: 'Home Page' },
        { value: 'product_page', label: 'Product Page' },
        { value: 'product_list_page', label: 'Product List Page' },
        { value: 'cart_page', label: 'Cart Page' },
        { value: 'custom_page', label: 'Custom Pages' }
    ]

    const addPage = (e) => {

        const newObj = { ...finalObj }

        if (e.target.checked) {
            if (!finalObj?.behaviour?.PAGES?.includes("all_pages") && e.target.value !== "all_pages") {
                newObj.behaviour.PAGES = [...finalObj?.behaviour?.PAGES, e.target.value]
            } else if (finalObj?.behaviour?.PAGES?.includes("all_pages") && e.target.value !== "all_pages") {
                newObj.behaviour.PAGES = [...finalObj?.behaviour?.PAGES?.filter(item => item !== "all_pages"), e.target.value]
            } else if (e.target.value === "all_pages") {
                newObj.behaviour.PAGES = ["all_pages"]
            }
        } else if (!e.target.checked && (finalObj?.behaviour?.PAGES?.length !== 1)) {
            newObj.behaviour.PAGES = [...finalObj?.behaviour?.PAGES?.filter(item => item !== e.target.value)]
            // } else if (!e.target.checked && (finalObj?.behaviour?.PAGES.length === 1)) {
            //     toast.error("Select atleast one page")
        }

        setFinalObj(newObj)
    }

    const [transfered, setTransfered] = useState("")

    const [crossStyle, setCrossStyle] = useState({ ...finalObj?.crossButtons?.main })
    const [colorType, setColorType] = useState("")

    const [isGenerating, setIsGenerating] = useState(false)
    // const [colorMode, setColorMode] = useState('light')
    const [sideNav, setSideNav] = useState('theme')
    // const [layout, setLayout] = useState([])
    // const [stateHistory, setStateHistory] = useState([])
    // const [index, setIndex] = useState(-1)

    // const [imageDataURLs, setImageDataURLs] = useState([])
    // const [currPosition?.curData, setcurrPosition?.curData] = useState(null)
    const [campaignStart, setCampaignStart] = useState(finalObj?.campaignStartDate === "" ? [new Date()] : [finalObj?.campaignStartDate])
    // const [isEndCampaign, setIsEndCampaign] = useState(false)
    const [campaignEnd, setCampaignEnd] = useState(!finalObj?.campaignHasEndDate ? "" : finalObj?.campaignEndDate === "" ? [new Date()] : [finalObj?.campaignEndDate])

    const [allOffers, setAllOffers] = useState([])
    const [allImages, setAllImages] = useState([])
    const [gotOffers, setGotOffers] = useState(false)

    const [popPosition, setPopPosition] = useState("MC")
    const [currPosition, setCurrPosition] = useState({
        id: null,
        position: null,
        name: null,
        selectedType: "navMenuStyles"
    })

    const [openPage, setOpenPage] = useState(true)
    // const [pageModal, setPageModal] = useState(false)


    const [indexes, setIndexes] = useState({ cur: 0, curElem: "left", subElem: "grandparent" })
    const [dragStartIndex, setDragStartIndex] = useState({ cur: 0, curElem: "left", subElem: "grandparent" })
    const [dragOverIndex, setDragOverIndex] = useState({ cur: 0, curElem: "left", subElem: "grandparent" })
    const [mouseEnterIndex, setMouseEnterIndex] = useState({ cur: false, curElem: false, subElem: false })

    // const [activeRow, setActiveRow] = useState("none")

    const [bgsettings, setBgSettings] = useState({ ...finalObj?.overlayStyles })

    const [bgModal0, setBgModal0] = useState(false)
    const [bgModal, setBgModal] = useState(false)
    const [bgModal2, setBgModal2] = useState(false)
    const [bgModal3, setBgModal3] = useState(false)
    const [bgModal4, setBgModal4] = useState(false)
    const [customColorModal, setCustomColorModal] = useState(false)
    const [customColorModal2, setCustomColorModal2] = useState(false)

    const [bgStyles, setBgStyles] = useState(selectedThemeId === "" ? { backgroundColor: "rgba(255,255,255,1)", bgType: "solid", width: '550px', maxWidth: "90%", minHeight: '75px', paddingTop: "0px", paddingBottom: "0px", paddingRight: "0px", paddingLeft: "0px", marginTop: "0px", marginBottom: "0px", marginRight: "0px", marginLeft: "0px", borderWidth: "0px 0px 0px 0px", defBorderWidth: "0px", borderColor: "rgba(0,0,0,1)", borderStyle: "solid", borderType: "none", borderTopLeftRadius: "0px", borderTopRightRadius: "0px", borderBottomRightRadius: "0px", borderBottomLeftRadius: "0px", boxSizing: "border-box" } : finalObj.backgroundStyles[`${mobileCondition}main`])

    const [btnStyles, setBtnStyles] = useState({ backgroundColor: "rgba(255,255,255,1)", bgType: "solid", width: '300px', maxWidth: "100%", minHeight: '50px', paddingTop: "0px", paddingBottom: "0px", paddingRight: "0px", paddingLeft: "0px", marginTop: "0px", marginBottom: "0px", marginRight: "0px", marginLeft: "0px", borderWidth: "0px 0px 0px 0px", defBorderWidth: "0px", borderColor: "rgba(0,0,0,1)", borderStyle: "solid", borderType: "none", borderTopLeftRadius: "0px", borderTopRightRadius: "0px", borderBottomRightRadius: "0px", borderBottomLeftRadius: "0px", boxSizing: "border-box" })

    const [brandStyles, setBrandStyles] = useState({ backgroundColor: "rgba(255,255,255,0)", bgType: "solid", paddingTop: "0px", paddingBottom: "0px", paddingRight: "0px", paddingLeft: "0px", marginTop: "0px", marginBottom: "0px", marginRight: "auto", marginLeft: "auto", borderWidth: "0px 0px 0px 0px", defBorderWidth: "0px", borderColor: "rgba(0,0,0,1)", borderStyle: "solid", borderType: "none", borderTopLeftRadius: "0px", borderTopRightRadius: "0px", borderBottomRightRadius: "0px", borderBottomLeftRadius: "0px", maxWidth: "100%", maxHeight: "300px", overflow: "auto", boxSizing: "border-box", width: "auto" })

    const [suggestions, setSuggestions] = useState([])

    const [values, setValues] = useState({})

    const [imgModal, setImgModal] = useState(false)

    const [isOfferDraggable, setIsOfferDraggable] = useState(true)
    const [phoneIsOfferDraggable, setPhoneIsOfferDraggable] = useState(true)

    const [cancelCust, setCancelCust] = useState(false)

    const [offerColors, setOfferColors] = useState({ ...finalObj?.offerProperties?.colors })

    const [currOfferColor, setCurrOfferColor] = useState("")

    const [themeId, setThemeId] = useState(themeLoc?.state?.custom_theme ? themeLoc?.state?.id : localStorage.getItem("draftId") ? localStorage.getItem("draftId") : 0)

    const SunEditorConfig = {
        toolbarContainer: '#toolbar_container',
        mode: 'balloon-always',
        showPathLabel: false,
        charCounter: true,
        maxCharCount: 720,
        width: 'auto',
        minWidth: '10px',
        height: 'auto',
        minHeight: '0px',
        maxHeight: 'auto',
        buttonList: [
            // ['undo', 'redo'],
            ['formatBlock', 'bold', 'underline', 'italic', 'strike', 'subscript', 'superscript', 'removeFormat'],
            ['fontColor', 'hiliteColor', 'outdent', 'indent', 'align', 'horizontalRule', 'list', 'lineHeight']
            // ['table', 'link', 'image', 'video', 'fullScreen', 'showBlocks', 'codeView', 'preview', 'print', 'save']
        ]
    }

    const SunEditorConfigBlock = {
        toolbarContainer: '#toolbar_container',
        mode: 'classic',
        showPathLabel: false,
        charCounter: false,
        charCounterLabel: null,
        maxCharCount: null,
        fullPage: false,
        resizingBar: false,

        width: '5px',
        // minWidth: '10px',
        height: 'auto',
        // minHeight: '0px',
        maxHeight: 'auto',
        buttonList: [
            ['font', 'formatBlock', 'bold', 'underline', 'italic', 'strike', 'subscript', 'superscript', 'removeFormat'],
            ['fontColor', 'hiliteColor', 'outdent', 'indent', 'align', 'horizontalRule', 'list', 'lineHeight']
        ]
    }

    // const getImage = (demoImg, src) => {
    //     if (demoImg) {
    //         let img
    //         try {
    //             if (src) {
    //                 img = URL.createObjectURL(demoImg)
    //             } else {
    //                 img = `url('${URL.createObjectURL(demoImg)}')`
    //             }
    //         } catch (error) {
    //             if (demoImg.includes("linear")) {
    //                 img = demoImg
    //             } else {
    //                 img = `url('${demoImg}')`
    //             }
    //         }
    //         return img
    //     }
    // }


    // const QuillConfig = {
    //     selector: '.dfree-body',
    //     menubar: false,
    //     inline: true,
    //     plugins: [
    //         'autolink', 'codesample', 'link', 'lists',
    //         'media', 'powerpaste', 'table', 'image',
    //         'quickbars', 'codesample', 'help', 'emojione', 'emoticons'
    //     ],
    //     toolbar: false,
    //     quickbars_selection_toolbar: `align lineheight spellcheckdialog  | blocks fontfamily fontsize | emoticons bold italic underline link typography | checklist bullist numlist | indent outdent | removeformat`,
    //     quickbars_insert_toolbar: 'undo redo quicktable image media codesample emoticons',
    //     contextmenu: 'undo redo | inserttable | cell row column deletetable | help',
    //     powerpaste_word_import: 'clean',
    //     powerpaste_html_import: 'clean'
    // }

    const [imgLoading, setImgLoading] = useState(false)

    const [goBack, setGoBack] = useState(false)

    const [draftCount, setDraftCount] = useState(0)

    const [isPro, setIsPro] = useState(false)
    const [showBrand, setShowBrand] = useState(true)
    const [offerTheme, setOfferTheme] = useState(finalObj?.offerTheme)
    const [offersModal, setOffersModal] = useState(false)

    const cancelAction = () => {
        const form_data = new FormData()
        if (themeLoc?.state?.custom_theme) {
            const is_draft = localStorage.getItem("is_draft")
            const newObj = JSON.parse(themeLoc?.state?.custom_theme)
            form_data.append('shop', outletData[0]?.web_url)
            form_data.append('app', 'superleadz')
            Object.entries(newObj?.behaviour).map(([key, value]) => {
                if (Array.isArray(value)) {
                    value.map(ele => form_data.append(key, ele))
                } else {
                    form_data.append(key, value)
                }
            })
            form_data.append("json_list", JSON.stringify(newObj))
            form_data.append("selected_offer_list", JSON.stringify(finalObj.selectedOffers))
            form_data.append("campaign_name", newObj?.theme_name)
            form_data.append("start_date", newObj?.campaignStartDate)
            form_data.append("end_date", newObj?.campaignEndDate)
            form_data.append("default_id", selectedThemeId)
            form_data.append("is_edit", 1)

            form_data.append("theme_id", themeId)
            // if (!themeLoc?.state?.custom_theme) {
            form_data.append("is_draft", (is_draft === "undefined" || is_draft === "null") ? 1 : Number(is_draft))
            // }

            axios({
                method: "POST", url: `${SuperLeadzBaseURL}/api/v1/form_builder_template/`, data: form_data
            }).catch((error) => {
                console.log({ error })
            })
        } else {
            const obj = {
                theme_id: [themeId]
            }

            Object.entries(obj).map(([key, value]) => {
                if (Array.isArray(value)) {
                    value.map(ele => {
                        form_data.append(key, ele)
                    })
                } else (
                    form_data.append(key, value)
                )
            })

            axios(`${SuperLeadzBaseURL}/api/v1/delete/theme/`, {
                method: "POST",
                data: form_data
            })
                .catch(() => {
                    return false
                })
        }
    }

    // const [editCount, setEditCount] = useState(0)

    // const [overlayColor, setOverlayColor] = useState("")

    // const undo = () => {
    //   if (index > 0) {
    //   setIndex((prevIndex) => prevIndex - 1)
    //   setcolWise(stateHistory[index - 1])
    //   }
    // }

    // const redo = () => {
    //   if (index < stateHistory.length - 1) {
    //   setIndex((prevIndex) => prevIndex + 1)
    //   setcolWise(stateHistory[index + 1])
    //   }
    // }

    // useEffect(() => {
    //   // Add current colWise to the history when colWise changes (excluding the forward history)
    //   if (index === stateHistory.length - 1) {
    //   setStateHistory((prevHistory) => [...prevHistory.slice(0, index + 1), colWise])
    //   }
    // }, [colWise, index, stateHistory])

    // const settingImage = (image) => {
    //     let demo
    //     try {
    //         demo = URL.createObjectURL(image)
    //     } catch (error) {
    //         demo = image
    //     }
    //     return demo
    // }

    const handleDragStart = (e, dataType, keyType) => {
        e.dataTransfer.setData("type", dataType)
        e.dataTransfer.setData("key", keyType)
    }

    const handleDragOver = (e) => {
        e.preventDefault()
        const transferType = e.dataTransfer.getData("type")
        setDragOverIndex(transferType?.includes("col") ? { cur: colWise?.length, curElem: "parent", subElem: "grandparent" } : { cur: colWise?.length, curElem: "left", subElem: 0 })
    }

    const handleLayoutDrop = (e) => {
        // setSideNav('add-elements')
        const dataTransfered = e.dataTransfer.getData("type")
        const transferedData = dataTransfered?.includes("rearrange") ? dataTransfered?.split("rearrange_") : dataTransfered
        // const transferedKey = e.dataTransfer.getData("key")
        const newObj = { ...finalObj }

        let updatedColWise = []
        let mobile_updatedColWise = []
        const pageIndex = newObj?.pages?.findIndex($ => $.id === currPage)
        const mobile_pageIndex = newObj?.mobile_pages?.findIndex($ => $.id === currPage)

        if (transferedData && transferedData !== "row") {
            if (transferedData === "col3") {
                updatedColWise = [
                    ...finalObj?.pages[pageIndex]?.values, {
                        id: finalObj?.pages[pageIndex]?.values?.length + 1,
                        col: 3,
                        style: elementStyles?.block,
                        elements: [
                            {
                                positionType: 'left',
                                style: elementStyles?.col,
                                element: [{ ...commonObj, type: "", id: finalObj?.pages[pageIndex]?.values?.length }]
                            },
                            {
                                positionType: 'center',
                                style: elementStyles?.col,
                                element: [{ ...commonObj, type: "", id: finalObj?.pages[pageIndex]?.values?.length }]
                            },
                            {
                                positionType: 'right',
                                style: elementStyles?.col,
                                element: [{ ...commonObj, type: "", id: finalObj?.pages[pageIndex]?.values?.length }]
                            }
                        ]
                    }
                ]
                mobile_updatedColWise = [
                    ...finalObj?.mobile_pages[mobile_pageIndex]?.values, {
                        id: finalObj?.mobile_pages[mobile_pageIndex]?.values?.length + 1,
                        col: 3,
                        style: elementStyles?.block,
                        elements: [
                            {
                                positionType: 'left',
                                style: elementStyles?.col,
                                element: [{ ...commonObj, type: "", id: finalObj?.mobile_pages[mobile_pageIndex]?.values?.length }]
                            },
                            {
                                positionType: 'center',
                                style: elementStyles?.col,
                                element: [{ ...commonObj, type: "", id: finalObj?.mobile_pages[mobile_pageIndex]?.values?.length }]
                            },
                            {
                                positionType: 'right',
                                style: elementStyles?.col,
                                element: [{ ...commonObj, type: "", id: finalObj?.mobile_pages[mobile_pageIndex]?.values?.length }]
                            }
                        ]
                    }
                ]
            } else if (transferedData === "col2") {
                updatedColWise = [
                    ...finalObj?.pages[pageIndex]?.values, {
                        id: finalObj?.pages[pageIndex]?.values?.length + 1,
                        col: 2,
                        style: elementStyles?.block,
                        elements: [
                            {
                                positionType: 'left',
                                style: elementStyles?.col,
                                element: [{ ...commonObj, type: "", id: finalObj?.pages[pageIndex]?.values?.length }]
                            },
                            {
                                positionType: 'right',
                                style: elementStyles?.col,
                                element: [{ ...commonObj, type: "", id: finalObj?.pages[pageIndex]?.values?.length }]
                            }
                        ]
                    }
                ]
                mobile_updatedColWise = [
                    ...finalObj?.mobile_pages[mobile_pageIndex]?.values, {
                        id: finalObj?.mobile_pages[mobile_pageIndex]?.values?.length + 1,
                        col: 2,
                        style: elementStyles?.block,
                        elements: [
                            {
                                positionType: 'left',
                                style: elementStyles?.col,
                                element: [{ ...commonObj, type: "", id: finalObj?.mobile_pages[mobile_pageIndex]?.values?.length }]
                            },
                            {
                                positionType: 'right',
                                style: elementStyles?.col,
                                element: [{ ...commonObj, type: "", id: finalObj?.mobile_pages[mobile_pageIndex]?.values?.length }]
                            }
                        ]
                    }
                ]
            } else if (transferedData === "col1") {
                updatedColWise = [
                    ...finalObj?.pages[pageIndex]?.values, {
                        id: finalObj?.pages[pageIndex]?.values?.length + 1,
                        col: 1,
                        style: elementStyles?.block,
                        elements: [
                            {
                                positionType: 'left',
                                style: elementStyles?.col,
                                element: [{ ...commonObj, type: "", id: finalObj?.pages[pageIndex]?.values?.length }]
                            }
                        ]
                    }
                ]
                mobile_updatedColWise = [
                    ...finalObj?.mobile_pages[mobile_pageIndex]?.values, {
                        id: finalObj?.mobile_pages[mobile_pageIndex]?.values?.length + 1,
                        col: 1,
                        style: elementStyles?.block,
                        elements: [
                            {
                                positionType: 'left',
                                style: elementStyles?.col,
                                element: [{ ...commonObj, type: "", id: finalObj?.mobile_pages[mobile_pageIndex]?.values?.length }]
                            }
                        ]
                    }
                ]
            } else if (transferedData !== "" && !transferedData?.includes("col")) {
                updatedColWise = [
                    ...finalObj?.pages[pageIndex]?.values, {
                        id: finalObj?.pages[pageIndex]?.values?.length + 1,
                        col: 1,
                        style: elementStyles?.block,
                        elements: [
                            {
                                positionType: 'left',
                                style: elementStyles?.col,
                                element: [dataTransfered?.includes("rearrange") ? { ...finalObj?.pages[pageIndex]?.values[dragStartIndex?.cur]?.elements[finalObj?.pages[pageIndex]?.values[dragStartIndex?.cur]?.elements?.findIndex($ => $?.positionType === dragStartIndex.curElem)]?.element[dragStartIndex?.subElem] } : { ...commonObj, type: transferedData, id: finalObj?.pages[pageIndex]?.values?.length, style: elementStyles?.[transferedData] }]
                            }
                        ]
                    }
                ]
                mobile_updatedColWise = [
                    ...finalObj?.mobile_pages[mobile_pageIndex]?.values, {
                        id: finalObj?.mobile_pages[mobile_pageIndex]?.values?.length + 1,
                        col: 1,
                        style: elementStyles?.block,
                        elements: [
                            {
                                positionType: 'left',
                                style: elementStyles?.col,
                                element: [dataTransfered?.includes("rearrange") ? { ...finalObj?.mobile_pages[mobile_pageIndex]?.values[dragStartIndex?.cur]?.elements[finalObj?.mobile_pages[mobile_pageIndex]?.values[dragStartIndex?.cur]?.elements?.findIndex($ => $?.positionType === dragStartIndex.curElem)]?.element[dragStartIndex?.subElem] } : { ...commonObj, type: transferedData, id: finalObj?.pages[pageIndex]?.values?.length, style: elementStyles?.[transferedData] }]
                            }
                        ]
                    }
                ]
            }
        }


        if (dataTransfered.includes("rearrange")) {
            updatedColWise[dragStartIndex.cur]?.elements[finalObj?.pages[pageIndex]?.values[dragStartIndex.cur]?.elements?.findIndex($ => $?.positionType === dragStartIndex.curElem)]?.element?.splice(dragStartIndex?.subElem, 1, { ...commonObj })
            mobile_updatedColWise[dragStartIndex.cur]?.elements[finalObj?.mobile_pages[mobile_pageIndex]?.values[dragStartIndex.cur]?.elements?.findIndex($ => $?.positionType === dragStartIndex.curElem)]?.element?.splice(dragStartIndex?.subElem, 1, { ...commonObj })
        }

        setcolWise(isMobile ? mobile_updatedColWise : updatedColWise)

        console.log({ desktop: newObj.pages[pageIndex].values, mobile: newObj.mobile_pages[mobile_pageIndex].values })
        // newObj.pages[pageIndex].values = [...updatedColWise]
        // newObj.mobile_pages[mobile_pageIndex].values = [...mobile_updatedColWise]
        // setFinalObj({ ...newObj })
    }

    const handleElementDrop = (e, position, id, index, curData, j) => {
        const dataTransfered = e.dataTransfer.getData("type")
        setValues({ ...elementStyles?.[dataTransfered] })
        const transferedData = dataTransfered?.includes("rearrange") ? dataTransfered?.split("rearrange_") : dataTransfered

        console.log({ transferedData })

        if (transferedData !== "row") {
            const newObj = { ...finalObj }
            const pageIndex = newObj?.pages?.findIndex($ => $.id === currPage)
            const mobile_pageIndex = newObj?.mobile_pages?.findIndex($ => $.id === currPage)
            const updatedColWise = newObj?.pages[pageIndex]?.values?.map((col, index) => {
                if (index === id) {
                    const updatedElements = col?.elements?.map((ele) => {
                        if (ele?.positionType === position) {
                            const dupArray = [...ele?.element]
                            dupArray[j] = dataTransfered?.includes("rearrange") ? { ...colWise[dragStartIndex?.cur]?.elements[colWise[dragStartIndex?.cur]?.elements?.findIndex($ => $?.positionType === dragStartIndex?.curElem)]?.element[dragStartIndex?.subElem] } : { ...commonObj, ...ele?.elements, type: transferedData, style: elementStyles?.[transferedData] }
                            return {
                                ...ele,
                                element: [...dupArray]
                            }
                        }
                        return ele
                    })

                    return {
                        ...col,
                        elements: updatedElements
                    }
                }
                return col
            })
            const mobile_updatedColWise = newObj?.mobile_pages[mobile_pageIndex]?.values?.map((col, index) => {
                if (index === id) {
                    const updatedElements = col?.elements?.map((ele) => {
                        if (ele?.positionType === position) {
                            const dupArray = [...ele?.element]
                            dupArray[j] = dataTransfered?.includes("rearrange") ? { ...colWise[dragStartIndex?.cur]?.elements[colWise[dragStartIndex?.cur]?.elements?.findIndex($ => $?.positionType === dragStartIndex?.curElem)]?.element[dragStartIndex?.subElem] } : { ...commonObj, ...ele?.elements, type: transferedData, style: elementStyles?.[transferedData] }
                            return {
                                ...ele,
                                element: [...dupArray]
                            }
                        }
                        return ele
                    })

                    return {
                        ...col,
                        elements: updatedElements
                    }
                }
                return col
            })
            if (dataTransfered?.includes("rearrange")) {
                if (isMobile ? mobile_updatedColWise[dragStartIndex.cur]?.elements[colWise[dragStartIndex?.cur]?.elements?.findIndex($ => $?.positionType === dragStartIndex?.curElem)]?.element?.length < 2 : updatedColWise[dragStartIndex.cur]?.elements[colWise[dragStartIndex?.cur]?.elements?.findIndex($ => $?.positionType === dragStartIndex?.curElem)]?.element?.length < 2) {
                    updatedColWise[dragStartIndex.cur]?.elements[colWise[dragStartIndex.cur]?.elements?.findIndex($ => $?.positionType === dragStartIndex?.curElem)]?.element?.splice(dragStartIndex?.subElem, 1, { ...commonObj })
                    mobile_updatedColWise[dragStartIndex.cur]?.elements[colWise[dragStartIndex.cur]?.elements?.findIndex($ => $?.positionType === dragStartIndex?.curElem)]?.element?.splice(dragStartIndex?.subElem, 1, { ...commonObj })
                } else {
                    updatedColWise[dragStartIndex.cur]?.elements[colWise[dragStartIndex?.cur]?.elements?.findIndex($ => $?.positionType === dragStartIndex?.curElem)].element?.splice(dragStartIndex?.subElem, 1)
                    mobile_updatedColWise[dragStartIndex.cur]?.elements[colWise[dragStartIndex?.cur]?.elements?.findIndex($ => $?.positionType === dragStartIndex?.curElem)].element?.splice(dragStartIndex?.subElem, 1)
                }
            }
            setcolWise(isMobile ? mobile_updatedColWise : updatedColWise)

            newObj.pages[pageIndex].values = [...updatedColWise]
            newObj.mobile_pages[mobile_pageIndex].values = [...mobile_updatedColWise]
            setFinalObj({ ...newObj })
            // if (curData.element.type === "image") {
            //     const imageInput = document.getElementById(`imageInput-${id}-${index}`)
            //     imageInput.click()
            // }
        }
    }

    const handleImage = (e) => {
        // const { id } = currPosition
        // const index = cur.elements.findIndex(elem => elem.positionType === position)
        const dupArray = [...colWise]
        const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)
        // if (!dupArray[currPosition]) {
        //   dupArray[id] = { ...cur }
        // }
        dupArray[indexes.cur].elements[positionIndex].element[dupArray[indexes.cur].elements[positionIndex].element.length - 1] = { ...commonObj, ...dupArray[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem], type: "image", src: e.target.files[0], style: elementStyles?.image }
        setcolWise([...dupArray])
    }

    // const handleImageChange = (e, id) => {
    //   const file = e.target.files[0]
    //   const reader = new FileReader()
    //   reader.onload = (event) => {
    //   const imageDataURL = event.target.result
    //   setImageDataURLs((prevImageDataUrls) => {
    //   const updatedImageDataUrls = [...prevImageDataUrls]
    //   updatedImageDataUrls[id] = imageDataURL
    //   return updatedImageDataUrls
    //   })
    //   }
    //   reader.readAsDataURL(file)
    // }

    const makActive = (e, cur, curData, position, id, j) => {
        setCurrPosition({ ...currPosition, position, id, name: e.target.name, curData, cur, j })
    }


    // const updateValues = () => {

    //     // const dimensions = ["height", "width", "minHeight", "minWidth", "maxHeight", "maxWidth"]

    //     // const updatedColWise = colWise.map((col, index) => {
    //     //   if (index === currPosition.id) {
    //     //   const updatedElements = col.elements.map((ele) => {
    //     //   if (ele.positionType === currPosition.position) {
    //     //   return {
    //     //   ...ele,
    //     //   element: [{ ...commonObj, ...ele.element, style: { ...ele.element.style, [e.target.name]: e.target.value } }]
    //     //   }
    //     //   }
    //     //   return ele
    //     //   })

    //     //   return {
    //     //   ...col,
    //     //   elements: updatedElements
    //     //   }
    //     //   }
    //     //   return col
    //     // })
    //     // setcolWise(updatedColWise)
    // }

    // const deleteRow = (key) => {
    //     const dupArray = [...colWise]
    //     dupArray.splice(key, 1)
    //     setcolWise(dupArray)
    //     // setcolWise(colWise.filter(item => item.id !== (key + 1)))
    // }
    const changeColumn = (col, width) => {
        // const positions = ["left", "center", "right"]
        const dupArray = [...colWise]
        // if (Number(col) !== colWise[indexes.cur]?.elements?.length) {
        let elements
        if (col === "1") {
            elements = [
                {
                    positionType: 'left',
                    style: { ...colWise[indexes.cur]?.elements[0]?.style, width: `${width?.left}` },
                    element: [...colWise[indexes.cur]?.elements[0]?.element]
                }
                // { ...elementStyles.col, width: `${width.left}` }
            ]
        } else if (col === "2") {
            elements = [
                {
                    positionType: 'left',
                    style: { ...colWise[indexes.cur]?.elements[0]?.style, width: `${width?.left}` },
                    element: [...colWise[indexes.cur]?.elements[0]?.element]
                },
                {
                    positionType: 'right',
                    style: colWise[indexes?.cur].elements?.length !== 1 ? { ...colWise[indexes?.cur]?.elements[1]?.style, width: `${width?.right}` } : { ...elementStyles?.col, width: `${width?.right}` },
                    element: colWise[indexes?.cur]?.elements?.length !== 1 ? [...colWise[indexes?.cur]?.elements[1]?.element] : [{ ...commonObj, type: "", id: colWise?.length }]
                }
            ]
        } else {
            elements = [
                {
                    positionType: 'left',
                    style: { ...colWise[indexes.cur]?.elements[0]?.style, width: `${width?.left}` },
                    element: [...colWise[indexes.cur]?.elements[0]?.element]
                },
                {
                    positionType: 'center',
                    style: colWise[indexes.cur]?.elements?.length > 1 ? { ...colWise[indexes.cur]?.elements[1]?.style, width: `${width?.center}` } : { ...elementStyles?.col, width: `${width?.center}` },
                    element: colWise[indexes.cur]?.elements?.length > 1 ? [...colWise[indexes.cur]?.elements[1]?.element] : [{ ...commonObj, type: "", id: colWise?.length }]
                },
                {
                    positionType: 'right',
                    style: colWise[indexes.cur].elements?.length === 3 ? { ...colWise[indexes.cur]?.elements[2]?.style, width: `${width?.center}` } : { ...elementStyles?.col, width: `${width?.right}` },
                    element: colWise[indexes.cur]?.elements?.length === 3 ? [...colWise[indexes.cur]?.elements[2]?.element] : [{ ...commonObj, type: "", id: colWise?.length }]
                }
            ]
        }
        dupArray[indexes.cur].elements = elements
        setcolWise([...colWise])
        // }
    }
    const generateSuggestion = () => {
        setIsGenerating(true)
        const innertext = document.getElementById(`textField-${indexes?.cur}-${indexes?.curElem}-${indexes?.subElem}`)
        const suggestionUrl = new URL(`${SuperLeadzBaseURL}/utils/api/v1/PromptSuggestion/`)
        const newArr = []

        const form_data = new FormData()

        form_data.append("type_of_content", "coupon text")
        form_data.append("content_text", innertext.innerText === "" ? "redeem OFFER_CODE and get 20% off" : innertext.innerText)

        for (let index = 0; index < 5; index++) {
            axios({
                method: "POST",
                url: suggestionUrl,
                data: form_data
            }).then((response) => {
                setIsGenerating(false)
                newArr.push(response.data.generated_text)
                if (index === 4) {
                    setSuggestions([...newArr])
                }
            }).catch((error) => {
                toast.error("error aaya", error)
            })
        }
    }

    const triggerImage = () => {
        setImgModal(true)
        setImgLoading(true)
        const imgUrl = new URL(`${SuperLeadzBaseURL}/api/v1/bucket_images/?shop=${outletData[0]?.web_url}&app=superleadz`)
        axios({
            method: "GET",
            url: imgUrl
        })
            .then((data) => {
                if (data.status === 200) {
                    setAllImages(data.data.images)
                    setImgLoading(false)
                } else {
                    toast.error("request image failed")
                }
            })
            .catch(err => console.log(err))
    }

    const renderElems = () => {
        const { selectedType } = currPosition
        // if (colWise[indexes.cur]) {
        // const objLocation = colWise[currPosition.id]?.elements.filter(item => {
        //   return item.positionType === currPosition.position
        // })
        let styles, general, advanced

        const inputTypeList = [
            { value: 'email', label: 'Email' },
            { value: 'number', label: 'Phone Number' },
            { value: 'firstName', label: 'First Name' },
            { value: 'lastName', label: 'Last Name' },
            { value: "enter_otp", label: "Enter OTP" }
        ]

        const draggedTypes = new Array()

        colWise?.forEach(cur => {
            cur?.elements?.forEach(curElem => {
                curElem.element?.forEach(subElem => {
                    if (subElem?.type === "input") {
                        draggedTypes?.push(subElem?.inputType)
                    }
                })
            })
        })

        if (selectedType === "button") {
            const arr = [...colWise]
            const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes.curElem)
            const pagesSelect = [
                { value: 'nextPage', label: 'Next page' },
                { value: 'jumpTo', label: 'Jump to' },
                { value: 'redirect', label: 'Redirect' },
                { value: 'call', label: 'Call' },
                { value: 'close', label: 'Close' },
                { value: 'sendOTP', label: 'Send OTP' }
            ]
            const pageRedirect = finalObj?.[`pages`]?.filter(item => item.id !== "user_verification")?.map((ele) => {
                return { label: ele.pageName, value: ele.id }
            })
            const bgCheckedCondition = (finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))]?.common?.includes("backgroundColor") || finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))]?.common?.includes("backgroundImage")) && finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))]?.page === currPage
            styles = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Display</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className='p-0 mb-2 justify-content-start align-items-center'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Width:</span>
                                        <Select className='w-100' name="" onChange={e => {
                                            if (e.value === "auto") {
                                                setValues({ ...values, widthType: e.value, width: e.value, minHeight: "0px", padding: "10px" })
                                            } else if (e.value === "100%") {
                                                setValues({ ...values, widthType: e.value, width: e.value, minHeight: "0px", padding: "10px" })
                                            } else if (e.value === "custom") {
                                                setValues({ ...values, widthType: e.value, padding: "10px" })
                                            }
                                        }} id="" options={[
                                            { value: 'auto', label: 'Fluid' },
                                            { value: '100%', label: '100%' },
                                            { value: 'custom', label: 'Custom' }
                                        ]} />
                                    </div>
                                    {values.widthType === "custom" && <div className='mb-2'>
                                        <p className='fw-bolder text-black mb-1' style={{ fontSize: "0.75rem" }}>Width: {arr[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.style?.width || ""}</p>
                                        <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                            <input type='range' className='w-100' onChange={e => {
                                                setValues({ ...values, width: `${e.target.value}px` })
                                            }} name="height" min="20" max="600" />
                                        </div>
                                    </div>}
                                    {values.widthType !== "auto" && <div className='mb-2'>
                                        <p className='fw-bolder text-black mb-1' style={{ fontSize: "0.75rem" }}>Height: {arr[indexes.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.style?.minHeight || ""}</p>
                                        <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                            <input type='range' className='w-100' onChange={e => {
                                                setValues({ ...values, minHeight: `${e.target.value}px` })
                                            }} name="height" min="0" max="600" />
                                        </div>
                                    </div>}
                                    <div className='mb-2'>
                                        <div className="d-flex justify-content-between align-items-center">
                                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Font Size: {values?.fontSize || ""}</span>
                                        </div>
                                        <div className="p-0 justify-content-start align-items-center gap-2">
                                            <input value={parseFloat(values?.fontSize)} type='range' className='w-100' onChange={e => {
                                                setValues({ ...values, fontSize: `${e.target.value}px` })
                                            }} name="height" min="0" max="60" />
                                        </div>
                                        <div className="d-flex align-items-center justify-content-between gap-1 form-check form-check-success m-0 p-0">
                                            <label style={{ fontSize: "10px" }} className="form-check-label m-0 p-0">Keep same font size for {isMobile ? "desktop theme" : "mobile theme"}</label>
                                            <input checked={finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))]?.common?.includes("fontSize") && finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))]?.page === currPage} type='checkbox' className='form-check-input m-0 p-0' onChange={(e) => {
                                                const newObj = { ...finalObj }
                                                if (e.target.checked) {
                                                    if (finalObj?.responsive?.some($ => isEqual($?.position, { ...indexes }))) {
                                                        const responiveIndex = finalObj.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))
                                                        newObj?.responsive[responiveIndex]?.common?.push("fontSize")
                                                    } else {
                                                        newObj?.responsive?.push({ position: { ...indexes }, common: ["fontSize"], page: currPage })
                                                    }
                                                } else {
                                                    const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))
                                                    newObj.responsive[responiveIndex].common = newObj?.responsive[responiveIndex]?.common?.filter(item => item !== "fontSize")
                                                }
                                                setFinalObj({ ...newObj })
                                                // if (currPage === "button") {
                                                //     newObj[`${mobileCondition}`]
                                                // }
                                            }} />
                                        </div>
                                    </div>
                                    {values?.widthType !== "100%" && (<>
                                        <p className='fw-bolder text-black mb-1' style={{ fontSize: "0.75rem" }}>Alignment:</p>
                                        <div className="blocks d-flex gap-1 mb-1">
                                            <div onClick={() => setValues({ ...values, alignType: "start" })} className={`cursor-pointer rounded w-100 text-center border-${values?.alignType === "left" ? "black" : "dark"}`} style={{ padding: "0.5rem", aspectRatio: "1" }}>
                                                <div>
                                                    <svg
                                                        width="1.25rem"
                                                        height="1.25rem"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24"
                                                        fill={values?.alignType === "start" ? "black" : "#464646"}
                                                    >
                                                        <path d="M21,10H16V7a1,1,0,0,0-1-1H4V3A1,1,0,0,0,2,3V21a1,1,0,0,0,2,0V18H21a1,1,0,0,0,1-1V11A1,1,0,0,0,21,10ZM4,8H14v2H4Zm16,8H4V12H20Z" />
                                                    </svg>
                                                </div>
                                                <div>
                                                    <span className={`text-${values?.alignType === "start" ? "black" : "dark"}`}>Left</span>
                                                </div>
                                            </div>
                                            <div onClick={() => setValues({ ...values, alignType: "center" })} className={`cursor-pointer rounded w-100 text-center border-${values?.alignType === "center" ? "black" : "dark"}`} style={{ padding: "0.5rem", aspectRatio: "1" }}>
                                                <div>
                                                    <svg
                                                        width="1.25rem"
                                                        height="1.25rem"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24"
                                                        fill={values?.alignType === "center" ? "black" : "#464646"}
                                                    >
                                                        <path d="M21,10H19V7a1,1,0,0,0-1-1H13V3a1,1,0,0,0-2,0V6H6A1,1,0,0,0,5,7v3H3a1,1,0,0,0-1,1v6a1,1,0,0,0,1,1h8v3a1,1,0,0,0,2,0V18h8a1,1,0,0,0,1-1V11A1,1,0,0,0,21,10ZM7,8H17v2H7Zm13,8H4V12H20Z" />
                                                    </svg>
                                                </div>
                                                <div>
                                                    <span className={`text-${values?.alignType === "center" ? "black" : "dark"}`}>Center</span>
                                                </div>
                                            </div>
                                            <div onClick={() => setValues({ ...values, alignType: "end" })} className={`cursor-pointer rounded w-100 text-center border-${values?.alignType === "end" ? "black" : "dark"}`} style={{ padding: "0.5rem", aspectRatio: "1" }}>
                                                <div>
                                                    <svg
                                                        width="1.25rem"
                                                        height="1.25rem"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24"
                                                        fill={values?.alignType === "end" ? "black" : "#464646"}
                                                    >
                                                        <path d="M21,2a1,1,0,0,0-1,1V6H9A1,1,0,0,0,8,7v3H3a1,1,0,0,0-1,1v6a1,1,0,0,0,1,1H20v3a1,1,0,0,0,2,0V3A1,1,0,0,0,21,2ZM20,16H4V12H20Zm0-6H10V8H20Z" />
                                                    </svg>
                                                </div>
                                                <div>
                                                    <span className={`text-${values?.alignType === "end" ? "black" : "dark"}`}>Right</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="d-flex align-items-center justify-content-between gap-1 form-check form-check-success m-0 p-0">
                                            <label style={{ fontSize: "10px" }} className="form-check-label m-0 p-0">Keep same alignment for {isMobile ? "desktop theme" : "mobile theme"}</label>
                                            <input checked={finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))]?.common?.includes("alignType") && finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))]?.page === currPage} type='checkbox' className='form-check-input m-0 p-0' onChange={(e) => {
                                                const newObj = { ...finalObj }
                                                if (e.target.checked) {
                                                    if (finalObj?.responsive?.some($ => isEqual($?.position, { ...indexes }))) {
                                                        const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))
                                                        newObj?.responsive[responiveIndex]?.common.push("alignType")
                                                    } else {
                                                        newObj?.responsive?.push({ position: { ...indexes }, common: ["alignType"], page: currPage })
                                                    }
                                                } else {
                                                    const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))
                                                    newObj.responsive[responiveIndex].common = newObj?.responsive[responiveIndex]?.common?.filter(item => item !== "alignType")
                                                }
                                                setFinalObj({ ...newObj })
                                            }} />
                                        </div>
                                    </>)}
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='2' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Background Fill</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='2'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className='p-0 mb-1 justify-content-start align-items-center'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Solid Color:</span>
                                        <div className="border p-1 rounded" style={{ backgroundColor: values?.backgroundColor, backgroundImage: values?.backgroundImage }} onClick={() => setBgModal0(!bgModal0)}></div>
                                    </div>
                                    <div className="d-flex align-items-center justify-content-between gap-1 form-check form-check-success m-0 p-0">
                                        <label style={{ fontSize: "10px" }} className="form-check-label m-0 p-0">Keep same background for {isMobile ? "desktop theme" : "mobile theme"}</label>
                                        <input checked={bgCheckedCondition} type='checkbox' className='form-check-input m-0 p-0' onChange={(e) => {
                                            const newObj = { ...finalObj }
                                            if (e.target.checked) {
                                                if (finalObj?.responsive?.some($ => isEqual($?.position, { ...indexes }))) {
                                                    const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))
                                                    newObj.responsive[responiveIndex].common = [...newObj?.responsive[responiveIndex]?.common, "backgroundColor", "backgroundImage"]
                                                } else {
                                                    newObj?.responsive?.push({ position: { ...indexes }, common: ["backgroundColor", "backgroundImage"], page: currPage })
                                                }
                                            } else {
                                                const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))
                                                newObj.responsive[responiveIndex].common = newObj?.responsive[responiveIndex]?.common?.filter(item => (item !== "backgroundColor") && (item !== "backgroundImage"))
                                            }
                                            setFinalObj({ ...newObj })
                                        }} />
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='3' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Border and Shadow</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='3'>
                                <BorderChange setStyles={setValues} styles={values} />
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
            general = (
                <>
                    <div className='px-1 mx-0 my-1'>
                        <div className='p-0 mb-1'>
                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Button Text:</span>
                            <SunEditor
                                setOptions={{ ...SunEditorConfigBlock, value: colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.textValue ? arr[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.textValue : "Enter Text" }}
                                onChange={(content) => {
                                    arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].textValue = content
                                    setcolWise([...arr])
                                }}
                            />
                            <div className="edit_here mt-3">
                                <Editor onChange={(content) => {
                                    arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].textValue = content
                                        setcolWise([...arr])
                                    }} 
                                    htmlContent={colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.textValue ? arr[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.textValue : "Enter Text"} 
                                />

                            </div>
                            {/* <input
                            className="form-control"
                            type="text"
                        /> */}
                        </div>
                        <div className='p-0 mb-1 me-1 justify-content-start align-items-center'>
                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>On click:</span>
                            <Select value={pagesSelect?.filter(item => item?.value === colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.redirectType)} onChange={e => {
                                arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].redirectType = e.value
                                arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].redirectTo = ""
                                setcolWise([...colWise])
                            }} options={pagesSelect} />
                        </div>
                        {colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.redirectType === "jumpTo" && <div className='p-0 mb-1 me-1 justify-content-start align-items-center'>
                            <span className='fw-bolder text-black mb-2' style={{ fontSize: "0.75rem" }}>Chosen Page:</span>
                            <Select value={pageRedirect?.filter(item => item?.value === colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.redirectTo)} onChange={e => {
                                arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].redirectTo = e.value
                                setcolWise([...arr])
                            }} options={pageRedirect} />
                        </div>}
                        {colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.redirectType === "redirect" && <div className='p-0 mb-1 me-1 justify-content-start align-items-center'>
                            <span className='fw-bolder text-black mb-2' style={{ fontSize: "0.75rem" }}>URL:</span>
                            <input type="text" className='form-control' placeholder='https://example.url.com' value={colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.redirectTo} onChange={e => {
                                arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].redirectTo = e.target.value
                                setcolWise([...arr])
                            }} />
                        </div>}
                        {colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.redirectType === "call" && <div className='p-0 mb-1 me-1 justify-content-start align-items-center'>
                            <span className='fw-bolder text-black mb-2' style={{ fontSize: "0.75rem" }}>Phone Number:</span>
                            <div className="d-flex align-items-center gap-1">
                                <select name="" id="" className="form-select w-50">
                                    {
                                        countries?.map((ele, key) => {
                                            return (
                                                <option key={key} value={ele?.isoNumeric}>{ele?.flag}</option>
                                            )
                                        })
                                    }
                                </select>
                                <input type="text" className='form-control w-100' placeholder='Phone Number' value={colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.redirectTo} onChange={e => {
                                    arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].redirectTo = e.target.value
                                    setcolWise([...arr])
                                }} />
                            </div>
                        </div>}
                        {colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.redirectType === "sendOTP" && <div className='p-0 mb-1 me-1 justify-content-start align-items-center'>
                            <span className='fw-bolder text-black mb-2' style={{ fontSize: "0.75rem" }}>Send OTP:</span>
                            <div className="">
                                {colWise?.map((cur, key) => {
                                    return cur?.elements?.map((curElem, i) => {
                                        return curElem?.element?.map((subElem, j) => {
                                            if (subElem?.type === "input") {
                                                return (
                                                    <div className="form-check">
                                                        <input checked={arr[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.sendOTPto?.includes(subElem?.inputType)} id={`renderElems-${key}-${i}-${j}`} onChange={() => {
                                                            arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].sendOTPto = []
                                                            arr[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.sendOTPto?.push(subElem?.inputType)
                                                        }} type="checkbox" className="form-check-input" /><label htmlFor={`renderElems-${key}-${i}-${j}`} className="form-check-label">{inputTypeList?.filter($ => $?.value === subElem?.inputType)[0]?.label || ""}</label>
                                                    </div>
                                                )
                                            }
                                        })
                                    })
                                })}
                            </div>
                        </div>}
                    </div>
                </>
            )
            advanced = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Spacing</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <InputChange
                                        allValues={values}
                                        setAllValues={setValues}
                                        type="margin"
                                    />
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
        } else if (selectedType === "text") {
            const arr = [...colWise]
            const positionIndex = colWise[indexes?.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)
            const textShadowOpts = [
                { value: '0px 0px 0px rgba(0,0,0,0)', label: 'None' },
                { value: '0px 0px 5px rgba(0,0,0,0.5)', label: 'Small' },
                { value: '0px 0px 15px rgba(0,0,0,0.75)', label: 'Medium' },
                { value: '0px 0px 25px rgba(0,0,0,1.0)', label: 'Large' }
            ]
            styles = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Display</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className='p-0 mb-2 justify-content-start align-items-center'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Text Shadow:</span>
                                        <Select className='mb-1' value={textShadowOpts?.filter(item => item.value === values?.textShadow)} onChange={e => {
                                            setValues({ ...values, textShadow: e.value })
                                        }} options={textShadowOpts} />
                                        <div className="d-flex align-items-center justify-content-between gap-1 form-check form-check-success m-0 p-0">
                                            <label style={{ fontSize: "10px" }} className="form-check-label m-0 p-0">Keep same text shadow for {isMobile ? "desktop theme" : "mobile theme"}</label>
                                            <input checked={finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))]?.common?.includes("textShadow") && finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))]?.page === currPage} type='checkbox' className='form-check-input m-0 p-0' onChange={(e) => {
                                                const newObj = { ...finalObj }
                                                if (e.target.checked) {
                                                    if (finalObj?.responsive?.some($ => isEqual($?.position, { ...indexes }))) {
                                                        const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))
                                                        newObj.responsive[responiveIndex].common = [...newObj?.responsive[responiveIndex]?.common, "textShadow"]
                                                    } else {
                                                        newObj?.responsive?.push({ position: { ...indexes }, common: ["textShadow"], page: currPage })
                                                    }
                                                } else {
                                                    const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))
                                                    newObj.responsive[responiveIndex].common = newObj?.responsive[responiveIndex]?.common?.filter(item => item !== "textShadow")
                                                }
                                                setFinalObj({ ...newObj })
                                            }} />
                                        </div>
                                    </div>
                                    <div className='mb-2'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Text Rotation: {parseFloat(values?.rotate)}°</span>
                                        <div className="p-0 justify-content-start align-items-center gap-2">
                                            <input type='range' value={parseFloat(values?.rotate)} className='w-100' onChange={e => {
                                                if (!isNaN(e.target.value)) {
                                                    setValues({ ...values, rotate: `${e.target.value}deg` })
                                                }
                                            }} name="height" min="-180" max="180" />
                                            {/* <input type="number" name='height' onChange={e => {
                                                        // updateValues(e)
                                                        if (!isNaN(e.target.value)) {
                                                        arr[indexes.cur].elements[positionIndex].element[indexes.subElem].style.rotate =  `${e.target.value}deg`
                                                        setcolWise([...arr])
                                                        }
                                                        }} min="0" max="360" className='w-50 form-control' /> */}
                                        </div>
                                        <div className="d-flex align-items-center justify-content-between gap-1 form-check form-check-success m-0 p-0">
                                            <label style={{ fontSize: "10px" }} className="form-check-label m-0 p-0">Keep same rotation for {isMobile ? "desktop theme" : "mobile theme"}</label>
                                            <input checked={finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))]?.common?.includes("rotate") && finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))]?.page === currPage} type='checkbox' className='form-check-input m-0 p-0' onChange={(e) => {
                                                const newObj = { ...finalObj }
                                                if (e.target.checked) {
                                                    if (finalObj?.responsive?.some($ => isEqual($?.position, { ...indexes }))) {
                                                        const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))
                                                        newObj.responsive[responiveIndex].common = [...newObj?.responsive[responiveIndex]?.common, "rotate"]
                                                    } else {
                                                        newObj?.responsive?.push({ position: { ...indexes }, common: ["rotate"], page: currPage })
                                                    }
                                                } else {
                                                    const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, { ...indexes }))
                                                    newObj.responsive[responiveIndex].common = newObj?.responsive[responiveIndex]?.common?.filter(item => item !== "rotate")
                                                }
                                                setFinalObj({ ...newObj })
                                            }} />
                                        </div>
                                    </div>
                                    <div className='mb-2'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Font Size: {values?.fontSize}</span>
                                        <div className="p-0 justify-content-start align-items-center gap-2">
                                            <input value={parseFloat(values?.fontSize)} type='range' className='w-100' onChange={e => {
                                                setValues({ ...values, fontSize: `${e.target.value}px` })
                                            }} name="height" min="0" max="60" />
                                        </div>
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='2' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Background Fill</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='2'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className='p-0 mb-1 justify-content-start align-items-center'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Background</span>
                                        {/* <input
                                                type="color"
                                                className="w-100"
                                                name="backgroundColor"
                                                onChange={e => {
                                                    arr[indexes.cur].elements[positionIndex].element[indexes.subElem].style.backgroundColor = e.target.value
                                                    setcolWise([...arr])
                                                }}
                                            // defaultValue={activeData.label}
                                            /> */}
                                        <div style={{ backgroundImage: `url(${pixels})` }}>
                                            <div className="p-1 border rounded" style={{ backgroundImage: values?.backgroundImage, backgroundColor: values?.backgroundColor }} onClick={() => setBgModal0(!bgModal0)}></div>
                                        </div>
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='3' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Border and Shadow</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='3'>
                                <BorderChange styles={values} setStyles={setValues} />
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
            general = (
                <>
                    <div className=''>
                        <div className='p-0 m-1'>
                            <SunEditor
                                setOptions={{ ...SunEditorConfigBlock, value: colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.textValue ? arr[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.textValue : "Enter Text" }}
                                onChange={(content) => {
                                    if (arr[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.textValue) {
                                        arr[indexes.cur].elements[positionIndex].element[indexes?.subElem].textValue = content
                                    }
                                    setcolWise([...arr])
                                }}
                            />
                            <div className="edit_here mt-3">
                                <Editor 
                                    onChange={(content) => {
                                        if (arr[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.textValue) {
                                            arr[indexes.cur].elements[positionIndex].element[indexes?.subElem].textValue = content
                                        }
                                        setcolWise([...arr])
                                    }}
                                    htmlContent={colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.textValue ? arr[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.textValue : "Enter Text"}
                                />

                            </div>
                            {/* <input
                            className="form-control"
                            type="text"
                        /> */}
                        </div>
                        <div className='p-0 m-1 d-none'>
                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Smart headline generator</span>
                            <button onClick={generateSuggestion} type='button' className='btn btn-dark px-2 w-100 mb-1 d-flex justify-content-start align-items-center gap-2' style={{ fontSize: "0.75rem" }}>
                                <div className='d-flex justify-content-center align-items-end'>
                                    <Star size={15} />
                                    <Star size={8} />
                                </div>
                                {/* <div className="flex-grow-1"></div> */}
                                <div className={`flex-grow-1`}>
                                    {isGenerating ? (
                                        <Spinner />
                                    ) : (
                                        <span>Generate Suggestions</span>
                                    )}
                                </div>
                            </button>

                            {suggestions?.map((suggestion, index) => {
                                return (
                                    <div onClick={() => {
                                        const textField = document.querySelector(`#textField-${indexes?.cur}-${indexes?.curElem}-${indexes?.subElem} p`)
                                        // const newElem = document.createElement("p")
                                        // newElem.innerHTML = textField
                                        // newElem.innerText = suggestion
                                        // arr[indexes.cur].elements[positionIndex].element[indexes.subElem].textValue = newElem
                                        // setcolWise([...arr])
                                        textField.innerText = suggestion
                                    }} key={index} className="border p-1 mb-1 rounded cursor-pointer gen-text">
                                        <p style={{ fontSize: "12px" }}>{suggestion}</p>
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                </>
            )
            advanced = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Spacing</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <InputChange
                                        allValues={values}
                                        setAllValues={setValues}
                                        type="padding"
                                    />
                                    <InputChange
                                        allValues={values}
                                        setAllValues={setValues}
                                        type="margin"
                                    />
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
        } else if (selectedType === "image") {
            const arr = [...colWise]
            const positionIndex = colWise[indexes?.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)
            const imgWidth = colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.style?.width
            const alignOptions = [
                { value: 'auto auto auto 0px', label: 'Left' },
                { value: 'auto', label: 'Center' },
                { value: 'auto 0px auto auto', label: 'Right' }
            ]
            styles = (
                <>
                    <UncontrolledAccordion defaultOpen={['1']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Border and Shadow</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <BorderChange styles={values} setStyles={setValues} />
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
            general = (
                <>
                    <UncontrolledAccordion defaultOpen={['1']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Image setting</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Select/Upload Image:</span>
                                    {arr[indexes.cur]?.elements[positionIndex]?.element[indexes.subElem]?.showRecommended ? <div style={{ fontSize: "10px" }}>Recommended image size: {arr[indexes.cur]?.elements[positionIndex]?.element[indexes.subElem]?.recommendedWidth}</div> : <></>}
                                    <div
                                        onClick={() => {
                                            setImgModal(!imgModal)
                                            triggerImage()
                                        }}
                                        className="d-flex justify-content-center align-items-center mb-1 position-relative"
                                        style={{ width: '100%', aspectRatio: '16/9' }}
                                    >
                                        <div
                                            className="overlay"
                                            style={{
                                                display: 'none',
                                                position: 'absolute',
                                                top: 0,
                                                left: 0,
                                                width: '100%',
                                                height: '100%',
                                                background: 'rgba(0, 0, 0, 0.5)',
                                                display: 'flex',
                                                justifyContent: 'center',
                                                alignItems: 'center',
                                                color: '#fff',
                                                fontSize: '18px',
                                                cursor: 'pointer',
                                                zIndex: 1
                                            }}
                                        >
                                            {colWise[indexes.cur]?.elements[positionIndex]?.element[indexes.subElem]?.src === "" ? <PlusCircle size={19} /> : <Edit size={19} />}
                                        </div>
                                        <img style={{ maxWidth: "100%", maxHeight: "100%" }} src={colWise[indexes.cur]?.elements[positionIndex]?.element[indexes.subElem]?.src} alt="" />
                                    </div>
                                    <div className='mb-1'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Width: {imgWidth}</span>
                                        <div className="p-0 justify-content-start align-items-center gap-2">
                                            <input value={parseFloat(imgWidth)} onChange={(e) => {
                                                // arr[indexes.cur].elements[positionIndex].element[indexes.subElem].style.width = `${e.target.value}px`
                                                setValues({ ...values, width: `${e.target.value}px` })
                                                // setcolWise([...arr])
                                            }} type='range' className='w-100' name="height" min="20" max="1500" />
                                            {/* <input onChange={(e) => {
                                                arr[indexes.cur].elements[positionIndex].element[indexes.subElem].style.width = `${e.target.value}px`
                                                setcolWise([...arr])
                                                }} type="number" name='height' min="0" max="1500" className='w-50 form-control' /> */}
                                        </div>
                                    </div>
                                    <div className='p-0 mb-1 align-items-center'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Alignment:</span>
                                        <Select value={alignOptions?.filter(item => item?.value === colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.style?.margin)} onChange={e => {
                                            arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].style.margin = e.value
                                            setcolWise([...arr])
                                        }} options={alignOptions} />
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
            advanced = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Spacing</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <InputChange
                                        allValues={values}
                                        setAllValues={setValues}
                                        type="padding"
                                    />
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
            // } else {
            //   general = <>
            //   <div className="d-flex justify-content-center align-items-center mt-2">
            //   <div className={'d-flex justify-content-center align-items-center cursor-pointer'}>
            //   <svg
            //  version="1.1"
            //  xmlns="http://www.w3.org/2000/svg"
            //  xmlnsXlink="http://www.w3.org/1999/xlink"
            //  viewBox="0 0 64 54"
            //  xmlSpace="preserve"
            //  className='w-50'
            //   >
            //  <g>
            //  <rect
            //  x={2}
            //  y={2}
            //  width={60}
            //  rx={5}
            //  height={50}
            //  fill="transparent"
            //  strokeWidth={3}
            //  stroke="#727272"
            //  />
            //  </g>
            //   </svg>
            //   </div>
            //   <div className={'d-flex justify-content-center align-items-center cursor-pointer'}>
            //   <svg
            //  version="1.1"
            //  xmlns="http://www.w3.org/2000/svg"
            //  xmlnsXlink="http://www.w3.org/1999/xlink"
            //  viewBox="0 0 64 54"
            //  xmlSpace="preserve"
            //  className='w-50'
            //   >
            //  <g>
            //  <rect
            //  x={2}
            //  y={2}
            //  width={60}
            //  rx={5}
            //  height={50}
            //  fill="transparent"
            //  strokeWidth={3}
            //  stroke="#727272"
            //  />
            //  <path d="M32 52 L 32 2" strokeWidth={3} stroke="#727272" />
            //  </g>
            //   </svg>
            //   </div>
            //   <div className={'d-flex justify-content-center align-items-center cursor-pointer'}>
            //   <svg
            //  version="1.1"
            //  xmlns="http://www.w3.org/2000/svg"
            //  xmlnsXlink="http://www.w3.org/1999/xlink"
            //  viewBox="0 0 64 54"
            //  xmlSpace="preserve"
            //  className='w-50'
            //   >
            //  <g>
            //  <rect
            //  x={2}
            //  y={2}
            //  width={60}
            //  rx={5}
            //  height={50}
            //  fill="transparent"
            //  strokeWidth={3}
            //  stroke="#727272"
            //  />
            //  <path d="M21 52 L 21 2" strokeWidth={3} stroke="#727272" />
            //  <path d="M42 52 L 42 2" strokeWidth={3} stroke="#727272" />
            //  </g>
            //   </svg>
            //   </div>
            //   </div>

            //   </>
        } else if (selectedType === "block") {
            styles = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Background Fill</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className='p-0 mb-1 justify-content-start align-items-center'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Solid Color</span>
                                        {/* <input
                                                    type="color"
                                                    className="w-100"
                                                    name="backgroundColor"
                                                    onChange={e => {
                                                        arr[indexes.cur].elements[positionIndex].element[indexes.subElem].style.backgroundColor = e.target.value
                                                        setcolWise([...arr])
                                                    }}
                                                // defaultValue={activeData.label}
                                                /> */}
                                        <div className="p-2 border rounded" onClick={() => setBgModal0(!bgModal0)} style={{ backgroundColor: values?.backgroundColor, backgroundImage: values?.backgroundImage }}></div>
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='2' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Border and Shadow</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='2'>
                                {/* <div className='p-0 mx-0 my-1'>
                                        <div className='p-0 mb-1 justify-content-start align-items-center'>
                                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Border:</span>
                                            <Select options={[
                                                { value: 'none', label: 'None' },
                                                { value: 'full', label: 'Full' },
                                                { value: 'top', label: 'Top' },
                                                { value: 'bottom', label: 'Bottom' },
                                                { value: 'left', label: 'Left' },
                                                { value: 'topbottom', label: 'Top bottom' }
                                            ]} />
                                        </div>
                                        <div className='d-flex flex-column text-start '>
                                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem", marginBottom: '0.25rem' }}>Corner radius:</span>
                                            <div className='d-flex p-0 mb-1 justify-content-between align-items-center'>
                                                <span className=' w-75 fw-bolder text-black' style={{ fontSize: "0.65rem", flexWrap: 'wrap' }}>Use Custom theme rounding:</span>
                                                <div className=" form-check form-switch form-check-dark m-0 p-0" style={{ transform: 'scale(0.8)' }}>
                                                    <input className="form-check-input" type="checkbox" id="flexSwitchCheckChecked" />
                                                </div>
                                            </div>
                                            <div className='match-height m-auto' style={{ aspectRatio: '1', gridTemplateColumns: '1fr 1fr 1fr', display: 'grid', width: '150px' }}>
                                                <div className="p-0 m-0 text-center">
                                                    <input type="number" min="0" step="1" placeholder="0" className="form-control w-100" />
                                                </div>
                                                <div></div>
                                                <div className="flex-grow-1 text-center">
                                                    <input type="number" min="0" step="1" placeholder="0" className="form-control" />
                                                </div>
                                                <div></div>
                                                <div className="d-flex justify-content-center align-items-center mb-1 m-0 p-0">
                                                    <Link2 size={18} strokeWidth={2.5} style={{ transform: 'rotate(-45deg)' }} />
                                                </div>
                                                <div></div>
                                                <div className="flex-grow-1 text-center">
                                                    <input type="number" min="0" step="1" placeholder="0" className="form-control" />
                                                </div>
                                                <div></div>
                                                <div className="flex-grow-1 text-center">
                                                    <input type="number" min="0" step="1" placeholder="0" className="form-control" />
                                                </div>
                                            </div>
                                        </div>
                                        <div className='p-0 mb-1 justify-content-start align-items-center'>
                                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Shadow:</span>
                                            <Select options={[
                                                { value: 'none', label: 'None' },
                                                { value: 'normal', label: 'Normal' },
                                                { value: 'medium', label: 'Medium' },
                                                { value: 'large', label: 'Large' }
                                            ]} />
                                        </div>
                                    </div> */}
                                <BorderChange styles={values} setStyles={setValues} />
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='3' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Size</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='3'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className="p-0 justify-content-start align-items-center gap-2">
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Min-height:</span>
                                        <input type="number" name='minHeight' min="0" max="300" className='w-100 form-control' />
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>

                    </UncontrolledAccordion>
                </>
            )
            general = (
                <div className={`h-100 d-flex flex-column justify-content-between`}>
                    <div>
                        {/* Column Count Starts */}
                        <h6 style={{ marginLeft: "7px", marginTop: "10px" }}>Column Count</h6>
                        <div className='d-flex justify-content-around align-items-center'>
                            <button className="btn p-0 d-flex justify-content-center align-items-center" onClick={() => changeColumn("1", { left: "100%", right: "0%" })} style={{ aspectRatio: "1", width: "50px" }}>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                    <rect
                                        x={2}
                                        y={2}
                                        width={60}
                                        rx={5}
                                        height={50}
                                        fill="transparent"
                                        strokeWidth={3}
                                        stroke="#727272"
                                    />
                                </svg>
                            </button>
                            <button className="btn p-0 d-flex justify-content-center align-items-center" onClick={() => changeColumn("2", { left: "50%", right: "50%" })} style={{ aspectRatio: "1", width: "50px" }}>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                    <g strokeWidth={3} stroke="#727272">
                                        <rect x={2} y={2} width={60} rx={5} height={50} fill="transparent" />
                                        <path d="M32 52V2" />
                                    </g>
                                </svg>
                            </button>
                            <button className="btn p-0 d-flex justify-content-center align-items-center" onClick={() => changeColumn("3", { left: "33%", center: "33%", right: "33%" })} style={{ aspectRatio: "1", width: "50px" }}>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                    <g strokeWidth={3} stroke="#727272">
                                        <rect x={2} y={2} width={60} rx={5} height={50} fill="transparent" />
                                        <path d="M21 52V2M42 52V2" />
                                    </g>
                                </svg>
                            </button>
                        </div>
                        {/* Column Count Ends*/}
                        {/* Column Split Starts*/}
                        {/* Column Split For 2 Columns Starts*/}
                        {colWise[indexes.cur]?.elements?.length === 2 && (
                            <div>
                                <h6 style={{ marginLeft: "7px", marginTop: "20px" }}>Column Split</h6>
                                <div className='d-flex justify-content-around align-items-center'>
                                    <button onClick={() => changeColumn("2", { left: "25%", right: "75%" })} className="btn p-0 d-flex justify-content-center align-items-center" style={{ aspectRatio: "1", width: "50px" }}>
                                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                            <g strokeWidth="3" stroke="#727272">
                                                <rect x="2" y="2" width="60" rx="5" height="50" fill="transparent" ></rect>
                                                <path d="M16 52 L 16 2"></path>
                                            </g>
                                        </svg>
                                    </button>
                                    <button onClick={() => changeColumn("2", { left: `${100 / 3}%`, right: `${200 / 3}%` })} className="btn p-0 d-flex justify-content-center align-items-center" style={{ aspectRatio: "1", width: "50px" }}>
                                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                            <g strokeWidth="3" stroke="#727272">
                                                <rect x="2" y="2" width="60" rx="5" height="50" fill="transparent" ></rect>
                                                <path d="M21 52 L 21 2"></path>
                                            </g>
                                        </svg>
                                    </button>
                                    <button onClick={() => changeColumn("2", { left: `${(250 * 100) / 600}%`, right: `${(350 * 100) / 600}%` })} className="btn p-0 d-flex justify-content-center align-items-center" style={{ aspectRatio: "1", width: "50px" }}>
                                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                            <g strokeWidth="3" stroke="#727272">
                                                <rect x="2" y="2" width="60" rx="5" height="50" fill="transparent" ></rect>
                                                <path d="M26 52 L 26 2" ></path>
                                            </g>
                                        </svg>
                                    </button>
                                </div>
                                <div className='d-flex justify-content-around align-items-center'>
                                    <button onClick={() => changeColumn("2", { left: "50%", right: "50%" })} className="btn p-0 d-flex justify-content-center align-items-center" style={{ aspectRatio: "1", width: "50px" }}>
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                            <g strokeWidth={3} stroke="#727272">
                                                <rect x={2} y={2} width={60} rx={5} height={50} fill="transparent" />
                                                <path d="M32 52V2" />
                                            </g>
                                        </svg>
                                    </button>
                                    <button onClick={() => changeColumn("2", { left: `${(350 * 100) / 600}%`, right: `${(250 * 100) / 600}%` })} className="btn p-0 d-flex justify-content-center align-items-center" style={{ aspectRatio: "1", width: "50px" }}>
                                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                            <g strokeWidth="3" stroke="#727272">
                                                <rect x="2" y="2" width="60" rx="5" height="50" fill="transparent" ></rect>
                                                <path d="M37 52 L 37 2"></path>
                                            </g>
                                        </svg>
                                    </button>
                                    <button onClick={() => changeColumn("2", { left: `${200 / 3}%`, right: `${100 / 3}%` })} className="btn p-0 d-flex justify-content-center align-items-center" style={{ aspectRatio: "1", width: "50px" }}>
                                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                            <g strokeWidth="3" stroke="#727272">
                                                <rect x="2" y="2" width="60" rx="5" height="50" fill="transparent" ></rect>
                                                <path d="M42 52 L 42 2" ></path>
                                            </g>
                                        </svg>
                                    </button>
                                </div>
                                <div className='d-flex justify-content-start align-items-center' style={{ marginLeft: "14.5px" }}>
                                    <button onClick={() => changeColumn("2", { left: "75%", right: "25%" })} className="btn p-0 d-flex justify-content-center align-items-center" style={{ aspectRatio: "1", width: "50px" }}>
                                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                            <g strokeWidth="3" stroke="#727272">
                                                <rect x="2" y="2" width="60" rx="5" height="50" fill="transparent" ></rect>
                                                <path d="M48 52 L 48 2"></path>
                                            </g>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        )}
                        {/* Column Split for 2 Columns Ends */}
                        {/* Column Split for 3 Columns Starts */}
                        {colWise[indexes?.cur]?.elements?.length === 3 && (
                            <div>
                                <h6 style={{ marginLeft: "7px", marginTop: "20px" }}>Column Split</h6>
                                <div className='d-flex justify-content-around align-items-center'>
                                    <button onClick={() => changeColumn("3", { left: `100%`, center: `100%`, right: `100%` })} className="btn p-0 d-flex justify-content-center align-items-center" style={{ aspectRatio: "1", width: "50px" }}>
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                            <g strokeWidth={3} stroke="#727272">
                                                <rect x={2} y={2} width={60} rx={5} height={50} fill="transparent" />
                                                <path d="M21 52V2M42 52V2" />
                                            </g>
                                        </svg>
                                    </button>
                                    <button onClick={() => changeColumn("3", { left: `${100 / 2}%`, center: `${100 / 4}%`, right: `${100 / 4}%` })} className="btn p-0 d-flex justify-content-center align-items-center" style={{ aspectRatio: "1", width: "50px" }}>
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                            <g strokeWidth={3} stroke="#727272">
                                                <rect x="2" y="2" width="60" rx="5" height="50" fill="transparent"></rect>
                                                <path d="M32 52 L 32 2"></path>
                                                <path d="M48 52 L 48 2"></path>
                                            </g>
                                        </svg>
                                    </button>
                                    <button onClick={() => changeColumn("3", { left: `${100 / 4}%`, center: `${100 / 2}%`, right: `${100 / 4}%` })} className="btn p-0 d-flex justify-content-center align-items-center" style={{ aspectRatio: "1", width: "50px" }}>
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                            <g strokeWidth={3} stroke="#727272">
                                                <rect x="2" y="2" width="60" rx="5" height="50" fill="transparent" ></rect>
                                                <path d="M16 52 L 16 2" ></path>
                                                <path d="M48 52 L 48 2" ></path>
                                            </g>
                                        </svg>
                                    </button>
                                </div>
                                <div className='d-flex justify-content-start align-items-center' style={{ marginLeft: "14.5px" }}>
                                    <button onClick={() => changeColumn("3", { left: `${100 / 4}%`, center: `${100 / 4}%`, right: `${100 / 2}%` })} className="btn p-0 d-flex justify-content-center align-items-center" style={{ aspectRatio: "1", width: "50px" }}>
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 54" className='w-75'>
                                            <g strokeWidth={3} stroke="#727272">
                                                <rect x="2" y="2" width="60" rx="5" height="50" fill="transparent" ></rect>
                                                <path d="M16 52 L 16 2" ></path>
                                                <path d="M32 52 L 32 2" ></path>
                                            </g>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        )}
                        {/* Column Split for 3 Columns Ends */}
                        {/* Column Split Ends */}
                    </div>
                    <div className="p-1">
                        {colWise?.[indexes?.cur]?.elements?.map((curElem) => {
                            return (
                                <button onClick={() => {
                                    setValues({ ...colWise[indexes?.cur]?.elements[colWise[indexes?.cur]?.elements?.findIndex($ => $?.positionType === curElem?.positionType)]?.style })
                                    setIndexes({ cur: indexes?.cur, curElem: curElem?.positionType, subElem: "parent" })
                                    setCurrPosition({ ...currPosition, selectedType: "column" })
                                }} className="btn btn-outline-dark w-100 text-capitalize mb-1 text-start">
                                    {colWise[indexes?.cur].elements?.length > 1 ? curElem?.positionType : ""} column
                                </button>
                            )
                        })}
                    </div>
                </div>
            )
            advanced = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Spacing</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <InputChange
                                        allValues={values}
                                        setAllValues={setValues}
                                        type="padding"
                                    />
                                    <InputChange
                                        allValues={values}
                                        setAllValues={setValues}
                                        type="margin"
                                    />
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
        } else if (selectedType === "input") {
            const arr = [...colWise]
            const positionIndex = colWise[indexes?.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)
            styles = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3', '4']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Font</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className='p-0 mb-2 justify-content-start align-items-center'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Select Font:</span>
                                        <Select className='w-100' name="" onChange={e => {
                                            setValues({ ...values, fontFamily: e.value })
                                        }} id="" options={fontStyles} />
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='2' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Display</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='2'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className='p-0 mb-2 justify-content-start align-items-center'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Width:</span>
                                        <Select className='w-100' name="" onChange={e => {
                                            if (e.value === "100%") {
                                                setValues({ ...values, widthType: e.value, width: e.value, minHeight: "0px", padding: "10px" })
                                            } else if (e.value === "custom") {
                                                setValues({ ...values, widthType: e.value, padding: "10px" })
                                            }
                                        }} id="" options={[
                                            { value: '100%', label: '100%' },
                                            { value: 'custom', label: 'Custom' }
                                        ]} />
                                    </div>
                                    {values?.widthType === "custom" && <div className='mb-2'>
                                        <p className='fw-bolder text-black mb-1' style={{ fontSize: "0.75rem" }}>Width: {values?.width}</p>
                                        <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                            <input value={parseFloat(values?.width)} type='range' className='w-100' onChange={e => {
                                                setValues({ ...values, width: `${e.target.value}px` })
                                            }} name="height" min="20" max="600" />
                                        </div>
                                    </div>}
                                    <div className='mb-2'>
                                        <p className='fw-bolder text-black mb-1' style={{ fontSize: "0.75rem" }}>Height: {values?.minHeight}</p>
                                        <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                            <input value={parseFloat(values?.minHeight)} type='range' className='w-100' onChange={e => {
                                                setValues({ ...values, minHeight: `${e.target.value}px` })
                                            }} name="height" min="0" max="600" />
                                        </div>
                                    </div>

                                    {values.widthType !== "100%" && (<>
                                        <p className='fw-bolder text-black mb-1' style={{ fontSize: "0.75rem" }}>Alignment:</p>
                                        <div className="blocks d-flex gap-1">
                                            <div onClick={() => setValues({ ...values, alignType: "left" })} className={`cursor-pointer rounded w-100 text-center border-${values?.alignType === "left" ? "black" : "dark"}`} style={{ padding: "0.5rem", aspectRatio: "1" }}>
                                                <div>
                                                    <svg
                                                        width="1.25rem"
                                                        height="1.25rem"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24"
                                                        fill={values?.alignType === "left" ? "black" : "#464646"}
                                                    >
                                                        <path d="M21,10H16V7a1,1,0,0,0-1-1H4V3A1,1,0,0,0,2,3V21a1,1,0,0,0,2,0V18H21a1,1,0,0,0,1-1V11A1,1,0,0,0,21,10ZM4,8H14v2H4Zm16,8H4V12H20Z" />
                                                    </svg>
                                                </div>
                                                <div>
                                                    <span className={`text-${values?.alignType === "left" ? "black" : "dark"}`}>Left</span>
                                                </div>
                                            </div>
                                            <div onClick={() => setValues({ ...values, alignType: "center" })} className={`cursor-pointer rounded w-100 text-center border-${values?.alignType === "center" ? "black" : "dark"}`} style={{ padding: "0.5rem", aspectRatio: "1" }}>
                                                <div>
                                                    <svg
                                                        width="1.25rem"
                                                        height="1.25rem"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24"
                                                        fill={values?.alignType === "center" ? "black" : "#464646"}
                                                    >
                                                        <path d="M21,10H19V7a1,1,0,0,0-1-1H13V3a1,1,0,0,0-2,0V6H6A1,1,0,0,0,5,7v3H3a1,1,0,0,0-1,1v6a1,1,0,0,0,1,1h8v3a1,1,0,0,0,2,0V18h8a1,1,0,0,0,1-1V11A1,1,0,0,0,21,10ZM7,8H17v2H7Zm13,8H4V12H20Z" />
                                                    </svg>
                                                </div>
                                                <div>
                                                    <span className={`text-${values?.alignType === "center" ? "black" : "dark"}`}>Center</span>
                                                </div>
                                            </div>
                                            <div onClick={() => setValues({ ...values, alignType: "right" })} className={`cursor-pointer rounded w-100 text-center border-${values?.alignType === "right" ? "black" : "dark"}`} style={{ padding: "0.5rem", aspectRatio: "1" }}>
                                                <div>
                                                    <svg
                                                        width="1.25rem"
                                                        height="1.25rem"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24"
                                                        fill={values.alignType === "right" ? "black" : "#464646"}
                                                    >
                                                        <path d="M21,2a1,1,0,0,0-1,1V6H9A1,1,0,0,0,8,7v3H3a1,1,0,0,0-1,1v6a1,1,0,0,0,1,1H20v3a1,1,0,0,0,2,0V3A1,1,0,0,0,21,2ZM20,16H4V12H20Zm0-6H10V8H20Z" />
                                                    </svg>
                                                </div>
                                                <div>
                                                    <span className={`text-${values?.alignType === "right" ? "black" : "dark"}`}>Right</span>
                                                </div>
                                            </div>
                                        </div>
                                    </>)}
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='3' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Background Fill</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='3'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className='p-0 mb-1 justify-content-start align-items-center'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Solid Color:</span>
                                        <div className="border rounded" style={{ backgroundImage: `url(${pixels})` }}>
                                            <div className="p-1" style={{ backgroundColor: values?.backgroundColor, backgroundImage: values?.backgroundImage, backgroundRepeat: values?.backgroundRepeat, backgroundSize: values?.backgroundSize }} onClick={() => setBgModal0(!bgModal0)}></div>
                                        </div>
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='4' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Border and Shadow</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='4'>
                                <BorderChange setStyles={setValues} styles={values} />
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
            general = (
                <>
                    <div className='p-1 mx-0 my-0'>
                        <div className='mt-0'>
                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Type:</span>
                            <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                <Select value={inputTypeList?.filter(item => item?.value === arr[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.inputType)} className='w-100' name="" id=""
                                    onChange={e => {
                                        arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].inputType = e.value
                                        arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].placeholder = e.label
                                        arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].labelText = e.label
                                        setcolWise([...arr])
                                    }} options={inputTypeList?.filter(item => !draggedTypes?.includes(item?.value))} />
                            </div>
                        </div>
                        <div className='my-2'>
                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Placeholder:</span>
                            <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                <input value={colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.placeholder} onChange={e => {
                                    arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].placeholder = e.target.value
                                    setcolWise([...arr])
                                }} type="text" name='title' min="0" max="300" className='form-control' />
                            </div>
                        </div>
                        <div className='my-2'>
                            <div className="d-flex p-0 justify-content-between align-items-center gap-3 form-check">
                                <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Show Label:</span>
                                <input checked={colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.hasLabel} onChange={e => {
                                    arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].hasLabel = e.target.checked
                                    setcolWise([...arr])
                                }} type="checkbox" name='title' min="0" max="300" className='form-check-input' />
                            </div>
                        </div>
                        {colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.hasLabel && <div className='my-2'>
                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Label Text:</span>
                            <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                <input value={colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.labelText} onChange={e => {
                                    arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].labelText = e.target.value
                                    setcolWise([...arr])
                                }} type="text" name='title' min="0" max="300" className='form-control' />
                            </div>
                        </div>}
                        <div className='d-flex p-0 my-1 justify-content-between gap-3 align-items-center'>
                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Required?</span>
                            <div className="form-check m-0 p-0">
                                <input checked={colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.isRequired} onChange={e => {
                                    arr[indexes?.cur].elements[positionIndex].element[indexes?.subElem].isRequired = e.target.checked
                                    setcolWise([...arr])
                                }} className="form-check-input m-0" type="checkbox" id="flexSwitchCheckChecked" />
                            </div>
                        </div>
                        {colWise[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.isRequired && <div className='my-1'>
                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Error message:</span>
                            <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                <input type="text" name='title' min="0" max="300" className='form-control' />
                            </div>
                        </div>}
                    </div>
                </>
            )
            advanced = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Spacing</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <InputChange
                                        allValues={values}
                                        setAllValues={setValues}
                                        type="margin"
                                    />
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
        } else if (selectedType === "cross") {
            styles = (
                <div className='mx-0 my-1 px-1'>
                    <div className='d-flex p-0 mb-1 justify-content-between align-items-center '>
                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Close when "Esc" is pressed</span>
                        <div className="form-check form-switch form-check-dark m-0 p-0" style={{ transform: 'scale(0.8)' }}>
                            <input className="form-check-input cursor-pointer" checked={finalObj?.closePopUpOn?.escape} onChange={e => {
                                setFinalObj({ ...finalObj, closePopUpOn: { ...finalObj?.closePopUpOn, escape: e.target.checked } })
                            }} type="checkbox" id="flexSwitchCheckChecked" />
                        </div>
                    </div>
                    <div className='d-flex p-0 mb-1 justify-content-between align-items-center '>
                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Close when overlay is clicked</span>
                        <div className="form-check form-switch form-check-dark m-0 p-0" style={{ transform: 'scale(0.8)' }}>
                            <input className="form-check-input cursor-pointer" checked={finalObj?.closePopUpOn?.overlay} onChange={e => {
                                setFinalObj({ ...finalObj, closePopUpOn: { ...finalObj?.closePopUpOn, overlay: e.target.checked } })
                            }} type="checkbox" id="flexSwitchCheckChecked" />
                        </div>
                    </div>
                    {/* <div className="sidebar-device-chooser">
                        <p className='fw-bolder text-black mb-1' style={{ fontSize: "0.75rem" }}>Alignment:</p>
                        <div className="blocks d-flex gap-1">
                            <div className='cursor-pointer rounded w-100 text-center border-primary' style={{ padding: "0.5rem", aspectRatio: "1" }}>
                                <div>
                                    <Monitor size={15} />
                                </div>
                                <div>
                                    <span className='text-black'>Desktop</span>
                                </div>
                            </div>
                            <div className='cursor-pointer rounded w-100 text-center border-dark' style={{ padding: "0.5rem", aspectRatio: "1" }}>
                                <div>
                                    <Smartphone size={15} />
                                </div>
                                <div>
                                    <span className='text-dark'>Mobile</span>
                                </div>
                            </div>
                            <div className='cursor-pointer rounded w-100 text-center border-dark' style={{ padding: "0.5rem", aspectRatio: "1" }}>
                                <div>
                                    <Monitor size={15} />
                                    <Smartphone size={15} />
                                </div>
                                <div>
                                    <span className='text-dark'>Both devices</span>
                                </div>
                            </div>
                        </div>

                    </div> */}
                    <div className='p-0 my-1'>
                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Background Color</span>
                        <div className="rounded border" style={{ backgroundImage: `url(${pixels})` }}>
                            <div className="p-2" style={{ backgroundColor: finalObj?.crossButtons?.[`${mobileCondition}main`]?.backgroundColor, backgroundImage: finalObj?.crossButtons?.[`${mobileCondition}main`]?.backgroundImage }} onClick={() => {
                                setColorType("backgroundColor")
                                setCustomColorModal(!customColorModal)
                            }}></div>
                        </div>

                        <div className="d-flex align-items-center justify-content-between gap-1 form-check form-check-success m-0 p-0">
                            <label style={{ fontSize: "10px" }} className="form-check-label m-0 p-0">Keep same background colour for {isMobile ? "desktop theme" : "mobile theme"}</label>
                            <input
                                checked={finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, "cross"))]?.common?.includes("backgroundColor")}
                                type='checkbox' className='form-check-input m-0 p-0' onChange={(e) => {
                                    const newObj = { ...finalObj }
                                    if (e.target.checked) {
                                        if (finalObj?.responsive?.some($ => isEqual($?.position, "cross"))) {
                                            const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, "cross"))
                                            newObj.responsive[responiveIndex]?.common?.push("backgroundColor")
                                        } else {
                                            newObj?.responsive?.push({ position: "cross", common: ["backgroundColor"], page: currPage })
                                        }
                                    } else {
                                        const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, "cross"))
                                        newObj.responsive[responiveIndex].common = newObj?.responsive[responiveIndex]?.common?.filter(item => item !== "backgroundColor")
                                    }
                                    setFinalObj({ ...newObj })
                                }} />
                        </div>
                    </div>
                    <div className='p-0 my-1'>
                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>X Color</span>
                        <div className="rounded border" style={{ backgroundImage: `url(${pixels})` }}>
                            <div className="p-2" style={{ backgroundColor: finalObj?.crossButtons?.[`${mobileCondition}main`]?.color }} onClick={() => {
                                setColorType("color")
                                setCustomColorModal(!customColorModal)
                            }}></div>
                        </div>
                    </div>
                    <div className='my-1'>
                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Size: {crossStyle?.width}</span>
                        <div className="p-0 justify-content-start align-items-center gap-2">
                            <input value={parseFloat(crossStyle?.width)} type='range' className='w-100' name="height" min="5" max="300"
                                onChange={(e) => {
                                    setCrossStyle({ ...crossStyle, width: `${e.target.value}px`, height: `${e.target.value}px`, maxWidth: `${e.target.value}px`, maxHeight: `${e.target.value}px` })
                                }} />
                        </div>
                    </div>
                    {/* <div className="d-flex justify-content-between my-1" style={{ alignItems: "flex-end" }}>
                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Style:</span>
                        <div className="d-flex flex-row flex-0">
                            <button data-v-6f3bf591="" type="button" aria-hidden="true" className="me-1 btn btn-link design-system" style={{ minWidth: "0rem", padding: "unset" }}>
                                <span data-v-6f3bf591="" className="d-inline-flex justify-content-center align-items-center">
                                    <Bold size={18} />
                                </span>
                            </button>
                            <button data-v-6f3bf591="" type="button" aria-hidden="true" className="me-1 btn btn-link design-system" style={{ minWidth: "0rem", padding: "unset" }}>
                                <span data-v-6f3bf591="" className="d-inline-flex justify-content-center align-items-center">
                                    <Italic size={18} />
                                </span>
                            </button>
                            <button data-v-6f3bf591="" type="button" aria-hidden="true" className=" btn btn-link design-system selected" style={{ minWidth: "0rem", padding: "unset" }}>
                                <span data-v-6f3bf591="" className="d-inline-flex justify-content-center align-items-center">
                                    <Underline size={18} />
                                </span>
                            </button>
                        </div>
                    </div> */}
                    <div className='my-1'>
                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Corner radius: {crossStyle?.borderRadius}</span>
                        <div className=" p-0 justify-content-start align-items-center gap-2">
                            <input value={parseFloat(crossStyle?.borderRadius)} type='range' className='w-100' name="height" min="0" max="300"
                                onChange={(e) => {
                                    // const newSize = parseInt(e.target.value)
                                    setCrossStyle({ ...crossStyle, borderRadius: `${e.target.value}px` })
                                }} />
                        </div>
                    </div>
                </div>
            )
            advanced = (
                <>
                    <div className='mx-0 my-1 px-1'>
                        <div className=''>
                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Vertical alignment: {crossStyle?.translateY}</span>
                            <div className=" p-0 justify-content-start align-items-center gap-2">
                                <input value={parseFloat(crossStyle?.translateY)} onChange={e => setCrossStyle({ ...crossStyle, translateY: `${e.target.value}px` })} type='range' className='w-100' name="height" min="-50" max="50" />
                                {/* <input type="number" name='height' onChange={e => {
                                    // updateValues(e)
                                    if (!isNaN(e.target.value)) {
                                    arr[indexes.cur].elements[positionIndex].element[indexes.subElem].style.rotate =  `${e.target.value}deg`
                                    setcolWise([...arr])
                                    }
                                }} min="0" max="50" className='w-50 form-control' /> */}
                            </div>
                        </div>
                        <div className='my-1'>
                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Horizontal alignment: {crossStyle?.translateX}</span>
                            <div className="p-0 justify-content-start align-items-center gap-2">
                                <input value={parseFloat(crossStyle?.translateX)} onChange={e => setCrossStyle({ ...crossStyle, translateX: `${e.target.value}px` })} type='range' className='w-100' name="height" min="-50" max="50" />
                                {/* <input type="number" name='height' onChange={e => {
                                    // updateValues(e)
                                    if (!isNaN(e.target.value)) {
                                    arr[indexes.cur].elements[positionIndex].element[indexes.subElem].style.rotate =  `${e.target.value}deg`
                                    setcolWise([...arr])
                                    }
                                }} min="0" max="360" className='w-50 form-control' /> */}
                            </div>
                        </div>
                        {/* <div className='p-0 mb-1 justify-content-start align-items-center'>
                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Visiblity delay:</span>
                            <Select className='w-100 form-select'>
                                    {options}
                                </Select>
                        </div> */}
                    </div>
                </>
            )
        } else if (selectedType === "teaser") {
            styles = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black' style={{ padding: "0.5rem 0.5rem 0px", fontSize: "0.9rem" }}>Background Fill</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className=' p-0 justify-content- align-items-center gap-1'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Background:</span>
                                        <div className=" rounded border cursor-pointer" style={{ backgroundImage: `url(${pixels})` }}>
                                            <div onClick={() => setBgModal3(!bgModal3)} className="p-2 w-100" style={{ backgroundColor: btnStyles?.backgroundColor, backgroundImage: btnStyles?.backgroundImage }}></div>
                                        </div>
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='2' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black' style={{ padding: "0.5rem 0.5rem 0px", fontSize: "0.9rem" }}>Size</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='2'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className='mb-1'>
                                        <span className='fw-bolder text-black text-capitalize' style={{ fontSize: "0.75rem" }}>{isMobile ? "Max Width" : "Width"}: {btnStyles?.[isMobile ? "maxWidth" : "width"]}</span>
                                        <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                            <input type='range'
                                                value={parseFloat(btnStyles?.[isMobile ? "maxWidth" : "width"])}
                                                className='w-100' onChange={e => {
                                                    setBtnStyles({ ...btnStyles, [e.target.name]: `${e.target.value}${isMobile ? "%" : "px"}` })
                                                }} name={isMobile ? "maxWidth" : "width"} min="25" max={isMobile ? "100" : "600"} />
                                        </div>
                                    </div>
                                    <div className=''>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Min-Height: {btnStyles?.minHeight}</span>
                                        <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                            <input type='range' value={parseFloat(btnStyles?.minHeight)} onChange={e => {
                                                setBtnStyles({ ...btnStyles, minHeight: `${e.target.value}px` })
                                            }} className='w-100' name="height" min="50" max="650" />
                                        </div>
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='3' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black' style={{ padding: "0.5rem 0.5rem 0px", fontSize: "0.9rem" }}>Border and Shadow</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='3'>
                                <BorderChange styles={btnStyles} setStyles={setBtnStyles} />
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
            advanced = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Spacing</span>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <InputChange allValues={btnStyles} setAllValues={setBtnStyles} type='padding' />
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
        } else if (selectedType === "column") {
            const arr = [...colWise]
            const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes.curElem)
            const alignOptions = [{ value: "start", label: "Top" }, { value: "center", label: "Middle" }, { value: "end", label: "Bottom" }]
            styles = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Background Fill</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className=' p-0 justify-content- align-items-center gap-1'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Background:</span>
                                        <div className=" rounded border cursor-pointer" style={{ backgroundImage: `url(${pixels})` }}>
                                            <div onClick={() => setBgModal0(!bgModal0)} className="p-2 w-100" style={{ backgroundColor: values?.backgroundColor, backgroundImage: values?.backgroundImage }}></div>
                                        </div>
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='2' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Border and Shadow</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='2'>
                                <BorderChange styles={values} setStyles={setValues} />
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='3' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Content</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='3'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className=' p-0 justify-content- align-items-center gap-1'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Vertical Alignment:</span>
                                        <Select value={alignOptions?.filter(item => item.value === colWise[indexes.cur]?.elements[positionIndex]?.style?.justifyContent)} onChange={e => {
                                            if (arr[indexes.cur].elements[positionIndex].style.justifyContent) {
                                                arr[indexes.cur].elements[positionIndex].style.justifyContent = e.value
                                            }
                                            setcolWise([...arr])
                                        }} options={alignOptions} />
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
            advanced = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Spacing</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <InputChange
                                        allValues={values}
                                        setAllValues={setValues}
                                        type="padding"
                                    />
                                    <InputChange
                                        allValues={values}
                                        setAllValues={setValues}
                                        type="margin"
                                    />
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
        } else if (selectedType === "offer") {
            // const arr = [...colWise]
            // const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes.curElem)
            general = (
                <>
                    <UncontrolledAccordion stayOpen defaultOpen={['1', '2', '3', '4']}>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Offer Settings</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                {/* <div className='p-0 mx-0 my-1'>
                                    <div className="form-check form-check-success">
                                        <div className="d-flex align-items-center gap-1 mb-1">
                                            <input onChange={() => {
                                                if (finalObj?.offerProperties?.showSections?.includes("usage")) {
                                                    setFinalObj({ ...finalObj, offerProperties: { ...finalObj?.offerProperties, showSections: [...finalObj?.offerProperties?.showSections]?.filter($ => $ !== "usage") } })
                                                } else {
                                                    setFinalObj({ ...finalObj, offerProperties: { ...finalObj?.offerProperties, showSections: [...finalObj?.offerProperties?.showSections, "usage"] } })

                                                }
                                            }} checked={finalObj?.offerProperties?.showSections?.includes("usage")} id='visible-offer-usage' type="checkbox" className="form-check-input" />
                                            <label htmlFor="visible-offer-usage" className="form-check-label">Usage</label>
                                        </div>
                                        <div className="d-flex align-items-center gap-1 mb-1">
                                            <input onChange={() => {
                                                if (finalObj?.offerProperties?.showSections?.includes("validity")) {
                                                    setFinalObj({ ...finalObj, offerProperties: { ...finalObj?.offerProperties, showSections: [...finalObj?.offerProperties?.showSections]?.filter($ => $ !== "validity") } })
                                                } else {
                                                    setFinalObj({ ...finalObj, offerProperties: { ...finalObj?.offerProperties, showSections: [...finalObj?.offerProperties?.showSections, "validity"] } })

                                                }
                                            }} checked={finalObj?.offerProperties?.showSections?.includes("validity")} id='visible-offer-validity' type="checkbox" className="form-check-input" />
                                            <label htmlFor="visible-offer-validity" className="form-check-label">Validity</label>
                                        </div>
                                        <div className="d-flex align-items-center gap-1 mb-1">
                                            <input onChange={() => {
                                                if (finalObj?.offerProperties?.showSections?.includes("description")) {
                                                    setFinalObj({ ...finalObj, offerProperties: { ...finalObj?.offerProperties, showSections: [...finalObj?.offerProperties?.showSections]?.filter($ => $ !== "description") } })
                                                } else {
                                                    setFinalObj({ ...finalObj, offerProperties: { ...finalObj?.offerProperties, showSections: [...finalObj?.offerProperties?.showSections, "description"] } })

                                                }
                                            }} checked={finalObj.offerProperties.showSections.includes("description")} id='visible-offer-description' type="checkbox" className="form-check-input" />
                                            <label htmlFor="visible-offer-description" className="form-check-label">Description</label>
                                        </div>
                                    </div>
                                </div> */}
                                <div className='p-0 mx-0 my-1'>
                                    <button className="btn btn-primary w-100" onClick={() => setOffersModal(!offersModal)}>Change offer design</button>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
            styles = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Display</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className='mb-2'>
                                        <p className='fw-bolder text-black mb-1' style={{ fontSize: "0.75rem" }}>Width: {values?.width}</p>
                                        <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                            <input type='range' className='w-100' onChange={e => {
                                                setValues({ ...values, width: `${e.target.value}px` })
                                            }} name="height" min="300" max="600" />
                                        </div>
                                    </div>
                                    <div className='mb-2'>
                                        <p className='fw-bolder text-black mb-1' style={{ fontSize: "0.75rem" }}>Max Height: {values?.maxHeight}</p>
                                        <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                            <input type='range' className='w-100' onChange={e => {
                                                setValues({ ...values, maxHeight: `${e.target.value}px` })
                                            }} name="height" min="0" max="600" />
                                        </div>
                                    </div>
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                        <AccordionItem>
                            <AccordionHeader className='acc-header' targetId='2' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Colors</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='2'>
                                <div className='p-0 mx-0 my-1'>
                                    <div className='p-0 mb-1 justify-content-start align-items-center'>
                                        <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Solid Color:</span>
                                        <div style={{ backgroundImage: `url(${pixels})` }}>
                                            <div className="border p-1 rounded" style={{ backgroundColor: values?.backgroundColor, backgroundImage: values?.backgroundImage }} onClick={() => setBgModal0(!bgModal0)}></div>
                                        </div>
                                    </div>
                                    {Object.entries(finalObj?.offerProperties?.colors)?.map(([key, value], index) => {
                                        return (
                                            <div key={index} className='p-0 mb-1 justify-content-start align-items-center'>
                                                <span className='fw-bolder text-black text-capitalize' style={{ fontSize: "0.75rem" }}>{key.split("_")[0]} {key.split("_")[1]}:</span>
                                                <div style={{ backgroundImage: `url(${pixels})` }}>
                                                    <div className="border p-1 rounded" style={{ backgroundColor: value }} onClick={() => {
                                                        setCurrOfferColor(key)
                                                        setBgModal4(!bgModal4)
                                                    }}></div>
                                                </div>
                                            </div>
                                        )
                                    })}
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
            advanced = (
                <UncontrolledAccordion defaultOpen={["1"]}>
                    <AccordionItem>
                        <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                            <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Spacing</span>
                        </AccordionHeader>
                        <AccordionBody accordionId='1'>
                            <div className='p-0 mx-0 my-1'>
                                <InputChange allValues={values} setAllValues={setValues} type='padding' />
                            </div>
                        </AccordionBody>
                    </AccordionItem>
                </UncontrolledAccordion>
            )
        } else if (selectedType === "brand") {
            console.log("brand")
            styles = (
                <>This is Brand Style</>
            )
            general = (
                <>
                    <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
                        <AccordionItem className='bg-white border-bottom'>
                            <AccordionHeader className='acc-header border-bottom' targetId='1'>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ fontSize: "0.75rem" }}>Brand settings</p>
                            </AccordionHeader>
                            <AccordionBody accordionId='1'>
                                <div className='p-0 mx-0 my-2'>
                                    <div className="form-check form-check-success d-flex align-items-center gap-2 m-0 p-0">
                                        <label htmlFor="brandingCheck" className="form-check-label m-0">Show branding</label> <input id="brandingCheck" onChange={e => {
                                            if (isPro) {
                                                setShowBrand(e.target.checked)
                                            } else {
                                                toast.error("You must have the Pro subscription to hide the branding")
                                            }
                                        }} checked={showBrand} type="checkbox" className="m-0 p-0 form-check-input" />
                                    </div>
                                    {/* <Select isMulti closeMenuOnSelect={false} options={pagesSelection} /> */}
                                </div>
                            </AccordionBody>
                        </AccordionItem>
                    </UncontrolledAccordion>
                </>
            )
        } else {
            function getSideText(subElem) {
                if (!subElem?.type && subElem?.type === "") {
                    return "No Element Here"
                } else if (subElem.type === "text") {
                    const newElem = document.createElement("div")
                    newElem.innerHTML = subElem?.textValue
                    const elemText = newElem.innerText
                    return elemText.length > 12 ? `${elemText.slice(0, 12)}...` : elemText
                } else {
                    return subElem.type
                }
            }
            return (
                <div>
                    <div className='d-flex flex-column h-100'>
                        {/* <div className='d-flex justify-content-start align-items-center w-100 mt-1 cursor-pointer' onClick={() => setSideNav("display")} >
                            <button
                                type="button"
                                className="btn btn-link m-0 p-0 ps-1"
                            >
                                <Layout color="#727272" size={15} />
                            </button>
                            <p className='m-0 fw-bold text-black text-capitalize' style={{ padding: "0.25rem 0.5rem 0px", fontSize: "0.85rem" }}>Website Layout</p>
                        </div> */}
                        <h5 className={`px-2 py-1 m-0 text-capitalize`}>{currPage === "button" ? "Button" : finalObj?.[`${mobileCondition}pages`][finalObj[`${mobileCondition}pages`]?.findIndex($ => $?.id === currPage)]?.pageName}</h5>
                        {/* <div className='d-flex justify-content-start align-items-center w-100 cursor-pointer' onClick={() => setCurrPosition({ ...currPosition, selectedType: "main" })} >
                            <button
                                type="button"
                                className="btn btn-link m-0 p-0 ps-1"
                            >
                                <Layout color="#727272" size={15} />
                            </button>
                            <p className='m-0 fw-bold text-black text-capitalize' style={{ padding: "0.25rem 0.5rem 0px", fontSize: "0.85rem" }}>{currPage === "button" ? "Button" : `${finalObj[`${mobileCondition}pages`][finalObj[`${mobileCondition}pages`].findIndex($ => $?.id === currPage)].pageName}`}</p>
                        </div> */}
                        <div className='d-flex justify-content-start align-items-center w-100 mt-0 cursor-pointer' onClick={() => setCurrPosition({ ...currPosition, selectedType: "cross" })}>
                            <button
                                type="button"
                                className="btn btn-link m-0 p-0 ps-1"
                            >
                                <XCircle color="#727272" size={15} />
                            </button>
                            <p className='m-0 fw-bold text-black text-capitalize' style={{ padding: "0.25rem 0.5rem 0px", fontSize: "0.85rem" }}>Close button</p>
                        </div>
                    </div>
                    {colWise.map((cur, key) => (
                        <div key={key}
                            className='h-100'>
                            <div className={`mt-1 fw-bolder text-black w-100 cursor-pointer d-flex align-items-center justify-content-between rounded ${isEqual({ cur: key, curElem: "parent", subElem: "grandparent" }, { ...indexes }) ? "bg-light-secondary" : ""}`} style={{ padding: "0px 1rem" }}>
                                <div className="d-flex align-items-center"
                                    onClick={(e) => {
                                        e.stopPropagation()
                                        // setActiveRow(key)
                                        makActive(e, cur, "parent", "parent", key, "parent", "parent")
                                        setCurrPosition({ ...currPosition, selectedType: "block" })
                                        setIndexes({ cur: key, curElem: "parent", subElem: "grandparent" })
                                        setValues(cur?.style)
                                        setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                    }}
                                    onMouseEnter={(e) => {
                                        e.stopPropagation()
                                        setMouseEnterIndex({ cur: key, curElem: "parent", subElem: "grandparent" })
                                    }}
                                    onMouseLeave={(e) => {
                                        e.stopPropagation()
                                        setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                    }}
                                    style={{ gap: "0.5rem" }}>
                                    <Columns size={15} />
                                    <p className='m-0 fw-bold text-capitalize text-black' style={{ fontSize: "0.85rem" }}>
                                        Block with {cur?.elements?.length} column{cur?.elements?.length > 1 ? 's' : ''}
                                    </p>
                                </div>
                                <UncontrolledDropdown className='more-options-dropdown'>
                                    <DropdownToggle className={`btn-icon cursor-pointer`} color='transparent' size='sm'>
                                        <span className={`${isEqual({ cur: key, curElem: "parent", subElem: "grandparent" }, { ...indexes }) ? "text-black" : ""}`}>
                                            <MoreVertical size='18' />
                                        </span>
                                    </DropdownToggle>
                                    <DropdownMenu end>
                                        <DropdownItem
                                            onClick={(e) => {
                                                e.stopPropagation()
                                                if (colWise.length <= 1) {
                                                    // setCurrPosition({ ...currPosition, selectedType: "main" })
                                                    setIndexes({ cur: 0, curElem: "left", subElem: "grandparent" })
                                                } else {
                                                    // setCurrPosition({ ...currPosition, selectedType: "block" })
                                                    setIndexes({ cur: key - 1, curElem: "left", subElem: "grandparent" })
                                                }
                                                const arr = [...colWise]
                                                arr.splice(key, 1)
                                                setcolWise([...arr])
                                                setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                            }} className='w-100'>
                                            <div className="d-flex align-items-center" style={{ gap: "0.5rem" }}>
                                                <Trash stroke='red' size={"15px"} className='cursor-pointer' /> <span className='fw-bold text-black' style={{ fontSize: "0.75rem" }}>Delete</span>
                                            </div>
                                        </DropdownItem>
                                        <DropdownItem
                                            onClick={(e) => {
                                                e.stopPropagation()
                                                setCurrPosition({ ...currPosition, selectedType: "block" })
                                                setIndexes({ cur: key + 1, curElem: "left", subElem: "grandparent" })
                                                const arr = [...colWise]
                                                arr.splice(key, 0, cur)
                                                setcolWise([...arr])
                                                setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                            }} className='w-100'>
                                            <div className="d-flex align-items-center" style={{ gap: "0.5rem" }}>
                                                <Copy stroke='#727272' size={"15px"} className='cursor-pointer' /> <span className='fw-bold text-black' style={{ fontSize: "0.75rem" }}>Duplicate</span>
                                            </div>
                                        </DropdownItem>
                                    </DropdownMenu>
                                </UncontrolledDropdown>
                            </div>
                            {cur?.elements?.map((curElem, i) => (
                                <div onClick={(e) => {
                                    e.stopPropagation()
                                    // setActiveRow("none")
                                    makActive(e, cur, curElem, curElem.positionType, key, i, "parent")
                                    setCurrPosition({ ...currPosition, selectedType: "column" })
                                    setIndexes({ cur: key, curElem: curElem.positionType, subElem: "parent" })
                                    setValues(curElem.style)
                                    setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                }}
                                    onMouseEnter={(e) => {
                                        e.stopPropagation()
                                        setMouseEnterIndex({ cur: key, curElem: curElem.positionType, subElem: "parent" })
                                    }}
                                    onMouseLeave={(e) => {
                                        e.stopPropagation()
                                        setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                    }} key={i}
                                    className='h-100 ms-2 position-relative tree-border'>
                                    <div className={`fw-bolder text-black ms-1 cursor-pointer d-flex align-items-center rounded ${isEqual({ cur: key, curElem: curElem.positionType, subElem: "parent" }, { ...indexes }) ? "bg-light-secondary" : ""}`} style={{ padding: "0.5rem", gap: "0.5rem" }}>
                                        <Columns color="#727272" size={15} />
                                        <p className='m-0 fw-bold text-capitalize w-100 text-black' style={{ fontSize: "0.85rem" }}>
                                            {`${cur?.elements?.length > 1 ? `${curElem?.positionType} ` : ""}`}column
                                        </p>
                                    </div>
                                    {curElem.element.every($ => $?.type !== "") && <ul className='ms-2 mb-0 p-0' style={{ listStyle: 'none' }}>
                                        {curElem.element.map((subElem, j) => (
                                            <li className={`text-black cursor-pointer d-flex justify-content-between align-items-center rounded ${isEqual({ cur: key, curElem: curElem.positionType, subElem: j }, { ...indexes }) ? "bg-light-secondary" : ""}`} style={{ padding: "0px 1rem 0px 1.5rem", fontSize: "0.75rem" }} key={j}>
                                                <div
                                                    type="button"
                                                    className="text-start m-0 p-0 d-flex align-items-center"
                                                    style={{ gap: "0.5rem" }}
                                                    onClick={e => {
                                                        e.stopPropagation()
                                                        makActive(e, cur, curElem, curElem.positionType, key, i, j)
                                                        setCurrPosition({ ...currPosition, selectedType: subElem.type })
                                                        setIndexes({ cur: key, curElem: curElem.positionType, subElem: j })
                                                        setValues(subElem.style)
                                                        setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                    }}
                                                    onMouseEnter={(e) => {
                                                        e.stopPropagation()
                                                        setMouseEnterIndex({ cur: key, curElem: curElem.positionType, subElem: j })
                                                    }}
                                                    onMouseLeave={(e) => {
                                                        e.stopPropagation()
                                                        setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                    }}
                                                >
                                                    {subElem?.type === 'text' && <Type size={16} color='#727272' />}
                                                    {subElem?.type === 'button' && <Disc size={16} color='#727272' />}
                                                    {subElem?.type === 'input' && <img style={{ filter: "grayscale(100%)" }} src='https://cdn-app.optimonk.com/img/StructureInput.61ed2888.svg' alt='' />}
                                                    {subElem?.type === 'image' && (subElem.src === "" ? <Image width={16} color='#727272' /> : <div style={{ width: 16, aspectRatio: "1", backgroundImage: `url(${subElem.src})`, backgroundSize: "contain", backgroundPosition: "center center", backgroundRepeat: "no-repeat" }} />)}
                                                    {<span className={`${subElem.type !== "text" ? "text-capitalize" : ""}`} style={{ fontSize: "0.75rem" }}>{getSideText(subElem)}</span>}
                                                </div>
                                                {subElem?.type !== "" && <UncontrolledDropdown onClick={e => e.stopPropagation()} className='more-options-dropdown'>
                                                    <DropdownToggle className='btn-icon cursor-pointer' color='transparent' size='sm'>
                                                        <span className={`${isEqual({ cur: key, curElem: curElem.positionType, subElem: j }, { ...indexes }) ? "text-black" : ""}`}>
                                                            <MoreVertical size='18' />
                                                        </span>
                                                    </DropdownToggle>
                                                    <DropdownMenu end>
                                                        <DropdownItem
                                                            onClick={(e) => {
                                                                e.stopPropagation()
                                                                if (colWise.length <= 1) {
                                                                    setCurrPosition({ ...currPosition, selectedType: "main" })
                                                                    setIndexes({ cur: 0, curElem: "left", subElem: "grandparent" })
                                                                } else {
                                                                    setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                    setIndexes({ cur: key - 1, curElem: "left", subElem: "grandparent" })
                                                                }
                                                                const arr = [...colWise]
                                                                if (curElem?.element?.length <= 1 && cur?.elements?.length <= 1) {
                                                                    arr.splice(key, 1)
                                                                } else if (curElem?.element?.length <= 1 && cur?.elements?.length >= 1) {
                                                                    arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 1, { ...commonObj })
                                                                } else {
                                                                    arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 1)
                                                                }
                                                                setcolWise([...arr])
                                                            }} className='w-100'>
                                                            <div className="d-flex align-items-center" style={{ gap: "0.5rem" }}>
                                                                <Trash stroke='red' size={"15px"} className='cursor-pointer' /> <span className='fw-bold text-black' style={{ fontSize: "0.75rem" }}>Delete</span>
                                                            </div>
                                                        </DropdownItem>
                                                        <DropdownItem
                                                            onClick={(e) => {
                                                                e.stopPropagation()
                                                                setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                setIndexes({ cur: key + 1, curElem: "left", subElem: "grandparent" })
                                                                const arr = [...colWise]
                                                                arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 0, subElem)
                                                                setcolWise([...arr])
                                                            }} className='w-100'>
                                                            <div className="d-flex align-items-center" style={{ gap: "0.5rem" }}>
                                                                <Copy stroke='#727272' size={"15px"} className='cursor-pointer' /> <span className='fw-bold text-black' style={{ fontSize: "0.75rem" }}>Duplicate</span>
                                                            </div>
                                                        </DropdownItem>
                                                    </DropdownMenu>
                                                </UncontrolledDropdown>}
                                            </li>
                                        ))}
                                    </ul>}
                                </div>
                            ))}
                        </div>
                    ))}
                </div>
            )
        }
        // else if (selectedType === "main") {
        //     const bgCheckedCondition = finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, "background"))]?.common?.includes("backgroundColor") || finalObj?.responsive[finalObj?.responsive?.findIndex($ => isEqual($?.position, "background"))]?.common?.includes("backgroundImage")
        //     styles = (
        //         <>
        //             <UncontrolledAccordion defaultOpen={['1', '2', '3']} stayOpen>
        //                 <AccordionItem>
        //                     <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
        //                         <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Background Fill</p>
        //                     </AccordionHeader>
        //                     <AccordionBody accordionId='1'>
        //                         <div className='p-0 mx-0 my-1'>
        //                             <div className=' p-0 justify-content- align-items-center gap-1'>
        //                                 <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Background:</span>
        //                                 <div className=" rounded border cursor-pointer" style={{ backgroundImage: `url(${pixels})` }}>
        //                                     <div onClick={() => {
        //                                         currPage === "button" ? setBgModal3(!bgModal3) : setBgModal2(!bgModal2)
        //                                     }} className="p-2 w-100" style={{ backgroundColor: currPage === "button" ? btnStyles?.backgroundColor : bgStyles?.backgroundColor, backgroundImage: currPage === "button" ? btnStyles.backgroundImage : bgStyles.backgroundImage }}></div>
        //                                 </div>
        //                                 <div className="d-flex align-items-center justify-content-between gap-1 form-check form-check-success m-0 p-0">
        //                                     <label style={{ fontSize: "10px" }} className="form-check-label m-0 p-0">Keep same background for {isMobile ? "desktop theme" : "mobile theme"}</label>
        //                                     <input
        //                                         checked={bgCheckedCondition}
        //                                         type='checkbox' className='form-check-input m-0 p-0' onChange={(e) => {
        //                                             const newObj = { ...finalObj }
        //                                             if (e.target.checked) {
        //                                                 if (finalObj?.responsive?.some($ => isEqual($?.position, "background"))) {
        //                                                     const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, "background"))
        //                                                     newObj?.responsive[responiveIndex]?.common?.push("backgroundColor")
        //                                                     newObj.responsive[responiveIndex].common = [...newObj?.responsive[responiveIndex]?.common, "backgroundColor", "backgroundImage"]
        //                                                 } else {
        //                                                     newObj.responsive.push({ position: "background", common: ["backgroundColor", "backgroundImage"], page: currPage })
        //                                                 }
        //                                             } else {
        //                                                 const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, "background"))
        //                                                 newObj.responsive[responiveIndex].common = newObj?.responsive[responiveIndex]?.common?.filter(item => (item !== "backgroundColor") && (item !== "backgroundImage"))
        //                                             }
        //                                             setFinalObj({ ...newObj })
        //                                         }} />
        //                                 </div>
        //                             </div>
        //                         </div>
        //                     </AccordionBody>
        //                 </AccordionItem>
        //                 <AccordionItem>
        //                     <AccordionHeader className='acc-header' targetId='2' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
        //                         <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Size</p>
        //                     </AccordionHeader>
        //                     <AccordionBody accordionId='2'>
        //                         <div className='p-0 mx-0 my-1'>
        //                             <div className='mb-1'>
        //                                 <span className='fw-bolder text-black text-capitalize' style={{ fontSize: "0.75rem" }}>{isMobile ? "Max Width" : "Width"}: {currPage === "button" ? btnStyles[isMobile ? "maxWidth" : "width"] : bgStyles[isMobile ? "maxWidth" : "width"]}</span>
        //                                 <div className="d-flex p-0 justify-content-between align-items-center gap-2">
        //                                     <input type='range'
        //                                         value={parseFloat(currPage === "button" ? btnStyles?.[isMobile ? "maxWidth" : "width"] : bgStyles?.[isMobile ? "maxWidth" : "width"])}
        //                                         className='w-100' onChange={e => {
        //                                             currPage === "button" ? setBtnStyles({ ...btnStyles, [e.target.name]: `${e.target.value}${isMobile ? "%" : "px"}` }) : setBgStyles({ ...bgStyles, [e.target.name]: `${e.target.value}${isMobile ? "%" : "px"}` })
        //                                         }} name={isMobile ? "maxWidth" : "width"} min="25" max={isMobile ? "100" : "600"} />
        //                                 </div>
        //                             </div>
        //                             <div className=''>
        //                                 <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Min-Height: {bgStyles?.minHeight}</span>
        //                                 <div className="d-flex p-0 justify-content-between align-items-center gap-2">
        //                                     <input type='range' value={parseFloat(currPage === "button" ? btnStyles.minHeight : bgStyles?.minHeight)} onChange={e => {
        //                                         currPage === "button" ? setBtnStyles({ ...btnStyles, minHeight: `${e.target.value}px` }) : setBgStyles({ ...bgStyles, minHeight: `${e.target.value}px` })
        //                                     }} className='w-100' name="height" min="50" max="650" />
        //                                 </div>
        //                             </div>
        //                         </div>
        //                     </AccordionBody>
        //                 </AccordionItem>
        //                 <AccordionItem>
        //                     <AccordionHeader className='acc-header' targetId='3' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
        //                         <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Border and Shadow</p>
        //                     </AccordionHeader>
        //                     <AccordionBody accordionId='3'>
        //                         {currPage === "button" ? < BorderChange styles={btnStyles} setStyles={setBtnStyles} /> : <BorderChange styles={bgStyles} setStyles={setBgStyles} />}
        //                     </AccordionBody>
        //                 </AccordionItem>
        //             </UncontrolledAccordion>
        //         </>
        //     )
        //     advanced = (
        //         <>
        //             <UncontrolledAccordion defaultOpen={['1', '2']} stayOpen>
        //                 <AccordionItem>
        //                     <AccordionHeader className='acc-header' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
        //                         <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Spacing</p>
        //                     </AccordionHeader>
        //                     <AccordionBody accordionId='1'>
        //                         <div className='p-0 mx-0 my-1'>
        //                             <InputChange allValues={currPage === "button" ? btnStyles : bgStyles} setAllValues={currPage === "button" ? setBtnStyles : setBgStyles} type='padding' />
        //                         </div>
        //                         {currPage !== "button" && <div className='p-0 mx-0 my-1'>
        //                             <InputChange allValues={bgStyles} setAllValues={setBgStyles} type='margin' />
        //                         </div>}
        //                     </AccordionBody>
        //                 </AccordionItem>
        //             </UncontrolledAccordion>
        //         </>
        //     )
        // }
        return <ModificationSection key={`${currPage}-${currPosition.selectedType}-${indexes.cur}-${indexes.curElem}-${indexes.subElem}`} currPosition={currPosition} setCurrPosition={setCurrPosition} styles={styles} general={general} advanced={advanced} />
        // }
        // }
    }

    // const renderSettings = () => {Nav

    //   return colWise.map((cur) => {
    //   cur.elements.map((renderCur) => {
    //   if (renderCur.type === "text" || renderCur.type === "image" || renderCur.type === "button") {
    //   return (
    //   <>
    //   <div className='label mb-4'>
    //   <label htmlFor="label" className="text-capitalize">Label</label>
    //   <input
    //  type="text"
    //  className="form-control"
    //  name="label"
    //   // defaultValue={activeData.label}
    //   />
    //   </div>
    //   <div className='class mb-4'>
    //   <label htmlFor="class" className="text-capitalize">Class</label>
    //   <input
    //  type="text"
    //  className="form-control"
    //  name="class"
    //   // defaultValue={activeData.class}
    //   />
    //   </div>
    //   </>
    //   )
    //   }
    //   })

    //   })
    // }


    const handleColDrop = (e, cur, curElem, subElem) => {
        e.stopPropagation()
        const transferedData = e.dataTransfer.getData("type")
        const dragOverData = document.getElementById(`${currPage}-${dragOverIndex.cur}-${dragOverIndex.curElem}-${dragOverIndex.subElem}`).getBoundingClientRect()
        const { y, height } = dragOverData
        if ((transferedData !== "" && !transferedData.includes("col"))) {
            let dupArray, mobile_dupArray

            if (currPage === "button") {
                dupArray = finalObj.button
                mobile_dupArray = finalObj.mobile_button
            } else {
                dupArray = finalObj.pages[finalObj.pages.findIndex($ => $?.id === currPage)].values
                mobile_dupArray = finalObj.mobile_pages[finalObj.pages.findIndex($ => $?.id === currPage)].values
            }

            if (mousePos.y - (y + (height / 2)) < 0) {
                dupArray[dragOverIndex.cur].elements[dupArray[dragOverIndex.cur].elements.findIndex($ => $?.positionType === dragOverIndex.curElem)].element.splice(dragOverIndex.subElem, 0, { ...commonObj, type: transferedData, style: elementStyles[transferedData] })
                mobile_dupArray[dragOverIndex.cur].elements[mobile_dupArray[dragOverIndex.cur].elements.findIndex($ => $?.positionType === dragOverIndex.curElem)].element.splice(dragOverIndex.subElem, 0, { ...commonObj, type: transferedData, style: elementStyles[transferedData] })
                setIndexes({ ...dragOverIndex })
            } else {
                dupArray[dragOverIndex.cur].elements[dupArray[dragOverIndex.cur].elements.findIndex($ => $?.positionType === dragOverIndex.curElem)].element.splice(dragOverIndex.subElem + 1, 0, { ...commonObj, type: transferedData, style: elementStyles[transferedData] })
                mobile_dupArray[dragOverIndex.cur].elements[mobile_dupArray[dragOverIndex.cur].elements.findIndex($ => $?.positionType === dragOverIndex.curElem)].element.splice(dragOverIndex.subElem + 1, 0, { ...commonObj, type: transferedData, style: elementStyles[transferedData] })
                setIndexes({ cur, curElem, subElem })
            }
            setValues({ ...elementStyles[transferedData] })
            setcolWise(isMobile ? [...mobile_dupArray] : [...dupArray])
            const newObj = { ...finalObj }

            if (currPage === "button") {
                newObj.button = dupArray
                newObj.mobile_button = mobile_dupArray
            } else {
                newObj.pages[finalObj.pages.findIndex($ => $?.id === currPage)].values = dupArray
                newObj.mobile_pages[finalObj.pages.findIndex($ => $?.id === currPage)].values = mobile_dupArray
            }

            setFinalObj({ ...newObj })
        }
    }

    const getOffers = () => {
        setGotOffers(false)
        // const form_data = new FormData()
        // form_data.append('shop', outletData[0]?.web_url)
        // form_data.append('app', 'superleadz')

        // const offerUrl = new URL(`${SuperLeadzBaseURL}/api/v1/get/get_offers/`)

        // axios({ method: "POST", data: form_data, url: offerUrl })
        //     .then((data) => {
        //         setGotOffers(true)
        //         setAllOffers([...data.data.status])
        //         // setFinalObj({ ...finalObj, selectedOffers: [...data.data.status] })
        //     })
        //     .catch(err => console.log(err))

        fetch(`${SuperLeadzBaseURL}/utils/api/v1/superoffer/`, {
            method: "POST",
            body: JSON.stringify({
                shop: outletData[0]?.web_url,
                app: "superleadz"
            })
        })
            .then((resp) => resp.json())
            .then((data) => {
                setGotOffers(true)
                setAllOffers(data)
            })
            .catch((error) => {
                setGotOffers(true)
                console.log(error)
            })
    }

    const handleRearrangeElement = (e) => {
        e.stopPropagation()
        const elementId = document.getElementById(`${currPage}-${dragOverIndex.cur}-${dragOverIndex.curElem}-${dragOverIndex.subElem}`)
        // if (elementId !== null || elementId !== undefined) {
        const isSameIndexes = `${currPage}-${dragOverIndex.cur}-${dragOverIndex.curElem}-${dragOverIndex.subElem}` === `${currPage}-${dragStartIndex.cur}-${dragStartIndex.curElem}-${dragStartIndex.subElem}`
        if (isSameIndexes || !transfered.includes("rearrange") || !elementId) {
            return
        }
        const dupArray = [...colWise]
        const mobile_dupArray = [...finalObj.mobile_pages[finalObj.mobile_pages.findIndex($ => $?.id === currPage)].values]

        const elementDetails = elementId.getBoundingClientRect()
        const { y, height } = elementDetails

        const removedElem = dupArray[dragStartIndex.cur].elements[dupArray[dragStartIndex.cur].elements.findIndex($ => $?.positionType === dragStartIndex.curElem)].element.splice(dragStartIndex.subElem, 1)[0]
        const mobile_removedElem = mobile_dupArray[dragStartIndex.cur].elements[mobile_dupArray[dragStartIndex.cur].elements.findIndex($ => $?.positionType === dragStartIndex.curElem)].element.splice(dragStartIndex.subElem, 1)[0]
        if (dupArray[dragStartIndex.cur].elements[dupArray[dragStartIndex.cur].elements.findIndex($ => $?.positionType === dragStartIndex.curElem)].element.length === 0) {
            dupArray[dragStartIndex.cur].elements[dupArray[dragStartIndex.cur].elements.findIndex($ => $?.positionType === dragStartIndex.curElem)].element.push({ ...commonObj })
            mobile_dupArray[dragStartIndex.cur].elements[mobile_dupArray[dragStartIndex.cur].elements.findIndex($ => $?.positionType === dragStartIndex.curElem)].element.push({ ...commonObj })
        }

        if ((mousePos.y - (y + (height / 2)) < 0) || (dragStartIndex.subElem === dragOverIndex.subElem + 1)) {
            dupArray[dragOverIndex.cur].elements[dupArray[dragOverIndex.cur].elements.findIndex($ => $?.positionType === dragOverIndex.curElem)].element.splice(dragOverIndex.subElem, 0, removedElem)
            mobile_dupArray[dragOverIndex.cur].elements[mobile_dupArray[dragOverIndex.cur].elements.findIndex($ => $?.positionType === dragOverIndex.curElem)].element.splice(dragOverIndex.subElem, 0, mobile_removedElem)
        } else if ((mousePos.y - (y + (height / 2)) > 0) || (dragStartIndex.subElem === dragOverIndex.subElem - 1)) {
            dupArray[dragOverIndex.cur].elements[dupArray[dragOverIndex.cur].elements.findIndex($ => $?.positionType === dragOverIndex.curElem)].element.splice(dragOverIndex.subElem + 1, 0, removedElem)
            mobile_dupArray[dragOverIndex.cur].elements[mobile_dupArray[dragOverIndex.cur].elements.findIndex($ => $?.positionType === dragOverIndex.curElem)].element.splice(dragOverIndex.subElem + 1, 0, mobile_removedElem)
        }
        setcolWise([...dupArray])
        const newObj = { ...finalObj }
        newObj.mobile_pages[newObj.mobile_pages.findIndex($ => $?.id === currPage)].values = mobile_dupArray
        setDragStartIndex({ cur: 0, curElem: "left", subElem: "grandparent" })
        setValues({ ...dupArray[dragOverIndex.cur].elements[dupArray[dragOverIndex.cur].elements.findIndex($ => $?.positionType === dragOverIndex.curElem)].element[dragOverIndex.subElem].style })
        setIndexes({ ...dragOverIndex })
        setFinalObj({ ...newObj })
        // }
    }

    const sendData = (e) => {
        e.preventDefault()
        const includesInput = []
        finalObj?.pages?.forEach((ele) => {
            ele?.values?.forEach((cur) => {
                cur?.elements?.forEach((curElem) => {
                    curElem?.element?.forEach((subElem) => {
                        if (subElem?.type === "input" && subElem?.inputType === "") {
                            includesInput?.push({ page: ele?.pageName, screen: "desktop" })
                        }
                    })
                })
            })
        })
        finalObj?.mobile_pages?.forEach((ele) => {
            ele?.values?.forEach((cur) => {
                cur?.elements?.forEach((curElem) => {
                    curElem?.element?.forEach((subElem) => {
                        if (subElem?.type === "input" && subElem?.inputType === "") {
                            includesInput?.push({ page: ele?.pageName, screen: "phone" })
                        }
                    })
                })
            })
        })
        if (finalObj.theme_name === "") {
            toast.error("Enter a theme name")
        } else if (isOfferDraggable && phoneIsOfferDraggable && finalObj.selectedOffers.length === 0) {
            toast.error("Add some offers to your Theme!")
        } else if (includesInput?.length > 0) {
            toast.error(<span> You have not selected input type {includesInput.map((ip, i) => {
                return <span>in {ip?.screen} view on {<span className='text-capitalize'>{ip?.page}</span>}{ip?.page?.toLowerCase()?.includes("page") ? "" : "page"}{includesInput.length - 1 === i ? "." : ", "}</span>
            })}
            </span>)
        } else {
            const form_data = new FormData()
            form_data.append('shop', outletData[0]?.web_url)
            form_data.append('app', 'superleadz')
            Object.entries(finalObj.behaviour).forEach(([key, value]) => {
                if (Array.isArray(value)) {
                    value.forEach(ele => form_data.append(key, ele))
                } else {
                    form_data.append(key, value)
                }
            })
            // finalObj.selectedOffers.forEach((offer) => {
            form_data.append("selected_offer_list", JSON.stringify(finalObj.selectedOffers))
            // })
            form_data.append("json_list", JSON.stringify(finalObj))

            form_data.append("campaign_name", finalObj.theme_name)
            form_data.append("start_date", finalObj.campaignStartDate)
            form_data.append("end_date", finalObj.campaignEndDate)
            form_data.append("default_id", selectedThemeId)
            form_data.append("is_edit", themeLoc?.state?.custom_theme ? 1 : 0)

            form_data.append("theme_id", themeId)
            // if (!themeLoc?.state?.custom_theme) {
            form_data.append("is_draft", 0)
            // }

            axios({
                method: "POST", url: `${SuperLeadzBaseURL}/api/v1/form_builder_template/`, data: form_data
            }).then((data) => {

                if (data?.data?.exist) {
                    toast.error("Campaign name already exist")
                } else {
                    localStorage.removeItem("draftId")
                    toast.success("Successfully saved")
                    navigate("/merchant/SuperLeadz/all_campaigns/")
                }

            }).catch((error) => {
                console.log({ error })
            })
        }
    }

    // function addPrevBorder() {
    //     const selectedElem = document.getElementById(`${currPage}-${indexes.cur}-${indexes.curElem}-${indexes.subElem}`)
    //     if (selectedElem) {
    //         if (document.getElementById("border-div-fixed")) {
    //             document.getElementById("border-div-fixed").remove()
    //         }
    //         const { left, top, height, width } = selectedElem.getBoundingClientRect()
    //         if (currPosition.selectedType !== "" && currPosition.selectedType !== "cross" && currPosition.selectedType !== "main") {
    //             const showBorder = document.createElement("div")
    //             showBorder.id = "border-div-fixed"
    //             showBorder.style.position = "fixed"
    //             showBorder.style.width = `${width}px`
    //             showBorder.style.height = `${height}px`
    //             showBorder.style.top = `${top}px`
    //             showBorder.style.left = `${left}px`
    //             showBorder.style.outline = `3.5px solid #727272`
    //             showBorder.style.zIndex = `999999999999999999999999999999999999999999`
    //             showBorder.style.pointerEvents = `none`
    //             document.getElementById('customization-container').appendChild(showBorder)
    //         }
    //     }
    // }

    const saveDraft = async () => {
        const form_data = new FormData()
        form_data.append('shop', outletData[0]?.web_url)
        form_data.append('app', 'superleadz')
        const theme_id = await themeLoc?.state?.custom_theme ? themeLoc?.state?.id : (themeId !== "undefined" || themeId !== "null") ? Number(themeId) : 0
        Object.entries(finalObj.behaviour).map(([key, value]) => {
            if (Array.isArray(value)) {
                value.map(ele => form_data.append(key, ele))
            } else {
                form_data.append(key, value)
            }
        })
        form_data.append("json_list", JSON.stringify(finalObj))

        form_data.append("selected_offer_list", JSON.stringify(finalObj.selectedOffers))
        form_data.append("campaign_name", finalObj.theme_name)
        form_data.append("start_date", finalObj.campaignStartDate)
        form_data.append("end_date", finalObj.campaignEndDate)
        form_data.append("default_id", selectedThemeId)
        form_data.append("is_draft", 1)

        form_data.append("theme_id", theme_id)
        axios({
            method: "POST", url: `${SuperLeadzBaseURL}/api/v1/form_builder_template/`, data: form_data
        }).then((data) => {
            setThemeId(data?.data?.theme_id)
            // if (finalObj.theme_name !== `template_${data?.data?.theme_id}` || !themeLoc?.state?.custom_theme) {
            //     setFinalObj({ ...finalObj, theme_name: `template_${data?.data?.theme_id}` })
            // }
        }).catch((error) => {
            console.log({ error })
        })
    }

    const refreshOfferDraggable = () => {
        const arr = []
        const phoneArr = []
        finalObj?.pages?.forEach(page => {
            page?.values?.forEach(cur => {
                cur?.elements?.forEach(curElem => {
                    curElem?.element?.forEach(subElem => {
                        arr?.push(subElem?.type === "offer")
                    })
                })
            })
        })
        finalObj?.mobile_pages?.forEach(page => {
            page?.values?.forEach(cur => {
                cur?.elements?.forEach(curElem => {
                    curElem?.element?.forEach(subElem => {
                        phoneArr?.push(subElem?.type === "offer")
                    })
                })
            })
        })
        setIsOfferDraggable(!arr.includes(true))
        setPhoneIsOfferDraggable(!phoneArr.includes(true))
    }

    const getPlan = () => {
        const form_data = new FormData()
        form_data.append('shop', outletData[0]?.web_url)
        form_data.append('app', 'superleadz')
        form_data.append('type', 'ACTIVE')
        const url = new URL(`${SuperLeadzBaseURL}/api/v1/get_active_shop_billing/`)

        axios({
            method: "POST",
            url,
            data: form_data
        })
            .then((data) => {
                setIsPro(data?.data?.data[0]?.plan_id?.toLowerCase()?.includes("pro"))
            })
            .catch((error) => {
                console.log({ error })
            })
    }

    // const getElementJsx = ({ draggable, dragStartFunc, icon, label }) => {
    //     const elem = (
    //         <div style={{ width: `${100 / 3}%`, padding: "0.25rem" }}>
    //             <div draggable={draggable} onDragStart={dragStartFunc} className="border rounded text-danger w-100 d-flex flex-column justify-content-between align-items-center p-1" style={{ aspectRatio: "1", cursor: "grab", gap: "0.5rem", boxShadow: "1px 1px 5px rgba(0,0,0,0.125)" }}>
    //                 {icon}
    //                 <span className='text-black' style={{ fontSize: "0.75rem" }}>{label}</span>
    //                 <svg
    //                     width={"35%"}
    //                     viewBox="0 0 67 28"
    //                     fill="none"
    //                     xmlns="http://www.w3.org/2000/svg"
    //                 >
    //                     <circle cx={5} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
    //                     <circle cx={24} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
    //                     <circle cx={43} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
    //                     <circle cx={62} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
    //                     <circle cx={5} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
    //                     <circle cx={24} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
    //                     <circle cx={43} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
    //                     <circle cx={62} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
    //                 </svg>
    //             </div>
    //         </div>
    //     )
    //     return elem
    // }

    useEffect(() => {
        // if (isMobile) {
        //     setPopPosition("MC")
        // }
        if (currPage === "button") {
            setcolWise(finalObj?.[`${mobileCondition}button`])
            setPopPosition(finalObj?.positions?.[`${mobileCondition}button`])
            setBtnStyles({ ...finalObj?.backgroundStyles?.[`${mobileCondition}button`] })
        } else {
            const pageIndex = finalObj?.[`${mobileCondition}pages`]?.findIndex($ => $?.id === currPage)
            setcolWise(finalObj?.[`${mobileCondition}pages`][pageIndex]?.values)
            setPopPosition(finalObj?.positions?.[`${mobileCondition}main`])
            setCrossStyle({ ...finalObj?.crossButtons?.[`${mobileCondition}main`] })
            setBgStyles({ ...finalObj?.backgroundStyles?.[`${mobileCondition}main`] })
        }

        setBrandStyles({ ...finalObj?.[`${mobileCondition}brandStyles`] })

        const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)
        if (indexes.subElem === "grandparent") {
            // arr[indexes.cur].style = { ...arr[indexes.cur].style, ...values }
            setValues(currPage === "button" ? { ...finalObj?.[`${mobileCondition}button`][indexes.cur]?.style } : { ...finalObj?.[`${mobileCondition}pages`][finalObj?.[`${mobileCondition}pages`]?.findIndex($ => $?.id === currPage)]?.values[indexes.cur]?.style })
            // setValues({...colWise[indexes.cur].style})
        } else if (indexes.subElem === "parent") {
            // const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes.curElem)
            // setValues({...colWise[indexes.cur].elements[positionIndex].style})
            setValues(currPage === "button" ? { ...finalObj?.[`${mobileCondition}button`][indexes.cur]?.elements[positionIndex]?.style } : { ...finalObj?.[`${mobileCondition}pages`][finalObj?.[`${mobileCondition}pages`]?.findIndex($ => $?.id === currPage)]?.values[indexes.cur]?.elements[positionIndex]?.style })
        } else {
            // const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)
            // setValues({...colWise[indexes.cur]?.elements[positionIndex]?.element[indexes.subElem]})
            setValues(currPage === "button" ? { ...finalObj?.[`${mobileCondition}button`][indexes.cur]?.elements[positionIndex]?.element[indexes.subElem]?.style } : { ...finalObj?.[`${mobileCondition}pages`][finalObj?.[`${mobileCondition}pages`]?.findIndex($ => $?.id === currPage)]?.values[indexes.cur]?.elements[positionIndex]?.element[indexes.subElem]?.style })
        }

    }, [isMobile, currPage])

    // useEffect(() => {
    //     if (colWise.length > 0) {
    //         const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)
    //         if (indexes.subElem === "grandparent") {
    //             setValues({ ...colWise[indexes.cur]?.style })
    //         } else if (indexes.subElem === "parent") {
    //             setValues({ ...colWise[indexes.cur].elements[positionIndex]?.style })
    //         } else {
    //             setValues({ ...colWise[indexes.cur]?.elements[positionIndex]?.element[indexes.subElem]?.style })
    //         }
    //     }
    // }, [indexes])

    useEffect(() => {
        if (colWise.length > 0) {
            const arr = [...colWise]
            const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)
            if (indexes.subElem === "grandparent") {
                if (arr[indexes?.cur]?.style) {
                    arr[indexes.cur].style = { ...arr[indexes?.cur]?.style, ...values }
                }
                // setValues({...colWise[indexes.cur].style})
            } else if (indexes.subElem === "parent") {
                // const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes.curElem)
                // setValues({...colWise[indexes.cur].elements[positionIndex].style})
                if (arr[indexes?.cur]?.elements[positionIndex]?.style) {
                    arr[indexes.cur].elements[positionIndex].style = { ...arr[indexes.cur]?.elements[positionIndex]?.style, ...values }
                }
            } else {
                // const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)
                // setValues({...colWise[indexes.cur]?.elements[positionIndex]?.element[indexes.subElem]})
                if (arr[indexes?.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.style) {
                    arr[indexes.cur].elements[positionIndex].element[indexes.subElem].style = { ...arr[indexes.cur]?.elements[positionIndex]?.element[indexes?.subElem]?.style, ...values }
                }
            }
            setcolWise([...arr])
        }
    }, [values])

    useEffect(() => {
        const obj = finalObj
        const dupObj = { ...obj }
        if (currPage === "button") {
            obj[`${mobileCondition}button`] = [...colWise]
            // setFinalObj({ ...finalObj, [`${mobileCondition}${currPage}`]: colWise })
            dupObj?.responsive?.filter(item => item.page === "button")?.forEach(style => {
                const deskPositionIndex = obj?.button?.[style?.position?.cur]?.elements?.findIndex($ => $?.positionType === style?.position?.curElem)
                const phPositionIndex = obj?.mobile_button?.[style?.position?.cur]?.elements?.findIndex($ => $?.positionType === style?.position?.curElem)
                style?.common?.forEach(value => {
                    if (style?.position?.subElem === "grandparent") {
                        obj[`${mobileConditionRev}button`][style.position.cur].style[value] = obj[`${mobileCondition}button`]?.[style.position.cur]?.style?.[value]
                    } else if (style?.position?.subElem === "parent") {
                        obj[`${mobileConditionRev}button`][style.position.cur].elements[!isMobile ? phPositionIndex : deskPositionIndex].style[value] = obj?.[`${mobileCondition}button`]?.[style.position.cur]?.elements[isMobile ? phPositionIndex : deskPositionIndex]?.style?.[value]
                    } else {
                        obj[`${mobileConditionRev}button`][style.position.cur].elements[!isMobile ? phPositionIndex : deskPositionIndex].element[style.position.subElem].style[value] = obj[`${mobileCondition}button`]?.[style.position.cur]?.elements[isMobile ? phPositionIndex : deskPositionIndex]?.element[style.position.subElem]?.style?.[value]
                    }
                })
            })
        } else if (finalObj[`${mobileCondition}pages`].some($ => $?.id === currPage)) {
            // setFinalObj({ ...finalObj, p })
            const pageIndex = obj[`${mobileCondition}pages`].findIndex($ => $?.id === currPage)
            obj[`${mobileCondition}pages`][pageIndex].values = [...colWise]
            dupObj.responsive?.filter(item => typeof item.position !== "string").forEach(style => {
                const deskIndex = obj?.pages?.findIndex($ => $?.id === style?.page)
                const phIndex = obj?.mobile_pages?.findIndex($ => $?.id === style?.page)
                const deskPositionIndex = obj?.pages[deskIndex]?.values[style?.position?.cur]?.elements?.findIndex($ => $?.positionType === style?.position?.curElem)
                const phPositionIndex = obj?.mobile_pages[phIndex]?.values[style?.position?.cur]?.elements?.findIndex($ => $?.positionType === style?.position?.curElem)
                style?.common?.forEach(value => {
                    if (style?.position?.subElem === "grandparent") {
                        obj[`${mobileConditionRev}pages`][!isMobile ? phIndex : deskIndex].values[style.position.cur].style[value] = obj?.[`${mobileCondition}pages`][isMobile ? phIndex : deskIndex]?.values[style.position.cur]?.style?.[value]
                    } else if (style.position.subElem === "parent") {
                        obj[`${mobileConditionRev}pages`][!isMobile ? phIndex : deskIndex].values[style.position.cur].elements[!isMobile ? phPositionIndex : deskPositionIndex].style[value] = obj?.[`${mobileCondition}pages`][isMobile ? phIndex : deskIndex]?.values[style.position.cur]?.elements[isMobile ? phPositionIndex : deskPositionIndex]?.style?.[value]
                    } else {
                        obj[`${mobileConditionRev}pages`][!isMobile ? phIndex : deskIndex].values[style.position.cur].elements[!isMobile ? phPositionIndex : deskPositionIndex].element[style.position.subElem].style[value] = obj?.[`${mobileCondition}pages`][isMobile ? phIndex : deskIndex]?.values[style.position.cur]?.elements[isMobile ? phPositionIndex : deskPositionIndex]?.element[style.position.subElem]?.style?.[value]
                    }
                })
            })
        }
        setFinalObj(obj)
    }, [colWise])


    useEffect(() => {
        // setFinalObj({ ...finalObj, positions: { ..
        setFinalObj({ ...finalObj, positions: { ...finalObj.positions, [currPage === "button" ? `${mobileCondition}button` : `${mobileCondition}main`]: popPosition } })
    }, [popPosition])

    useEffect(() => {
        const obj = { ...finalObj }
        obj.crossButtons[`${mobileCondition}main`] = { ...crossStyle }
        const dupObj = { ...obj }
        // if (currPage === "button") {
        dupObj?.responsive?.filter(item => item.position === "cross")?.forEach(style => {
            style?.common?.forEach(value => {
                obj.crossButtons[`${mobileConditionRev}main`][value] = obj?.crossButtons?.[`${mobileCondition}main`]?.[value]
            })
        })
    }, [crossStyle])

    useEffect(() => {
        setCrossStyle({ ...finalObj?.crossButtons[currPage === "button" ? currPage : "main"] })
    }, [currPage])

    useEffect(() => {
        getOffers()
        setBgStyles({ ...finalObj?.backgroundStyles?.main })
        setBtnStyles({ ...finalObj?.backgroundStyles?.button })
        setBrandStyles({ ...finalObj?.brandStyles })
        refreshOfferDraggable()
        getPlan()
        const campaignStartDate = campaignStart === "" ? moment(new Date()).format("YYYY-MM-DD HH:mm:ss") : Array.isArray(campaignStart) ? moment(campaignStart[0]).format("YYYY-MM-DD HH:mm:ss") : finalObj?.campaignStartDate
        const campaignEndDate = !finalObj?.campaignHasEndDate ? "" : campaignEnd === "" ? moment(new Date()).format("YYYY-MM-DD HH:mm:ss") : Array.isArray(campaignEnd) ? moment(campaignEnd[0]).format("YYYY-MM-DD HH:mm:ss") : finalObj?.campaignEndDate
        setFinalObj({ ...finalObj, campaignStartDate, campaignEndDate })
        saveDraft()
        return () => {
            localStorage.removeItem("draftId")
        }
        // }
    }, [])
    useEffect(() => {
        const campaignStartDate = campaignStart === "" ? moment(new Date()).format("YYYY-MM-DD HH:mm:ss") : Array.isArray(campaignStart) ? moment(campaignStart[0]).format("YYYY-MM-DD HH:mm:ss") : finalObj?.campaignStartDate
        const campaignEndDate = !finalObj?.campaignHasEndDate ? "" : campaignEnd === "" ? moment(new Date()).format("YYYY-MM-DD HH:mm:ss") : Array.isArray(campaignEnd) ? moment(campaignEnd[0]).format("YYYY-MM-DD HH:mm:ss") : finalObj?.campaignEndDate
        setFinalObj({ ...finalObj, campaignStartDate, campaignEndDate })
    }, [campaignStart, campaignEnd])

    useEffect(() => {
        setFinalObj({ ...finalObj, overlayStyles: bgsettings })
    }, [bgsettings])

    useEffect(() => {
        const obj = { ...finalObj }
        obj.backgroundStyles[`${mobileCondition}${currPage === "button" ? "button" : "main"}`] = currPage === "button" ? { ...btnStyles } : { ...bgStyles }
        const dupObj = { ...obj }
        dupObj?.responsive?.filter(item => item.position === "background")?.forEach(style => {
            style?.common?.forEach(value => {
                obj.backgroundStyles[`${mobileConditionRev}${currPage === "button" ? "button" : "main"}`][value] = obj?.backgroundStyles?.[`${mobileCondition}${currPage === "button" ? "button" : "main"}`]?.[value]
            })
        })
        setFinalObj({ ...obj })
    }, [btnStyles, bgStyles])

    useEffect(() => {
        refreshOfferDraggable()
    }, [finalObj, bgsettings, btnStyles, bgStyles, crossStyle, popPosition, values, colWise])

    useEffect(() => {
        const delay = 500
        const request = setTimeout(() => {
            if (!isEqual(timeline[timeline.length - 1], colWise)) {
                const copy = timeline.slice(0, timelineIndex + 1) // This removes all future (redo) states after current index
                copy.push(colWise)
                setTimeline(copy)
                setTimelineIndex(copy.length - 1)
            }
        }, delay)
        return () => {
            clearTimeout(request)
        }
    }, [colWise, values])

    // useEffect(() => {
    //     const elemResize = document.getElementById("preview_section")
    //     const resizeObserver = new ResizeObserver(() => {
    //         addPrevBorder()
    //     })

    //     elemResize.addEventListener("scroll", addPrevBorder())

    //     resizeObserver.observe(elemResize)
    //     return () => resizeObserver.unobserve(elemResize)
    // }, [currPosition.selectedType, currPage, indexes, colWise, isMobile])

    useEffect(() => {
        // setFinalObj({ ...finalObj, defaultThemeColors: { ...finalObj.defaultThemeColors, [currColor]: defColors[currColor] } })
        const newObj = { ...finalObj }
        const newBgStyles = { ...bgStyles }
        function changeStyles(obj) {
            if (obj?.isInitialBgColor) {
                obj.backgroundColor = defColors[obj?.initialBgColor]
            } else if (obj?.isInitialColor) {
                obj.color = defColors[obj?.initialColor]
            } else if (obj?.isInitialBorderColor) {
                obj.borderColor = defColors[obj?.initialBorderColor]
            }
        }
        changeStyles(newBgStyles)
        newObj?.pages?.forEach((page) => {
            page?.values?.forEach((cur) => {
                changeStyles(cur?.style)
                cur?.elements?.forEach((curElem) => {
                    changeStyles(curElem?.style)
                    curElem?.element?.forEach((subElem) => {
                        changeStyles(subElem?.style)
                    })
                })
            })
        })
        newObj?.mobile_pages?.forEach((page) => {
            page?.values?.forEach((cur) => {
                changeStyles(cur?.style)
                cur?.elements?.forEach((curElem) => {
                    changeStyles(curElem?.style)
                    curElem?.element?.forEach((subElem) => {
                        changeStyles(subElem.style)
                    })
                })
            })
        })
        // colWise.forEach((cur, key) => {
        //     changeStyles(newCol[key].style)
        //     cur.elements.forEach((curElem, i) => {
        //         changeStyles(newCol[key].elements[i].style)
        //         curElem.element.forEach((subElem, j) => {
        //             changeStyles(newCol[key].elements[i].element[j].style)
        //         })
        //     })
        // })
        // setcolWise([...newCol])
        setBgStyles(newBgStyles)
        setcolWise(currPage === "button" ? newObj?.button : newObj?.pages[newObj?.pages?.findIndex($ => $?.id === currPage)]?.values)
        // setValues({...newCol})
        // const arr = [...colWise]
        const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)
        if (indexes.subElem === "grandparent") {
            // arr[indexes.cur].style = { ...arr[indexes.cur].style, ...values }
            setValues(currPage === "button" ? { ...newObj?.button[indexes.cur]?.style } : { ...newObj?.pages[newObj?.pages?.findIndex($ => $?.id === currPage)]?.values[indexes.cur]?.style })
            // setValues({...colWise[indexes.cur].style})
        } else if (indexes.subElem === "parent") {
            // const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes.curElem)
            // setValues({...colWise[indexes.cur].elements[positionIndex].style})
            setValues(currPage === "button" ? { ...newObj?.button[indexes.cur]?.elements[positionIndex]?.style } : { ...newObj?.pages[newObj.pages?.findIndex($ => $?.id === currPage)]?.values[indexes.cur]?.elements[positionIndex]?.style })
        } else {
            // const positionIndex = colWise[indexes.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)
            // setValues({...colWise[indexes.cur]?.elements[positionIndex]?.element[indexes.subElem]})
            setValues(currPage === "button" ? { ...newObj?.button[indexes.cur]?.elements[positionIndex]?.element[indexes.subElem]?.style } : { ...newObj?.pages[newObj?.pages?.findIndex($ => $?.id === currPage)]?.values[indexes.cur]?.elements[positionIndex]?.element[indexes.subElem]?.style })
        }
        // setcolWise([...newCol])
        setFinalObj({ ...newObj, defaultThemeColors: { ...finalObj.defaultThemeColors, [currColor]: defColors[currColor] } })
    }, [defColors, currColor])

    useEffect(() => {
        setFinalObj({ ...finalObj, offerProperties: { ...finalObj.offerProperties, colors: offerColors } })
    }, [offerColors, currOfferColor])

    useEffect(() => {
        localStorage.setItem("draftId", themeId)
    }, [themeId])

    useEffect(() => {
        setFinalObj({ ...finalObj, offerTheme })
    }, [offerTheme])

    useEffect(() => {
        // setEditCount(editCount + 1)
        if (themeId !== "undefined" && themeId !== "null" && Number(themeId) !== 0) {
            setDraftCount(draftCount + 1)
            saveDraft()
        }
    }, [finalObj])

    const currPageIndex = finalObj?.pages?.findIndex($ => $?.id === currPage)

    return (
        <div className='position-relative' id='customization-container'>
            <input type="file" id='hidden-image-input' onChange={handleImage} accept="image/*" className="d-none" />
            <style>
                {`
                @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
                @import url('https://fonts.googleapis.com/css2?family=Abril+Fatface&family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Oswald:wght@200;300;400;500;600;700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap');

                @font-face {
                    font-family: 'Colaborate';
                    src: url(${ColabReg}) format('truetype');
                    font-weight: normal;
                    font-style: normal;
                }
                #preview_section, #preview_section > * {
                    all: initial;
                }

                .text-field > * {
                    line-height: 24px !important;
                }

                .active-on::before {
                content: "";
                position: absolute;
                inset: 0px;
                z-index: -1;
                border-bottom: 5px solid #464646;
                }
                .sketch-picker {
                width: auto !important;
                padding: 0px !important;
                box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px !important;
                }
                [dir] .ql-bubble .ql-tooltip {
                    background-color: #1d1d1d;
                    border-radius: 5px;
                }
                [dir] .css-1rhbuit-multiValue {
                background-color: #464646 !important;
                }
                [dir] .acc-header button {
                background-color: white !important;
                }
                .row > .px-0 {
                padding-left: 0px !important;
                padding-right: 0px !important;
                }
                .se-toolbar-balloon {
                width: ${finalObj.backgroundStyles.main.width} !important;
                margin: auto !important;
                position: fixed !important;
                }
                .se-wrapper-inner.se-wrapper-wysiwyg.sun-editor-editable {
                    padding: 0px !important;
                }
                #dropZoneParent::-webkit-scrollbar, #dropZoneParent *::-webkit-scrollbar {
                display: none;
                }
                .modal-backdrop.fade.show {
                opacity: 0 !important;
                }
                .gen-text {
                box-shadow: 0px 0px 0px rgba(0,0,0,0) !important;
                transition: 0.3s ease;
                }
                .gen-text:hover {
                box-shadow: 0px 0px 15px rgba(0,0,0,0.25) !important;
                }
                [dir] .accordion-button::after {
                    background-image: url(${chevronDown}) !important;
                }
                .revealSection {
                    opacity: 0;
                    transition: 0.3s ease-in-out;
                }
                .img-array-item:hover .revealSection {
                    opacity: 1;
                }
                input::-webkit-outer-spin-button, input::-webkit-inner-spin-button {
                    -webkit-appearance: auto !important;
                    opacity: 1 !important;
                }
                input[type=range] {
                    accent-color: #464646 !important;
                }
                .tree-border::after {
                    content: "";
                    position: absolute;
                    inset: 1.185rem auto auto auto;
                    width: 1rem;
                    border-top: 1px solid lightgray;    
                }
                .tree-border::before {
                    content: "";
                    position: absolute;
                    top: 0.185rem;
                    height: 100%;
                    border-left: 1px solid lightgray;    
                }
                .tree-border:last-child::before {
                    height: 1rem !important;   
                }
                #customization-container {
                    font-family: "Montserrat";

                }
                .active-elem {
                    position: relative;
                    outline: 2px solid #727272;
                }
                .swiper-button-next::after, .swiper-rtl .swiper-button-prev::after, .swiper-button-prev::after, .swiper-rtl .swiper-button-next::after  {
                    font-size: 13px;
                    background-color: rgba(0,0,0,0.25);
                    font-weight: bold;
                    color: #464646;
                    height: 25px;
                    width: 25px;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    border-radius: 500px;
                    padding: 0px;
                    outline: 1px solid #464646
                }
                #page-selector {
                    max-width: calc(100vw - 65px - 350px - 240px);
                }
                .custom-btn-outline {
                    color: #82868b !important;
                    border: 1px solid #82868b !important;
                    background-color: rgba(59, 89, 152, 0) !important;
                    transition: 0.2s ease;
                }
                .custom-btn-outline:hover {
                    color: #000000 !important;
                    border: 1px solid #000000 !important;
                }
                [dir] .form-check-dark .form-check-input:checked {
                    border-color: #464646;
                    background-color: #006aff;
                }
                .sideNav-items {
                    gap: 0.5rem;
                    cursor: pointer;
                    padding: 0.75rem 0px;
                    aspect-ratio: 1;
                    transition: 0.3s ease-in-out;
                    box-shadow: 0px 0px 0px rgba(0,0,0,0);
                    border-radius: 10px;
                }
                .sideNav-items.active-item {
                    box-shadow: 0px 0px 10px rgba(0,0,0,0.5);
                }

                @media only screen and (max-width: 1280px) {
                    #page-selector {
                        max-width: 340px;
                    }
                }
            `}
            </style>

            <Container fluid className='border-bottom px-0' style={{ height: "55px" }}>
                <Row className='align-items-center px-0'>
                    <div className='col-md-4 d-flex justify-content-start align-items-center gap-1'>
                        <button className="btn" style={{ border: "none", outline: "none" }} onClick={() => setGoBack(!goBack)}><ArrowLeft /></button>
                        <div className="d-flex flex-column align-items-center justify-content-center" style={{ gap: "0.5rem", cursor: "pointer", height: "55px" }}>
                            <Link to={"/merchant/SuperLeadz/"} className='text-secondary'><Home size={"20px"} /></Link>
                        </div>
                        {sideNav === "theme" && <input placeholder={"Search Themes"} className={"form-control"} />}
                    </div>
                    <div className="col-md-4 d-flex justify-content-center align-items-stretch align-self-stretch">
                        <button className={`btn d-flex justify-content-center align-items-center position-relative rounded-0 ${!isMobile ? "bg-light-secondary active-on" : ""}`} onClick={() => setIsMobile(false)} style={{ border: "none", outline: "none", padding: "0px", aspectRatio: "1" }}><Monitor size={17.5} /></button>
                        <button className={`btn d-flex justify-content-center align-items-center position-relative rounded-0 ${isMobile ? "bg-light-secondary active-on" : ""}`} onClick={() => setIsMobile(true)} style={{ border: "none", outline: "none", padding: "0px", aspectRatio: "1" }}><Smartphone size={17.5} /></button>
                        {false && <button className="btn" style={{ border: "none", outline: "none" }}>Preview</button>}
                    </div>
                    <div className='col-md-4 d-flex flex-row justify-content-end align-items-center' style={{ padding: "0.5rem", gap: "0.5rem" }}>
                        <div style={{ gap: "0.5rem" }} className="d-flex align-items-center">
                            {/* <button
                                // disabled={!(docStateIndex > 0)} onClick={goBack} 
                                className="btn border bg-light-secondary" style={{ padding: "0.75rem" }}><RotateCcw size={15} /></button>
                            <button
                                // disabled={!(docStateIndex < docStateLastIndex)} onClick={goForward} 
                                className="btn border bg-light-secondary" style={{ padding: "0.75rem" }}><RotateCw size={15} /></button> */}
                        </div>
                        <input type="text" placeholder='Enter theme name' value={finalObj.theme_name} onChange={e => {
                            setFinalObj({ ...finalObj, theme_name: e.target.value })
                        }} className="form-control w-50" />
                        <button className="btn custom-btn-outline" onClick={() => setCancelCust(!cancelCust)}>Cancel</button>
                        <button disabled={currPageIndex === 0} onClick={() => {
                            setCurrPage(currPage === "button" ? finalObj.pages[finalObj.pages.length - 1].id : finalObj.pages[currPageIndex - 1].id)
                        }} className="btn custom-btn-outline">Previous</button>
                        <button disabled={currPage === "button"} onClick={() => {
                            setCurrPage(currPage === finalObj.pages[finalObj.pages.length - 1].id ? "button" : finalObj.pages[currPageIndex + 1].id)
                        }} className="btn custom-btn-outline">Next</button>
                        <button onClick={sendData} id='saveBtn' className="btn btn-primary-main">Save</button>
                        {/* <button onClick={() => {
                            const form_data = new FormData()
                            allPreviews.map((theme) => {
                                form_data.append("default_theme", JSON.stringify(theme))
                            })
                            axios({
                                url: `${SuperLeadzBaseURL}/api/v1/add_default_theme/`,
                                method: "POST",
                                data: form_data
                            })
                                .then((data) => console.log(data))
                                .catch(error => toast.error(error, "Theme not saved"))
                        }} className="btn btn-dark">Add Theme</button> */}
                    </div>
                </Row>
            </Container>
            <div className="d-flex justify-content-center align-items-stretch border position-relative" style={{ height: "calc(100vh - 55px)" }}>
                {/* Component for changing background of the selected element */}
                {/* <BgModifier styles={bgStyles} setStyles={setBgStyles} /> */}
                {/* Component for changing background of the selected element */}

                {/* Sidebar */}
                <div className="nav-sidebar d-flex flex-column align-items-stretch justify-content-start border-end text-center h-100" style={{ padding: "0.5rem", width: "70px", overflow: "auto" }}>
                    <div className={`sideNav-items d-flex flex-column align-items-center justify-content-center ${sideNav === "theme" ? "text-black active-item" : ""}`} style={{ gap: "0.5rem", cursor: "pointer", padding: "0.75rem 0px" }} onClick={() => setSideNav(sideNav === "theme" ? "" : "theme")}>
                        <button className={`btn d-flex align-items-center justify-content-center`} style={{ aspectRatio: "1", padding: "0rem", border: "none", outline: "none", transition: "0.3s ease-in-out" }}>
                            <svg
                                width="15px"
                                id="Layer_1"
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 512 512"
                                xmlSpace="preserve"
                                fill={sideNav === "theme" ? "#000" : "#85898e"}
                                style={{ transition: "0.3s ease-in-out" }}
                            >
                                <path d="M475.691.021c-14.656 0-27.776 8.725-33.451 22.251l-32.64 77.973c-9.728-9.152-22.421-14.933-36.267-14.933h-320C23.936 85.312 0 109.248 0 138.645v320c0 29.397 23.936 53.333 53.333 53.333h320c29.397 0 53.333-23.936 53.333-53.333V225.152l81.92-172.821c2.24-4.757 3.413-10.048 3.413-16.043C512 16.299 495.701.021 475.691.021zm-70.358 458.624c0 17.643-14.357 32-32 32h-320c-17.643 0-32-14.357-32-32v-320c0-17.643 14.357-32 32-32h320c11.243 0 21.312 6.101 27.072 15.573l-37.739 90.197v-52.437c0-5.888-4.779-10.667-10.667-10.667H74.667c-5.888 0-10.667 4.779-10.667 10.667v85.333c0 5.888 4.779 10.667 10.667 10.667h269.76l-8.939 21.333h-90.155c-5.888 0-10.667 4.779-10.667 10.667v128c0 .277.128.512.149.789-8.768 7.787-14.144 10.389-14.528 10.539a10.68 10.68 0 00-6.699 7.616 10.706 10.706 0 002.859 9.941c15.445 15.445 36.757 21.333 57.6 21.333 26.645 0 52.48-9.643 64.128-21.333 16.768-16.768 29.056-50.005 19.776-74.773l47.381-99.925v188.48zm-134.698-61.12c2.944-9.685 5.739-18.859 14.229-27.349 15.083-15.083 33.835-15.083 48.917 0 13.504 13.504 3.2 45.717-10.667 59.584-11.563 11.541-52.672 22.677-80.256 8.256 3.669-2.859 7.893-6.549 12.672-11.328 8.918-8.939 12.075-19.221 15.105-29.163zM256 375.339v-76.672h70.571l-16.363 39.083c-14.251-.256-28.565 5.483-40.448 17.387-6.635 6.634-10.752 13.524-13.76 20.202zm75.264-32.598l28.715-68.629 16.128 7.915-32.555 68.651c-3.947-3.201-8.021-5.931-12.288-7.937zm10.069-172.096v64h-256v-64h256zM489.28 43.243l-104.064 219.52-17.003-8.341 54.08-129.237 39.616-94.677c2.325-5.568 7.744-9.152 13.803-9.152 8.235 0 14.933 6.699 14.933 15.659 0 2.132-.469 4.329-1.365 6.228z" />
                                <path d="M181.333 277.312H74.667c-5.888 0-10.667 4.779-10.667 10.667v149.333c0 5.888 4.779 10.667 10.667 10.667h106.667c5.888 0 10.667-4.779 10.667-10.667V287.979c-.001-5.888-4.78-10.667-10.668-10.667zm-10.666 149.333H85.333v-128h85.333v128z" />
                            </svg>
                        </button>
                        <span style={{ fontSize: "8.5px", fontStyle: "normal", fontWeight: "500", lineHeight: "10px", transition: "0.3s ease-in-out" }} className={`text-uppercase`}>Theme</span>
                        {/* <div className="m-auto" style={{ borderBottom: "2px solid rgba(0,0,0,0.4)", transition: "0.3s ease-in-out", width: sideNav === "theme" ? "25px" : "0px" }}></div> */}
                    </div>
                    <div className={`sideNav-items d-flex flex-column align-items-center justify-content-center ${sideNav === "audience" ? "text-black active-item" : ""}`} style={{ gap: "0.5rem", cursor: "pointer", padding: "0.75rem 0px" }} onClick={() => setSideNav(sideNav === "audience" ? "" : "audience")}>
                        <button className={`btn d-flex align-items-center justify-content-center`} style={{ aspectRatio: "1", padding: "0rem", border: "none", outline: "none", transition: "0.3s ease-in-out" }}>
                            <Target size={15} />
                        </button>
                        <span style={{ fontSize: "8.5px", fontStyle: "normal", fontWeight: "500", lineHeight: "10px", transition: "0.3s ease-in-out" }} className={`text-uppercase`}>Audience</span>
                        {/* <div className="m-auto" style={{ borderBottom: "2px solid rgba(0,0,0,0.4)", transition: "0.3s ease-in-out", width: sideNav === "audience" ? "25px" : "0px" }}></div> */}
                    </div>
                    <div className={`sideNav-items d-flex flex-column align-items-center justify-content-center ${sideNav === "display" ? "text-black active-item" : ""}`} style={{ gap: "0.5rem", cursor: "pointer", padding: "0.75rem 0px" }} onClick={() => setSideNav(sideNav === "display" ? "" : "display")}>
                        <button className={`btn d-flex align-items-center justify-content-center`} style={{ aspectRatio: "1", padding: "0rem", border: "none", outline: "none", transition: "0.3s ease-in-out" }}>
                            <Monitor size={15} />
                        </button>
                        <span style={{ fontSize: "8.5px", fontStyle: "normal", fontWeight: "500", lineHeight: "10px", transition: "0.3s ease-in-out" }} className={`text-uppercase`}>Display</span>
                        {/* <div className="m-auto" style={{ borderBottom: "2px solid rgba(0,0,0,0.4)", transition: "0.3s ease-in-out", width: sideNav === "display" ? "25px" : "0px" }}></div> */}
                    </div>
                    <div className={`sideNav-items d-flex flex-column align-items-center justify-content-center ${(sideNav === "add-elements" || sideNav === "button") ? "text-black active-item" : ""}`} style={{ gap: "0.5rem", cursor: "pointer", padding: "0.75rem 0px" }} onClick={() => {
                        if (currPage === "button") {
                            setSideNav(sideNav === "button" ? "" : "button")
                        } else {
                            setSideNav(sideNav === "add-elements" ? "" : "add-elements")
                        }
                        // setCurrPage("main")
                        // setIndexes({ cur: 0, curElem: "left", subElem: "grandparent" })
                        // setCurrPosition({ ...currPosition, selectedType: "main" })
                        // // const pageIndex = finalObj[`${mobileCondition}pages`].findIndex($ => $?.id === "main")
                        // // setcolWise([...finalObj[`${mobileCondition}pages`][pageIndex].values])
                        // setPopPosition(finalObj.positions[`${mobileCondition}main`])
                    }}>
                        <button className={`btn d-flex align-items-center justify-content-center`} style={{ aspectRatio: "1", padding: "0rem", border: "none", outline: "none", transition: "0.3s ease-in-out" }}>
                            <PlusCircle size={15} />
                        </button>
                        <span style={{ fontSize: "8.5px", fontStyle: "normal", fontWeight: "500", lineHeight: "10px", transition: "0.3s ease-in-out" }} className={`text-uppercase`}>Elements</span>
                        {/* <div className="m-auto" style={{ borderBottom: "2px solid rgba(0,0,0,0.4)", transition: "0.3s ease-in-out", width: sideNav === "add-elements" ? "25px" : "0px" }}></div> */}
                    </div>
                    <div className={`sideNav-items d-flex flex-column align-items-center justify-content-center ${sideNav === "offers" ? "text-black active-item" : ""}`} style={{ gap: "0.5rem", cursor: "pointer", padding: "0.75rem 0px" }} onClick={() => {
                        setSideNav(sideNav === "offers" ? "" : "offers")
                        setCurrPage("offers")
                    }}>
                        <button className={`btn d-flex align-items-center justify-content-center`} style={{ aspectRatio: "1", padding: "0rem", border: "none", outline: "none", transition: "0.3s ease-in-out" }}>
                            <Tag size={15} />
                        </button>
                        <span style={{ fontSize: "8.5px", fontStyle: "normal", fontWeight: "500", lineHeight: "10px", transition: "0.3s ease-in-out" }} className={`text-uppercase`}>Offers</span>
                        {/* <div className="m-auto" style={{ borderBottom: "2px solid rgba(0,0,0,0.4)", transition: "0.3s ease-in-out", width: sideNav === "offers" ? "25px" : "0px" }}></div> */}
                    </div>
                    <div className={`sideNav-items d-flex flex-column align-items-center justify-content-center ${sideNav === "criteria" ? "text-black active-item" : ""}`} style={{ gap: "0.5rem", cursor: "pointer", padding: "0.75rem 0px" }} onClick={() => setSideNav(sideNav === "criteria" ? "" : "criteria")}>
                        <button className={`btn d-flex align-items-center justify-content-center`} style={{ aspectRatio: "1", padding: "0rem", border: "none", outline: "none", transition: "0.3s ease-in-out" }}>
                            <Crosshair size={15} />
                        </button>
                        <span style={{ fontSize: "8.5px", fontStyle: "normal", fontWeight: "500", lineHeight: "10px", transition: "0.3s ease-in-out" }} className={`text-uppercase`}>Duration</span>
                        {/* <div className="m-auto" style={{ borderBottom: "2px solid rgba(0,0,0,0.4)", transition: "0.3s ease-in-out", width: sideNav === "criteria" ? "25px" : "0px" }}></div> */}
                    </div>
                </div>
                {/* Sidebar */}

                {/* Preview and Edit Section */}
                <div className="d-flex align-items-stretch flex-grow-1 h-100">
                    {/* Section Drawer */}
                    <div className=" border-end bg-white position-relative h-100" style={{ width: sideNav === "" ? "0px" : "240px", overflowX: "hidden", transition: "0.3s ease-in-out", opacity: "1", boxShadow: "10px 2px 5px rgba(0,0,0,0.125)", zIndex: "1" }}>
                        <div className='w-100' style={{ height: "100%", overflowY: "auto" }}>

                            {/* Theme Section */}
                            {sideNav === "theme" && <div style={{ transition: "0.3s ease-in-out", overflow: "auto", width: "240px", transform: `translateX(${sideNav === "theme" ? "0px" : "-240px"})`, position: "absolute", inset: "0px" }}>
                                <UncontrolledAccordion stayOpen defaultOpen={["1", "2"]}>
                                    <AccordionItem>
                                        <AccordionHeader className='acc-header border-top' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                            <label style={{ fontSize: "0.85rem" }} className="form-check-label m-0 p-0">Quick Setup</label>
                                        </AccordionHeader>

                                        <AccordionBody accordionId='1'>
                                            <div className="py-1">
                                                <label style={{ fontSize: "0.85rem" }} className="form-check-label m-0 p-0">Main Font</label>
                                                <Select value={fontStyles[fontStyles?.findIndex($ => $?.value === finalObj?.fontFamilies?.primary)]} id='font-select-primary' styles={{
                                                    option: (provided, state) => {
                                                        return ({ ...provided, fontFamily: fontStyles[fontStyles?.findIndex($ => $?.value === state.value)]?.value })
                                                    }
                                                }} options={fontStyles}
                                                    onChange={e => {
                                                        setFinalObj({ ...finalObj, fontFamilies: { ...finalObj.fontFamilies, primary: e.value } })
                                                    }}
                                                />
                                            </div>
                                            <div className="py-1">
                                                <label style={{ fontSize: "0.85rem" }} className="form-check-label m-0 p-0">Secondary Font</label>
                                                <Select value={fontStyles[fontStyles.findIndex($ => $?.value === finalObj?.fontFamilies?.secondary)]} id='font-select-secondary' styles={{
                                                    option: (provided, state) => {
                                                        return ({ ...provided, fontFamily: fontStyles[fontStyles?.findIndex($ => $?.value === state.value)]?.value })
                                                    }
                                                }} options={fontStyles}
                                                    onChange={e => {
                                                        setFinalObj({ ...finalObj, fontFamilies: { ...finalObj.fontFamilies, secondary: e.value } })
                                                    }}
                                                />
                                            </div>
                                            <div className="py-1">
                                                <label style={{ fontSize: "0.85rem" }} className="form-check-label m-0 p-0">Main Colour</label>
                                                {/* <div className='cursor-pointer' style={{ backgroundImage: `url(${pixels})` }}>
                                        <div className="py-1 rounded border" style={{ backgroundColor: finalObj?.defaultThemeColors?.primary }} onClick={() => {
                                            setCurrColor("primary")
                                            setCustomColorModal2(!customColorModal2)
                                        }}></div>
                                    </div> */}
                                                <div className=" rounded border cursor-pointer" style={{ backgroundImage: `url(${pixels})` }}>
                                                    <div onClick={() => {
                                                        currPage === "button" ? setBgModal3(!bgModal3) : setBgModal2(!bgModal2)
                                                    }} className="p-2 w-100" style={{ backgroundColor: currPage === "button" ? btnStyles?.backgroundColor : bgStyles?.backgroundColor, backgroundImage: currPage === "button" ? btnStyles.backgroundImage : bgStyles.backgroundImage }}></div>
                                                </div>
                                            </div>
                                            <div className="py-1">
                                                <label style={{ fontSize: "0.85rem" }} className="form-check-label m-0 p-0">Secondary Colour</label>
                                                <div className="d-flex align-items-center gap-1">
                                                    <div className='cursor-pointer flex-grow-1' style={{ backgroundImage: `url(${pixels})` }}>
                                                        <div className="p-1 rounded border" style={{ backgroundColor: finalObj?.defaultThemeColors?.secondary1 }} onClick={() => {
                                                            setCurrColor("secondary1")
                                                            setCustomColorModal2(!customColorModal2)
                                                        }}></div>

                                                    </div>
                                                    <div className='cursor-pointer flex-grow-1' style={{ backgroundImage: `url(${pixels})` }}>
                                                        <div className="p-1 rounded border" style={{ backgroundColor: finalObj?.defaultThemeColors?.secondary2 }} onClick={() => {
                                                            setCurrColor("secondary2")
                                                            setCustomColorModal2(!customColorModal2)
                                                        }}></div>

                                                    </div>
                                                    <div className='cursor-pointer flex-grow-1' style={{ backgroundImage: `url(${pixels})` }}>
                                                        <div className="p-1 rounded border" style={{ backgroundColor: finalObj?.defaultThemeColors?.secondary3 }} onClick={() => {
                                                            setCurrColor("secondary3")
                                                            setCustomColorModal2(!customColorModal2)
                                                        }}></div>

                                                    </div>
                                                    <div className='cursor-pointer flex-grow-1' style={{ backgroundImage: `url(${pixels})` }}>
                                                        <div className="p-1 rounded border" style={{ backgroundColor: finalObj?.defaultThemeColors?.secondary4 }} onClick={() => {
                                                            setCurrColor("secondary4")
                                                            setCustomColorModal2(!customColorModal2)
                                                        }}></div>

                                                    </div>
                                                </div>
                                            </div>
                                        </AccordionBody>
                                    </AccordionItem>
                                </UncontrolledAccordion>
                                <UncontrolledAccordion stayOpen defaultOpen={["1", "2"]}>
                                    <AccordionItem>
                                        <AccordionHeader className='acc-header border-top' targetId='1' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                            <label style={{ fontSize: "0.85rem" }} className="form-check-label m-0 p-0">Style</label>
                                        </AccordionHeader>
                                        <AccordionBody accordionId='1'>
                                            <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Background Fill</p>
                                            <div className='p-0 mx-0 my-1'>
                                                <div className=' p-0 justify-content- align-items-center gap-1'>
                                                    <span className='fw-bolder text-black' style={{ fontSize: "0.7rem" }}>Background:</span>
                                                    <div className=" rounded border cursor-pointer" style={{ backgroundImage: `url(${pixels})` }}>
                                                        <div onClick={() => {
                                                            currPage === "button" ? setBgModal3(!bgModal3) : setBgModal2(!bgModal2)
                                                        }} className="p-2 w-100" style={{ backgroundColor: currPage === "button" ? btnStyles?.backgroundColor : bgStyles?.backgroundColor, backgroundImage: currPage === "button" ? btnStyles.backgroundImage : bgStyles.backgroundImage }}></div>
                                                    </div>
                                                    <div className="d-flex align-items-center justify-content-between gap-1 form-check form-check-success m-0 p-0">
                                                        <label style={{ fontSize: "10px" }} className="form-check-label m-0 p-0">Keep same background for {isMobile ? "desktop theme" : "mobile theme"}</label>
                                                        <input
                                                            // checked={bgCheckedCondition}
                                                            type='checkbox' className='form-check-input m-0 p-0' onChange={(e) => {
                                                                const newObj = { ...finalObj }
                                                                if (e.target.checked) {
                                                                    if (finalObj?.responsive?.some($ => isEqual($?.position, "background"))) {
                                                                        const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, "background"))
                                                                        newObj?.responsive[responiveIndex]?.common?.push("backgroundColor")
                                                                        newObj.responsive[responiveIndex].common = [...newObj?.responsive[responiveIndex]?.common, "backgroundColor", "backgroundImage"]
                                                                    } else {
                                                                        newObj.responsive.push({ position: "background", common: ["backgroundColor", "backgroundImage"], page: currPage })
                                                                    }
                                                                } else {
                                                                    const responiveIndex = finalObj?.responsive?.findIndex($ => isEqual($?.position, "background"))
                                                                    newObj.responsive[responiveIndex].common = newObj?.responsive[responiveIndex]?.common?.filter(item => (item !== "backgroundColor") && (item !== "backgroundImage"))
                                                                }
                                                                setFinalObj({ ...newObj })
                                                            }} />
                                                    </div>
                                                </div>
                                            </div>
                                            <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Size</p>
                                            <div className='p-0 mx-0 my-1'>
                                                <div className='mb-1'>
                                                    <span className='fw-bolder text-black text-capitalize' style={{ fontSize: "0.7rem" }}>{isMobile ? "Max Width" : "Width"}: {currPage === "button" ? btnStyles[isMobile ? "maxWidth" : "width"] : bgStyles[isMobile ? "maxWidth" : "width"]}</span>
                                                    <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                                        <input type='range'
                                                            value={parseFloat(currPage === "button" ? btnStyles?.[isMobile ? "maxWidth" : "width"] : bgStyles?.[isMobile ? "maxWidth" : "width"])}
                                                            className='w-100' onChange={e => {
                                                                currPage === "button" ? setBtnStyles({ ...btnStyles, [e.target.name]: `${e.target.value}${isMobile ? "%" : "px"}` }) : setBgStyles({ ...bgStyles, [e.target.name]: `${e.target.value}${isMobile ? "%" : "px"}` })
                                                            }} name={isMobile ? "maxWidth" : "width"} min="25" max={isMobile ? "100" : "600"} />
                                                    </div>
                                                </div>
                                                <div className=''>
                                                    <span className='fw-bolder text-black' style={{ fontSize: "0.7rem" }}>Min-Height: {bgStyles?.minHeight}</span>
                                                    <div className="d-flex p-0 justify-content-between align-items-center gap-2">
                                                        <input type='range' value={parseFloat(currPage === "button" ? btnStyles.minHeight : bgStyles?.minHeight)} onChange={e => {
                                                            currPage === "button" ? setBtnStyles({ ...btnStyles, minHeight: `${e.target.value}px` }) : setBgStyles({ ...bgStyles, minHeight: `${e.target.value}px` })
                                                        }} className='w-100' name="height" min="50" max="650" />
                                                    </div>
                                                </div>
                                            </div>
                                            <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Border and Shadow</p>
                                            {currPage === "button" ? < BorderChange styles={btnStyles} setStyles={setBtnStyles} /> : <BorderChange styles={bgStyles} setStyles={setBgStyles} />}
                                        </AccordionBody>
                                    </AccordionItem>
                                    <AccordionItem>
                                        <AccordionHeader className='acc-header' targetId='2' style={{ borderBottom: '1px solid #EBE9F1', borderRadius: '0' }}>
                                            <label style={{ fontSize: "0.85rem" }} className="form-check-label m-0 p-0">Advanced</label>
                                        </AccordionHeader>
                                        <AccordionBody accordionId='2'>
                                            <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0px", fontSize: "0.75rem" }}>Spacing</p>
                                            <div className='p-0 mx-0 my-1'>
                                                <InputChange allValues={currPage === "button" ? btnStyles : bgStyles} setAllValues={currPage === "button" ? setBtnStyles : setBgStyles} type='padding' />
                                            </div>
                                            {currPage !== "button" && <div className='p-0 mx-0 my-1'>
                                                <InputChange allValues={bgStyles} setAllValues={setBgStyles} type='margin' />
                                            </div>}
                                        </AccordionBody>
                                    </AccordionItem>
                                </UncontrolledAccordion>
                                {/* <div className="container-fluid p-0 m-0">
                                    <div className="row p-1 m-0 w-100">
                                        {allPreviews?.map((ele, key) => {
                                            return (
                                                <div className="col-6" key={key}>
                                                    <div onClick={() => {
                                                        setFinalObj(ele?.object)
                                                        setSelectedThemeId(ele?.theme_id)
                                                        setcolWise(ele?.object?.pages[0]?.values)
                                                        setBgStyles(ele?.object?.backgroundStyles?.main)
                                                        setBtnStyles(ele?.object?.backgroundStyles?.button)
                                                        setCrossStyle(ele?.object?.crossButtons?.[currPage])
                                                    }} className="d-flex justify-content-center align-items-center mb-1 position-relative cursor-pointer" style={{ padding: "0.5rem", aspectRatio: "1", outline: `1px solid ${selectedThemeId === ele?.theme_id ? "#727272" : "lightgray"}`, transition: "0.3s ease-in-out", filter: "drop-shadow(0px 2px 5px rgba(0,0,0,0.25))" }}>
                                                        <img src={ele?.imagePrev} style={{ objectFit: "contain", maxWidth: "100%" }} alt="" />
                                                        <div className="position-absolute w-100 h-100 d-flex align-items-end" style={{ inset: "0px", backgroundColor: `rgba(0,0,0,0.25)`, opacity: selectedThemeId === ele?.theme_id ? "1" : "0", transition: "0.3s ease-in-out" }}>
                                                            <svg
                                                                className="position-absolute top-0 end-0"
                                                                width={25}
                                                                viewBox="0 0 320 320"
                                                                fill="none"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                            >
                                                                <path d="M319 1H2l317 317V1z" fill="#727272" stroke="#000" />
                                                                <path
                                                                    d="M178 84.52l22.943 32.766 69.296-48.521"
                                                                    stroke="#fff"
                                                                    strokeWidth={22}
                                                                />
                                                            </svg>
                                                            <div className="w-100 text-white bg-primary text-center" style={{ padding: "0.25rem", fontSize: "0.75rem" }}>
                                                                Current Theme
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            )
                                        })}
                                    </div>
                                </div> */}
                            </div>}
                            {/* Theme Section */}

                            {/* Audience Section */}
                            {sideNav === "audience" && <div style={{ transition: "0.3s ease-in-out", overflow: "hidden", width: "240px", transform: `translateX(${sideNav === "audience" ? "0px" : "-240px"})`, position: "absolute", inset: "0px" }}>
                                <UncontrolledAccordion defaultOpen={["1"]} stayOpen>
                                    <AccordionItem className='bg-white border-bottom'>
                                        <AccordionHeader className='acc-header border-bottom' targetId='1'>
                                            <p className='m-0 fw-bolder text-black text-uppercase' style={{ fontSize: "0.75rem" }}>Show Pop-up To</p>
                                        </AccordionHeader>
                                        <AccordionBody accordionId='1'>
                                            <div className='p-0 mx-0 my-1'>
                                                {/* <Select options={[
                                                        { value: 'chocolate', label: 'All Visitors' },
                                                        { value: 'strawberry', label: 'First Time Visitors' },
                                                        { value: 'vanilla', label: 'Returning Visitors' },
                                                        { value: 'blueberry', label: 'Registered Users' }
                                                        ]} /> */}
                                                <div className="form-check form-check mb-1">
                                                    <input type="radio" name='visitor_settings' checked={finalObj?.behaviour?.visitor_settings === "ALL_VISITORS"} onChange={e => {
                                                        setFinalObj({ ...finalObj, behaviour: { ...finalObj?.behaviour, visitor_settings: e.target.value } })
                                                    }} id='all' value={"ALL_VISITORS"} className="form-check-input cursor-pointer" /><label className="cursor-pointer" style={{ fontSize: "13px" }} htmlFor="all">All Visitors</label>
                                                </div>
                                                <div className="form-check form-check mb-1">
                                                    <input type="radio" name='visitor_settings' checked={finalObj?.behaviour?.visitor_settings === "FIRST_VISITORS"} onChange={e => {
                                                        setFinalObj({ ...finalObj, behaviour: { ...finalObj?.behaviour, visitor_settings: e.target.value } })
                                                    }} id='first' value={"FIRST_VISITORS"} className="form-check-input cursor-pointer" /><label htmlFor="first" className="cursor-pointer" style={{ fontSize: "13px" }}>First Time Visitors</label>
                                                </div>
                                                <div className="form-check form-check mb-1">
                                                    <input type="radio" name='visitor_settings' checked={finalObj?.behaviour?.visitor_settings === "RETURNING_VISITORS"} onChange={e => {
                                                        setFinalObj({ ...finalObj, behaviour: { ...finalObj?.behaviour, visitor_settings: e.target.value } })
                                                    }} id='return' value={"RETURNING_VISITORS"} className="form-check-input cursor-pointer" /><label htmlFor="return" className="cursor-pointer" style={{ fontSize: "13px" }}>Returning Visitors</label>
                                                </div>
                                                <div className="form-check form-check mb-1">
                                                    <input type="radio" name='visitor_settings' checked={finalObj?.behaviour?.visitor_settings === "REGISTERED_USERS"} onChange={e => {
                                                        setFinalObj({ ...finalObj, behaviour: { ...finalObj?.behaviour, visitor_settings: e.target.value } })
                                                    }} id='registered' value={"REGISTERED_USERS"} className="form-check-input cursor-pointer" /><label htmlFor="registered" className="cursor-pointer" style={{ fontSize: "13px" }}>Registered Users</label>
                                                </div>
                                                {/* <div className="form-check form-check mb-1">
                                                    <input type="radio" name='visitor_settings' checked={finalObj?.behaviour?.visitor_settings === "CUSTOMERS"} onChange={e => {
                                                        setFinalObj({ ...finalObj, behaviour: { ...finalObj.behaviour, visitor_settings: e.target.value } })
                                                    }} id='customers' value={"CUSTOMERS"} className="form-check-input cursor-pointer" /><label htmlFor="customers" className="cursor-pointer" style={{ fontSize: "13px" }}>Customers</label>
                                                </div> */}
                                            </div>
                                        </AccordionBody>
                                    </AccordionItem>
                                </UncontrolledAccordion>
                            </div>}
                            {/* Audience Section */}

                            {/* Display Section */}
                            {sideNav === "display" && <div style={{ transition: "0.3s ease-in-out", overflowY: "auto", width: "240px", transform: `translateX(${sideNav === "display" ? "0px" : "-240px"})`, position: "absolute", inset: "0px" }}>
                                <UncontrolledAccordion defaultOpen={['1', '2', '3', '4']} stayOpen>
                                    {/* Position */}
                                    <AccordionItem className='bg-white border-bottom'>
                                        <AccordionHeader className='acc-header border-bottom' targetId='1'>
                                            <p className='m-0 fw-bolder text-black text-uppercase' style={{ fontSize: "0.75rem" }}>Position</p>
                                        </AccordionHeader>
                                        <AccordionBody accordionId='1'>
                                            <div className='d-flex flex-column justify-content-center align-items-center mt-1 mb-2'>

                                                <label style={{ fontSize: "0.85rem" }} className="form-check-label m-0 p-0 align-self-start mb-1">{currPage === "button" ? "Button" : "Pop-up"} position</label>

                                                {!isMobile ? (
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 513 367.2" className='w-75'>
                                                        <path fill="#b5b9ba" d="M210.8 312.3H302.20000000000005V362.36H210.8z" />
                                                        <path fill="#8a9093" d="M154.2 362.3H358.79999999999995V367.2H154.2z" />
                                                        <path fill="#929699" d="M210.8 312.3H302.20000000000005V330.8H210.8z" />
                                                        <rect
                                                            x={0.5}
                                                            y={0.5}
                                                            width={512}
                                                            height={311.77}
                                                            rx={22.5}
                                                            ry={22.5}
                                                            fill="#323233"
                                                            stroke="#231f20"
                                                            strokeMiterlimit={10}
                                                        />
                                                        <path
                                                            d="M512 366a22.5 22.5 0 01-22.5 22.5h-467c-12.4 0 467-311.8 467-311.8A22.5 22.5 0 01512 99.2z"
                                                            transform="translate(.5 -76.2)"
                                                            fill="#2d2d2d" />
                                                        <path fill="#fff" d="M22.2 21.1H490.8V289.43H22.2z" />
                                                        <path
                                                            d="M489.8 97.9v267.3H22.2V97.9h467.6m1-1H21.2v269.3h469.6V96.9z"
                                                            transform="translate(.5 -76.2)"
                                                            fill="#231f20"
                                                        />
                                                        <path
                                                            d="M260.9 87.6a4.9 4.9 0 11-4.9-4.9 4.9 4.9 0 014.9 4.9z"
                                                            transform="translate(.5 -76.2)"
                                                            fill="#323031"
                                                        />
                                                        <path
                                                            d="M258.2 87.6a2.2 2.2 0 01-4.4 0 2.2 2.2 0 014.4 0z"
                                                            transform="translate(.5 -76.2)"
                                                            fill="#231f20"
                                                        />
                                                        <g>
                                                            <path
                                                                onClick={() => setPopPosition("TL")}
                                                                style={{ cursor: "pointer", transition: "0.3s ease" }}
                                                                fill={popPosition === "TL" ? "#464646" : "#ffffff"}
                                                                stroke="#231f20"
                                                                strokeMiterlimit={10}
                                                                className="mosaic"
                                                                d="M22.8 21.7H178.60000000000002V110.8H22.8z"
                                                            />
                                                            <path
                                                                onClick={() => setPopPosition("TC")}
                                                                style={{ cursor: "pointer", transition: "0.3s ease" }}
                                                                fill={popPosition === "TC" ? "#464646" : "#ffffff"}
                                                                stroke="#231f20"
                                                                strokeMiterlimit={10}
                                                                className="mosaic"
                                                                d="M178.6 21.7H334.4V110.8H178.6z"
                                                            />
                                                            <path
                                                                onClick={() => setPopPosition("TR")}
                                                                style={{ cursor: "pointer", transition: "0.3s ease" }}
                                                                fill={popPosition === "TR" ? "#464646" : "#ffffff"}
                                                                stroke="#231f20"
                                                                strokeMiterlimit={10}
                                                                className="mosaic"
                                                                d="M334.4 21.7H490.2V110.8H334.4z"
                                                            />
                                                            <path
                                                                onClick={() => setPopPosition("ML")}
                                                                style={{ cursor: "pointer", transition: "0.3s ease" }}
                                                                fill={popPosition === "ML" ? "#464646" : "#ffffff"}
                                                                stroke="#231f20"
                                                                strokeMiterlimit={10}
                                                                className="mosaic"
                                                                d="M22.8 110.8H178.60000000000002V199.89999999999998H22.8z"
                                                            />
                                                            <path
                                                                onClick={() => setPopPosition(currPage !== "button" ? "MC" : popPosition)}
                                                                style={{ cursor: "pointer", transition: "0.3s ease" }}
                                                                fill={currPage === "button" ? "#cccccc" : popPosition === "MC" ? "#464646" : "#ffffff"}
                                                                stroke="#231f20"
                                                                strokeMiterlimit={10}
                                                                className="mosaic selected"
                                                                d="M178.6 110.8H334.4V199.89999999999998H178.6z"
                                                            />
                                                            <path
                                                                onClick={() => setPopPosition("MR")}
                                                                style={{ cursor: "pointer", transition: "0.3s ease" }}
                                                                fill={popPosition === "MR" ? "#464646" : "#ffffff"}
                                                                stroke="#231f20"
                                                                strokeMiterlimit={10}
                                                                className="mosaic"
                                                                d="M334.4 110.8H490.2V199.89999999999998H334.4z"
                                                            />
                                                            <path
                                                                onClick={() => setPopPosition("BL")}
                                                                style={{ cursor: "pointer", transition: "0.3s ease" }}
                                                                fill={popPosition === "BL" ? "#464646" : "#ffffff"}
                                                                stroke="#231f20"
                                                                strokeMiterlimit={10}
                                                                className="mosaic"
                                                                d="M22.8 199.9H178.60000000000002V289H22.8z"
                                                            />
                                                            <path
                                                                onClick={() => setPopPosition("BC")}
                                                                style={{ cursor: "pointer", transition: "0.3s ease" }}
                                                                fill={popPosition === "BC" ? "#464646" : "#ffffff"}
                                                                stroke="#231f20"
                                                                strokeMiterlimit={10}
                                                                className="mosaic"
                                                                d="M178.6 199.9H334.4V289H178.6z"
                                                            />
                                                            <path
                                                                onClick={() => setPopPosition("BR")}
                                                                style={{ cursor: "pointer", transition: "0.3s ease" }}
                                                                fill={popPosition === "BR" ? "#464646" : "#ffffff"}
                                                                stroke="#231f20"
                                                                strokeMiterlimit={10}
                                                                className="mosaic"
                                                                d="M334.4 199.9H490.2V289H334.4z"
                                                            />
                                                        </g>
                                                    </svg>
                                                ) : currPage !== "button" ? (
                                                    <svg
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 184.45 367.2"
                                                        style={{ width: "55px" }}
                                                        property="globalStyle.overlay.mobilePosition"
                                                    >
                                                        <g id="mobile-position">
                                                            <rect x="11.76" y="239.71" width="162.2" height="116.24" onClick={() => setPopPosition("BC")} style={{ cursor: "pointer", transition: "0.3s ease" }} stroke="#231f20" fill={popPosition === "BC" ? "#464646" : "#ffffff"} />
                                                            <rect x="11.99" y="124.46" width="162.2" height="116.24" onClick={() => setPopPosition("MC")} style={{ cursor: "pointer", transition: "0.3s ease" }} stroke="#231f20" fill={popPosition === "MC" ? "#464646" : "#ffffff"} />
                                                            <rect x="11.61" y="9.2" width="162.2" height="116.24" onClick={() => setPopPosition("TC")} style={{ cursor: "pointer", transition: "0.3s ease" }} stroke="#231f20" fill={popPosition === "TC" ? "#464646" : "#ffffff"} />
                                                        </g>
                                                        <path
                                                            fill="#58595b"
                                                            d="M182.49,26.65A26.65,26.65,0,0,0,155.84,0H28.61A26.65,26.65,0,0,0,2,26.65v313.9A26.65,26.65,0,0,0,28.61,367.2H155.84a26.65,26.65,0,0,0,26.65-26.65ZM178.4,340.29a22.82,22.82,0,0,1-22.82,22.82H28.36A22.82,22.82,0,0,1,5.54,340.29V26.4A22.82,22.82,0,0,1,28.36,3.58H155.58A22.82,22.82,0,0,1,178.4,26.4Z"
                                                        />
                                                        <path
                                                            d="M2,48.47H1.72A1.72,1.72,0,0,0,0,50.19V60.65a1.71,1.71,0,0,0,1.72,1.71H2"
                                                        />
                                                        <path
                                                            d="M182.49,126.27h0a2,2,0,0,0,2-2V85.48a2,2,0,0,0-2-2h0"
                                                        />
                                                        <path
                                                            d="M2,75.21H2a2,2,0,0,0-2,2V99.25a2,2,0,0,0,2,2H2"
                                                        />
                                                        <path
                                                            d="M2,108.58H2a2,2,0,0,0-2,2v22.08a2,2,0,0,0,2,2H2"
                                                        />
                                                        <path
                                                            fill="#231f20"
                                                            d="M178.4,26.4A22.82,22.82,0,0,0,155.58,3.58H28.36A22.82,22.82,0,0,0,5.54,26.4V340.29a22.82,22.82,0,0,0,22.82,22.82H155.58a22.82,22.82,0,0,0,22.82-22.82ZM113.31,12.54a2.24,2.24,0,1,1-2.24-2.23A2.24,2.24,0,0,1,113.31,12.54ZM82.88,11.25h19.94a1.4,1.4,0,0,1,1.54,1.28,1.4,1.4,0,0,1-1.54,1.28H82.88a1.4,1.4,0,0,1-1.54-1.28A1.4,1.4,0,0,1,82.88,11.25Zm89.89,328.42c0,8.93-7.48,15.77-16.41,15.77H29a15.53,15.53,0,0,1-15.81-15.77V26A16,16,0,0,1,29,9.72H43.74c3.11,0,4.26,0,4.45,4,.2,4.1,3,6.33,6.82,7.53a14,14,0,0,0,4.1.27H126.4a14.07,14.07,0,0,0,4.11-.17c3.81-1.2,6.62-3.63,6.82-7.72s1.33-3.87,4.45-3.87h14.58A16.5,16.5,0,0,1,172.77,26Z"
                                                        />
                                                        <circle cx="111.07" cy="12.54" r="2.24" />
                                                        <path d="M82.88,13.81h19.94a1.4,1.4,0,0,0,1.54-1.28,1.4,1.4,0,0,0-1.54-1.28H82.88a1.4,1.4,0,0,0-1.54,1.28A1.4,1.4,0,0,0,82.88,13.81Z" />
                                                    </svg>
                                                ) : (
                                                    <svg
                                                        width={80}
                                                        height={162}
                                                        fill="none"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                    >
                                                        <rect x={1.5} y={0.5} width={77} height={161} rx={11.5} fill="#252626" />
                                                        <g clipPath="url(#clip0_529_46870)">
                                                            <rect x={5} y={4} width={70} height={154} rx={8} fill="#fff" />
                                                            <path style={{ cursor: "pointer", transition: "0.3s ease" }} onClick={() => setPopPosition("TC")}
                                                                fill={popPosition === "TC" ? "#727272" : "#fff"}
                                                                className="mobile-position-area"
                                                                d="M5.125 4.125H76.875V40.875H5.125z"
                                                            />
                                                            <path style={{ cursor: "pointer", transition: "0.3s ease" }} onClick={() => setPopPosition("TC")}
                                                                stroke="#313233"
                                                                strokeWidth={0.25}
                                                                d="M5.125 4.125H76.875V40.875H5.125z"
                                                            />
                                                            <path style={{ cursor: "pointer", transition: "0.3s ease" }} onClick={() => setPopPosition("ML")}
                                                                fill={popPosition === "ML" ? "#727272" : "#fff"}
                                                                className="mobile-position-area"
                                                                d="M5.125 41.125H40.875V120.875H5.125z"
                                                            />
                                                            <path style={{ cursor: "pointer", transition: "0.3s ease" }} onClick={() => setPopPosition("ML")}
                                                                stroke="#313233"
                                                                strokeWidth={0.25}
                                                                d="M5.125 41.125H40.875V120.875H5.125z"
                                                            />
                                                            <path style={{ cursor: "pointer", transition: "0.3s ease" }} onClick={() => setPopPosition("MR")}
                                                                fill={popPosition === "MR" ? "#727272" : "#fff"}
                                                                className="mobile-position-area selected"
                                                                d="M41.125 41.125H76.875V120.875H41.125z"
                                                            />
                                                            <path style={{ cursor: "pointer", transition: "0.3s ease" }} onClick={() => setPopPosition("MR")}
                                                                stroke="#313233"
                                                                strokeWidth={0.25}
                                                                d="M41.125 41.125H76.875V120.875H41.125z"
                                                            />
                                                            <path style={{ cursor: "pointer", transition: "0.3s ease" }} onClick={() => setPopPosition("BC")}
                                                                fill={popPosition === "BC" ? "#727272" : "#fff"}
                                                                className="mobile-position-area"
                                                                d="M5.125 121.125H76.875V157.875H5.125z"
                                                            />
                                                            <path style={{ cursor: "pointer", transition: "0.3s ease" }} onClick={() => setPopPosition("BC")}
                                                                stroke="#313233"
                                                                strokeWidth={0.25}
                                                                d="M5.125 121.125H76.875V157.875H5.125z"
                                                            />
                                                        </g>
                                                        <rect
                                                            x={5.25}
                                                            y={4.25}
                                                            width={69.5}
                                                            height={153.5}
                                                            rx={7.75}
                                                            stroke="#313233"
                                                            strokeWidth={0.5}
                                                        />
                                                        <rect
                                                            x={1.5}
                                                            y={0.5}
                                                            width={77}
                                                            height={161}
                                                            rx={11.5}
                                                            stroke="#585A5B"
                                                        />
                                                        <path fill="#252626" d="M0 21H1V27H0z" />
                                                        <path fill="#252626" d="M0 39H1V50H0z" />
                                                        <path fill="#252626" d="M79 43H80V61H79z" />
                                                        <path
                                                            d="M20.753 4.612A3 3 0 0123.689 1h32.622a3 3 0 012.937 3.612l-.417 2A3 3 0 0155.894 9H24.106a3 3 0 01-2.937-2.388l-.416-2z"
                                                            fill="#252626"
                                                        />
                                                        <path fill="#252626" d="M0 52H1V63H0z" />
                                                        <rect
                                                            x={45}
                                                            y={4}
                                                            width={1}
                                                            height={10}
                                                            rx={0.5}
                                                            transform="rotate(90 45 4)"
                                                            fill="#000"
                                                        />
                                                        <rect
                                                            x={48}
                                                            y={4}
                                                            width={1}
                                                            height={2}
                                                            rx={0.5}
                                                            transform="rotate(90 48 4)"
                                                            fill="#000"
                                                        />
                                                        <defs>
                                                            <clipPath id="clip0_529_46870">
                                                                <rect x={5} y={4} width={70} height={154} rx={8} fill="#fff" />
                                                            </clipPath>
                                                        </defs>
                                                    </svg>
                                                )
                                                }
                                            </div>
                                            {currPage === "button" && <div className='p-0 mx-0 mt-1 mb-2'>
                                                <label style={{ fontSize: "0.85rem" }} className="form-check-label m-0 p-0">Edge spacing</label>

                                                <InputChange hideLabel allValues={btnStyles} setAllValues={setBtnStyles} type='margin' />
                                            </div>}
                                        </AccordionBody>
                                    </AccordionItem>
                                    {/* Position */}

                                    {/* Website Overlay */}
                                    <AccordionItem className='bg-white border-bottom'>
                                        <AccordionHeader className='acc-header border-bottom' targetId='2'>
                                            <p className='m-0 fw-bolder text-black text-uppercase' style={{ fontSize: "0.75rem" }}>Overlay</p>
                                        </AccordionHeader>
                                        <AccordionBody accordionId='2'>
                                            <label style={{ fontSize: "0.85rem" }} className="form-check-label m-0 p-0">Background</label>
                                            <div className='cursor-pointer' style={{ backgroundImage: `url(${pixels})` }}>
                                                <div className="p-1 rounded border" style={{ ...bgsettings, backgroundImage: bgsettings?.backgroundImage }} onClick={() => setBgModal(!bgModal)}></div>
                                            </div>
                                        </AccordionBody>
                                    </AccordionItem>
                                    {/* Website Overlay */}

                                    {/* Popup Visibility */}

                                    <AccordionItem className='bg-white border-bottom'>
                                        <AccordionHeader className='acc-header border-bottom' targetId='3'>
                                            <p className='m-0 fw-bolder text-black text-uppercase' style={{ fontSize: "0.75rem" }}>Pop-up behaviour</p>
                                        </AccordionHeader>
                                        <AccordionBody accordionId='3'>
                                            <div className='p-0 mx-0 my-2'>
                                                <Select value={visibleOnOptions?.filter(item => finalObj?.behaviour?.pop_up_load_type === item?.value)} onChange={e => {
                                                    setFinalObj({ ...finalObj, behaviour: { ...finalObj.behaviour, pop_up_load_type: e.value, pop_up_load_value: "0" } })
                                                }} options={visibleOnOptions} />
                                            </div>
                                            {finalObj.behaviour.pop_up_load_type === "scroll" && (
                                                <div className="my-2">
                                                    <label style={{ fontSize: "12px" }} htmlFor="">Your pop up will be visible after scrolling {finalObj?.behaviour?.pop_up_load_value}% of the page</label>
                                                    <input type="range" step={10} min={0} max={100} value={finalObj.behaviour.pop_up_load_value} onChange={e => {
                                                        setFinalObj({ ...finalObj, behaviour: { ...finalObj.behaviour, pop_up_load_value: e.target.value } })
                                                    }} style={{ accentColor: "#727272" }} className='w-100 mt-1' />
                                                </div>
                                            )}
                                            {finalObj.behaviour.pop_up_load_type === "delay" && (
                                                <div className="my-2">
                                                    <label style={{ fontSize: "12px" }} htmlFor="">Your pop up will be visible {finalObj?.behaviour?.pop_up_load_value} seconds of loading</label>
                                                    <input type="range" min={0} max={120} value={finalObj?.behaviour?.pop_up_load_value} onChange={e => {
                                                        setFinalObj({ ...finalObj, behaviour: { ...finalObj?.behaviour, pop_up_load_value: e.target.value } })
                                                    }} style={{ accentColor: "#727272" }} className='w-100 mt-1' />
                                                </div>
                                            )}
                                            {(finalObj?.behaviour?.pop_up_load_type === "scroll" || finalObj?.behaviour?.pop_up_load_type === "delay") && (
                                                <div className='p-0 mx-0 my-1'>
                                                    <label htmlFor="" className='form-control-label' style={{ fontSize: "0.85rem" }} >Pop-up frequency: (appears {finalObj?.behaviour?.frequency ? finalObj?.behaviour?.frequency : "1"} time(s))</label>
                                                    <input value={finalObj?.behaviour?.frequency || 1} min={1} max={10} type="range" className='w-100' onChange={e => {
                                                        setFinalObj({ ...finalObj, behaviour: { ...finalObj?.behaviour, frequency: e.target.value } })
                                                    }} />
                                                </div>
                                            )}
                                        </AccordionBody>
                                    </AccordionItem>
                                    {/* Popup Visibility */}

                                    {/* Pop up Active status */}
                                    <AccordionItem className='bg-white border-bottom'>
                                        <AccordionHeader className='acc-header border-bottom' targetId='4'>
                                            <p className='m-0 fw-bolder text-black text-uppercase' style={{ fontSize: "0.75rem" }}>Pop-up visible on</p>
                                        </AccordionHeader>
                                        <AccordionBody accordionId='4'>
                                            <div className='p-0 mx-0 my-2'>
                                                {/* <Select isMulti closeMenuOnSelect={false} options={pagesSelection} /> */}
                                                <div className="row">
                                                    {pagesSelection?.map((ele, key) => {
                                                        return (
                                                            <div key={key} className="col-md-6 d-flex gap-2 align-items-start">
                                                                <input
                                                                    checked={finalObj?.behaviour?.PAGES?.includes(ele?.value)}
                                                                    className="d-none" value={ele?.value} onChange={addPage} type='checkbox' id={`page-${key}`} />
                                                                <label style={{ cursor: 'pointer' }} htmlFor={`page-${key}`} className="mb-2 text-capitalize d-flex flex-column align-items-center w-100 position-relative">
                                                                    {/* <div className='p-1 mb-2 rounded-2' style={themes[`themeData${selectedThemeNo}`].PAGES.includes(ele) ? { outline: '2px solid rgb(0, 128, 96)' } : {}}> */}
                                                                    <div className="position-relative w-50 d-flex justify-content-center align-items-center">
                                                                        <div className="position-absolute w-100" style={{ inset: "0px", outline: finalObj?.behaviour?.PAGES?.includes(ele.value) ? `1.5px solid rgba(0,0,0,1)` : `0px solid rgba(0,0,0,0)`, aspectRatio: "1", scale: finalObj?.behaviour?.PAGES?.includes(ele.value) ? "1.15" : "1.25", zIndex: "99999999", backgroundColor: `rgba(255,255,255,${finalObj?.behaviour?.PAGES?.includes(ele.value) ? "0" : "0.5"})`, transition: "0.3s ease-in-out" }}></div>
                                                                        <img width="100%" style={{ transition: '0.25s ease' }}
                                                                            className={`mb-2`} src={`${xircls_url}/plugin_other_images/icons/${ele.value === "custom_page" ? "all_pages" : ele.value}.png`}
                                                                            alt='no img' />
                                                                        {/* <img src="https://cdn-icons-png.flaticon.com/512/8373/8373208.png" className={`position-absolute opacity-${finalObj.behaviour.PAGES.includes(ele.value) ? "100" : '0'}`} style={{ top: '-7.5px', right: '-7.5px', transition: '0.25s ease' }} width={'20px'} height={'20px'} alt="" /> */}
                                                                    </div>
                                                                    <span className={`${finalObj?.behaviour?.PAGES?.includes(ele.value) ? "text-black" : ""} fw-bolder`} style={{ fontSize: '75%', textAlign: "center" }}>{ele?.label}</span>
                                                                </label>
                                                            </div>
                                                        )
                                                    })}
                                                </div>

                                                {finalObj?.behaviour?.PAGES?.includes("custom_page") && <div className="row mt-2">
                                                    <label htmlFor="" className='mb-1' style={{ fontSize: "12px" }}>Custom URLs:</label>
                                                    {finalObj?.behaviour?.CUSTOM_PAGE_LINK?.map((ele, key) => {
                                                        return (
                                                            <div className="col-12" key={key}>
                                                                <div className="p-0 position-relative d-flex align-items-center mb-1">
                                                                    <input style={{ fontSize: "12px" }} onChange={e => {
                                                                        const newObj = { ...finalObj }
                                                                        newObj.behaviour.CUSTOM_PAGE_LINK[key] = e.target.value
                                                                        setFinalObj(newObj)
                                                                    }} value={ele} className='form-control' type="text" placeholder={`www.url-example${key + 1}.com`} />{finalObj.behaviour.CUSTOM_PAGE_LINK.length > 1 && <span onClick={() => {
                                                                        const newObj = { ...finalObj }
                                                                        newObj?.behaviour?.CUSTOM_PAGE_LINK?.splice(key, 1)
                                                                        setFinalObj(newObj)
                                                                    }} className="d-flex justify-content-center alignn-items-center position-absolute end-0 p-1 cursor-pointer"><Trash stroke='red' size={12.5} /></span>}
                                                                </div>
                                                            </div>
                                                        )
                                                    })}
                                                    {finalObj.behaviour.CUSTOM_PAGE_LINK.length < 6 && <div className="col-12">
                                                        <button onClick={() => {
                                                            const newObj = { ...finalObj }
                                                            newObj.behaviour.CUSTOM_PAGE_LINK = [...finalObj.behaviour.CUSTOM_PAGE_LINK, ""]
                                                            setFinalObj(newObj)
                                                        }} style={{ padding: "5px" }} className="btn btn-dark w-100"><PlusCircle color='white' size={17.5} /></button>
                                                    </div>}
                                                </div>}
                                            </div>
                                        </AccordionBody>
                                    </AccordionItem>
                                    {/* Pop up Active status */}
                                </UncontrolledAccordion>
                            </div>}
                            {/* Display Section */}

                            {/* Elements section */}
                            {sideNav === "add-elements" && <div style={{ transition: "0.3s ease-in-out", overflow: "hidden", width: "240px", transform: `translateX(${sideNav === "add-elements" ? "0px" : "-240px"})`, position: "absolute", inset: "0px" }}>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0.5rem 0px", fontSize: "0.75rem" }}>Basic Elements</p>
                                <div className="toggleSection border-end d-flex align-items-start justify-content-start mb-1" style={{ flexWrap: "wrap" }}>
                                    {/* {getElementJsx({ draggable: true, dragStartFunc: (e) => handleDragStart(e, "text", "type"), icon: <Type size={17.5} />, label: "Text" })} */}
                                    <div style={{ width: `${100 / 3}%`, padding: "0.25rem" }}>
                                        <div draggable onDragStart={(e) => handleDragStart(e, "text", "type")} className="border rounded w-100 d-flex flex-column justify-content-between align-items-center p-1" style={{ aspectRatio: "1", cursor: "grab", gap: "0.5rem", boxShadow: "1px 1px 5px rgba(0,0,0,0.125)" }}>
                                            <Type color="#727272" size={17.5} />
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Text</span>
                                            <svg
                                                width={"35%"}
                                                viewBox="0 0 67 28"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <circle cx={5} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={5} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                            </svg>
                                        </div>
                                    </div>
                                    <div style={{ width: `${100 / 3}%`, padding: "0.25rem" }}>
                                        <div draggable onDragStart={(e) => handleDragStart(e, "image")} className="border rounded w-100 d-flex flex-column justify-content-between align-items-center p-1" style={{ aspectRatio: "1", cursor: "grab", gap: "0.5rem", boxShadow: "1px 1px 5px rgba(0,0,0,0.125)" }}>
                                            <Image color="#727272" size={17.5} />
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Image</span>
                                            <svg
                                                width={"35%"}
                                                viewBox="0 0 67 28"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <circle cx={5} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={5} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                            </svg>
                                        </div>
                                    </div>
                                    <div style={{ width: `${100 / 3}%`, padding: "0.25rem" }}>
                                        <div draggable onDragStart={(e) => handleDragStart(e, "button")} className="border rounded w-100 d-flex flex-column justify-content-between align-items-center p-1" style={{ aspectRatio: "1", cursor: "grab", gap: "0.5rem", boxShadow: "1px 1px 5px rgba(0,0,0,0.125)" }}>
                                            <Square color="#727272" fill="#727272" size={17.5} style={{ scale: "225% 100%" }} />
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Button</span>
                                            <svg
                                                width={"35%"}
                                                viewBox="0 0 67 28"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <circle cx={5} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={5} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                            </svg>
                                        </div>
                                    </div>
                                    {/* <div style={{ width: "80px", padding: "0.25rem" }}>
                                        <div draggable onDragStart={(e) => handleDragStart(e, "text", "type")} className="border rounded text-danger w-100 d-flex flex-column justify-content-between align-items-center p-1 gap-1" style={{ aspectRatio: "1", cursor: "grab" }}>
                                            <Type size={17.5} />
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Text</span>
                                        </div>
                                    </div> */}
                                    {/* <div style={{ width: "80px", padding: "0.5rem" }}>
                                        <div draggable onDragStart={(e) => handleDragStart(e, "image")} className="border rounded text-info w-100 d-flex flex-column justify-content-between align-items-center p-1 gap-1" style={{ aspectRatio: "1", cursor: "grab" }}>
                                            <Image size={17.5} />
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Image</span>
                                        </div>
                                    </div> */}
                                    {/* <div style={{ width: "80px", padding: "0.5rem" }}>
                                        <div draggable onDragStart={(e) => handleDragStart(e, "button")} className="border rounded text-success w-100 d-flex flex-column justify-content-between align-items-center p-1 gap-1" style={{ aspectRatio: "1", cursor: "grab" }}>
                                            <Square size={17.5} />
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Button</span>
                                        </div>
                                    </div> */}
                                </div>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0.5rem 0px", fontSize: "0.75rem" }}>Form Elements</p>
                                <div className="toggleSection border-end d-flex align-items-start justify-content-start mb-1">
                                    <div style={{ width: `${100 / 3}%`, padding: "0.25rem" }}>
                                        <div draggable onDragStart={(e) => handleDragStart(e, "input")} className="border rounded text-black w-100 d-flex flex-column justify-content-between align-items-center p-1" style={{ aspectRatio: "1", cursor: "grab", gap: "0.5rem", boxShadow: "1px 1px 5px rgba(0,0,0,0.125)" }}>
                                            <svg
                                                xmlns="http://www.w3.org/2000/svg"
                                                fill="none"
                                                viewBox="0 0 52 52"
                                                width={25}
                                            >
                                                <path
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fillRule="evenodd"
                                                    clipRule="evenodd"
                                                    d="M44 17H8a2 2 0 00-2 2v14a2 2 0 002 2h36a2 2 0 002-2V19a2 2 0 00-2-2zM8 15a4 4 0 00-4 4v14a4 4 0 004 4h36a4 4 0 004-4V19a4 4 0 00-4-4H8z"
                                                    fill="#727272"
                                                />
                                                <path
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fillRule="evenodd"
                                                    clipRule="evenodd"
                                                    d="M10 20a1 1 0 011 1v10a1 1 0 11-2 0V21a1 1 0 011-1z"
                                                    fill="#727272"
                                                />
                                            </svg>
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Input</span>
                                            <svg
                                                width={"35%"}
                                                viewBox="0 0 67 28"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <circle cx={5} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={5} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                            </svg>
                                        </div>
                                    </div>
                                    {/* <div draggable onDragStart={(e) => handleDragStart(e, "input")} className="border rounded text-black w-100 d-flex flex-column justify-content-between align-items-center p-1 gap-1" style={{ aspectRatio: "1", cursor: "grab" }}>
                                            <svg
                                                xmlns="http://www.w3.org/2000/svg"
                                                fill="none"
                                                viewBox="0 0 52 52"
                                                width={25}
                                            >
                                                <path
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fillRule="evenodd"
                                                    clipRule="evenodd"
                                                    d="M44 17H8a2 2 0 00-2 2v14a2 2 0 002 2h36a2 2 0 002-2V19a2 2 0 00-2-2zM8 15a4 4 0 00-4 4v14a4 4 0 004 4h36a4 4 0 004-4V19a4 4 0 00-4-4H8z"
                                                    fill="#727272"
                                                />
                                                <path
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    fillRule="evenodd"
                                                    clipRule="evenodd"
                                                    d="M10 20a1 1 0 011 1v10a1 1 0 11-2 0V21a1 1 0 011-1z"
                                                    fill="#727272"
                                                />
                                            </svg>
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Input</span>
                                        </div> */}
                                </div>
                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ padding: "0.5rem 0.5rem 0px", fontSize: "0.75rem" }}>Structured Elements</p>
                                <div className="toggleSection border-end d-flex align-items-start justify-content-start mb-1">
                                    {/* <div style={{ width: "80px", padding: "0.5rem" }}>
                                        <div draggable onDragStart={(e) => handleDragStart(e, "col1")} className="border rounded text-dark w-100 d-flex flex-column justify-content-between align-items-center p-1 gap-1" style={{ aspectRatio: "1", cursor: "grab" }}>
                                            <Square size={17.5} />
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Block</span>
                                        </div>
                                    </div> */}
                                    <div style={{ width: `${100 / 3}%`, padding: "0.25rem" }}>
                                        <div draggable onDragStart={(e) => handleDragStart(e, "col1")} className="border rounded text-dark w-100 d-flex flex-column justify-content-between align-items-center p-1" style={{ aspectRatio: "1", cursor: "grab", gap: "0.5rem", boxShadow: "1px 1px 5px rgba(0,0,0,0.125)" }}>
                                            <Square size={17.5} />
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Block</span>
                                            <svg
                                                width={"35%"}
                                                viewBox="0 0 67 28"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <circle cx={5} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={5} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </div>}
                            {/* Elements section */}

                            {/* Button Section */}
                            {sideNav === "button" && <div style={{ transition: "0.3s ease-in-out", overflow: "hidden", width: "240px", transform: `translateX(${sideNav === "button" ? "0px" : "-240px"})`, position: "absolute", inset: "0px" }}>
                                <div style={{ flexWrap: "wrap" }} className="toggleSection border-end d-flex align-items-start justify-content-start mb-1">
                                    <div style={{ width: `${100 / 3}%`, padding: "0.25rem" }}>
                                        <div draggable onDragStart={(e) => handleDragStart(e, "text", "type")} className="border rounded w-100 d-flex flex-column justify-content-between align-items-center p-1" style={{ aspectRatio: "1", cursor: "grab", gap: "0.5rem", boxShadow: "1px 1px 5px rgba(0,0,0,0.125)" }}>
                                            <Type color="#727272" size={17.5} />
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Text</span>
                                            <svg
                                                width={"35%"}
                                                viewBox="0 0 67 28"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <circle cx={5} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={5} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                            </svg>
                                        </div>
                                    </div>
                                    <div style={{ width: `${100 / 3}%`, padding: "0.25rem" }}>
                                        <div draggable onDragStart={(e) => handleDragStart(e, "image")} className="border rounded w-100 d-flex flex-column justify-content-between align-items-center p-1" style={{ aspectRatio: "1", cursor: "grab", gap: "0.5rem", boxShadow: "1px 1px 5px rgba(0,0,0,0.125)" }}>
                                            <Image color="#727272" size={17.5} />
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Image</span>
                                            <svg
                                                width={"35%"}
                                                viewBox="0 0 67 28"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <circle cx={5} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={5} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                            </svg>
                                        </div>
                                    </div>
                                    {/* <div style={{ width: `${100 / 3}%`, padding: "0.25rem" }}>
                                        <div draggable onDragStart={(e) => handleDragStart(e, "icon")} className="border rounded w-100 d-flex flex-column justify-content-between align-items-center p-1" style={{ aspectRatio: "1", cursor: "grab", gap: "0.5rem", boxShadow: "1px 1px 5px rgba(0,0,0,0.125)" }}>
                                            <Image color="#727272" size={17.5} />
                                            <span className='text-black' style={{ fontSize: "0.75rem" }}>Icon</span>
                                            <svg
                                                width={"35%"}
                                                viewBox="0 0 67 28"
                                                fill="none"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <circle cx={5} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={5} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={24} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={43} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                <circle cx={62} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                            </svg>
                                        </div>
                                    </div> */}
                                </div>
                            </div>}
                            {/* Button Section */}

                            {/* Offer Section */}
                            {sideNav === "offers" && (
                                <div style={{ transition: "0.3s ease-in-out", overflow: "hidden", width: "240px", transform: `translateX(${sideNav === "offers" ? "0px" : "-240px"})`, position: "absolute", inset: "0px", maxHeight: "100%", overflow: "auto" }}>
                                    <div className="toggleSection border-end d-flex align-items-start justify-content-start mb-1">
                                        {/* <div style={{ width: "80px", padding: "0.5rem" }}>
                                            <div draggable={isOfferDraggable} onDragStart={(e) => {
                                                if (isOfferDraggable) {
                                                    handleDragStart(e, "offer", "type")
                                                }
                                            }} className="border rounded w-100 d-flex flex-column justify-content-between align-items-center p-1 gap-1" style={{ aspectRatio: "1", cursor: isOfferDraggable ? "grab" : "default", color: "rgb(255, 103, 28)", opacity: isOfferDraggable ? "1" : "0.5" }}>
                                                <Percent color='rgb(255, 103, 28)' size={17.5} />
                                                <span className='fw-bolder text-black' style={{ fontSize: "0.75rem" }}>Offer</span>
                                            </div>
                                        </div> */}
                                        <div style={{ width: `${100 / 3}%`, padding: "0.25rem" }}>
                                            <div draggable={isMobile ? phoneIsOfferDraggable : isOfferDraggable} onDragStart={(e) => {
                                                if (isMobile ? phoneIsOfferDraggable : isOfferDraggable) {
                                                    handleDragStart(e, "offer", "type")
                                                }
                                            }} className="border rounded w-100 d-flex flex-column justify-content-between align-items-center p-1" style={{ aspectRatio: "1", cursor: "grab", gap: "0.5rem", boxShadow: "1px 1px 5px rgba(0,0,0,0.125)", cursor: isOfferDraggable ? "grab" : "default", opacity: isOfferDraggable ? "1" : "0.5" }}>
                                                <Percent color='rgb(255, 103, 28)' size={17.5} />
                                                <span className='text-black' style={{ fontSize: "0.75rem" }}>Offer</span>
                                                <svg
                                                    width={"35%"}
                                                    viewBox="0 0 67 28"
                                                    fill="none"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                >
                                                    <circle cx={5} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                    <circle cx={24} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                    <circle cx={43} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                    <circle cx={62} cy={5} r={3.5} stroke="#727272" strokeWidth={3} />
                                                    <circle cx={5} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                    <circle cx={24} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                    <circle cx={43} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                    <circle cx={62} cy={23} r={3.5} stroke="#727272" strokeWidth={3} />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                    {/* {gotOffers ? (
                                        allOffers.map((ele, key) => {
                                            return (
                                                <div key={key}>
                                                    {ele.Code}
                                                </div>
                                            )
                                        })
                                    ) : (
                                        <div className="d-flex justify-content-center">
                                            <svg
                                                xmlns="http://www.w3.org/2000/svg"
                                                x="0px"
                                                y="0px"
                                                viewBox="0 0 100 100"
                                                xmlSpace="preserve"
                                            >
                                                <path
                                                    fill="#fff"
                                                    d="M73 50c0-12.7-10.3-23-23-23S27 37.3 27 50m3.9 0c0-10.5 8.5-19.1 19.1-19.1S69.1 39.5 69.1 50"
                                                >
                                                    <animateTransform
                                                        attributeName="transform"
                                                        attributeType="XML"
                                                        type="rotate"
                                                        dur="1s"
                                                        from="0 50 50"
                                                        to="360 50 50"
                                                        repeatCount="indefinite"
                                                    />
                                                </path>
                                            </svg>
                                        </div>
                                    )} */}

                                    <UncontrolledAccordion defaultOpen={['1']} stayOpen>
                                        <AccordionItem className='bg-white border-bottom'>
                                            <AccordionHeader className='acc-header border-bottom' targetId='1'>
                                                <p className='m-0 fw-bolder text-black text-uppercase' style={{ fontSize: "0.75rem" }}>Select Offers</p>
                                            </AccordionHeader>
                                            <AccordionBody accordionId='1'>
                                                {(gotOffers && Array.isArray(allOffers)) ? allOffers?.map((ele, key) => {
                                                    // const { offer_json } = ele
                                                    // const replacedJson = offer_json.replaceAll(`'`, '"').replaceAll(`None`, `"none"`).replaceAll("False", false)
                                                    return (
                                                        // <div className='p-0 mx-0 mt-1 mb-3'>
                                                        //     <div style={{
                                                        //         flexDirection: 'column',
                                                        //         justifyContent: 'center',
                                                        //         alignItems: 'center',
                                                        //         position: "relative"
                                                        //     }} onClick={() => {
                                                        //         if (finalObj?.selectedOffers?.some($ => $?.Code === ele.Code)) {
                                                        //             const newArr = [...finalObj.selectedOffers]
                                                        //             setFinalObj({ ...finalObj, selectedOffers: [...newArr?.filter(item => item.Code !== ele.Code)] })
                                                        //         } else {
                                                        //             setFinalObj({ ...finalObj, selectedOffers: [...finalObj?.selectedOffers, ele] })
                                                        //         }
                                                        //     }}>
                                                        //         <div style={{
                                                        //             width: '100%',
                                                        //             minHeight: '100%',
                                                        //             justifyContent: 'center',
                                                        //             // boxShadow: 'rgba(0, 0, 0, 0.125) 10px 2px 5px',
                                                        //             filter: 'drop-shadow(rgba(0, 0, 0, 0.2) 0px 0px 10px',
                                                        //             borderRadius: '10px',
                                                        //             display: 'flex',
                                                        //             position: "relative",
                                                        //             backgroundColor: 'white',
                                                        //             cursor: "pointer",
                                                        //             outline: `2px solid ${finalObj?.selectedOffers?.some($ => $?.Code === ele.Code) ? "#FF671C" : "rgba(0,0,0,0)"}`
                                                        //         }}>
                                                        //             {finalObj?.selectedOffers?.some($ => $?.Code === ele?.Code) && <span style={{ position: "absolute", inset: "0px 0px auto auto", transform: `translateX(35%) translateY(-35%)`, width: "25px", aspectRatio: "1", display: "flex", justifyContent: "center", alignItems: "center", color: "#FF671C", backgroundColor: "white", borderRadius: "100px", zIndex: "99999999999", border: "2px solid #FF671C" }}>{(finalObj?.selectedOffers?.findIndex($ => $?.Code === ele.Code)) + 1}</span>}
                                                        //             <div className='flex-grow-1 d-flex flex-column justify-content-between' style={{ padding: '0.5rem' }}>
                                                        //                 <div style={{ text: 'wrap' }}>
                                                        //                     <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'start', justifyContent: 'start', textTransform: 'uppercase' }}>
                                                        //                         <h2 style={{ fontWeight: 'bolder', fontSize: '0.9rem', color: '#FF671C' }}>
                                                        //                             {ele?.Code}
                                                        //                         </h2>
                                                        //                         <span style={{ textTransform: 'lowercase', fontSize: '0.75rem', color: 'black' }}>
                                                        //                             {ele?.Summary}
                                                        //                         </span>
                                                        //                     </div>
                                                        //                 </div>
                                                        //                 <div>
                                                        //                     <div style={{ paddingTop: '0.5rem' }}>
                                                        //                         <span style={{ color: 'black', textTransform: 'uppercase', fontWeight: '500', fontSize: '0.65rem' }}>
                                                        //                             valid until: {ele?.ValidityPeriod?.end ? moment(ele?.ValidityPeriod?.end).format('L') : "Never ending"}
                                                        //                         </span>
                                                        //                     </div>
                                                        //                 </div>
                                                        //             </div>
                                                        //             <div style={{ display: 'flex', flexDirection: 'column', gap: "0.5rem", padding: "0px 0.5rem 0.5rem" }}>
                                                        //                 <div style={{
                                                        //                     position: 'relative',
                                                        //                     display: 'flex',
                                                        //                     flexDirection: 'column',
                                                        //                     justifyContent: 'space-between',
                                                        //                     alignItems: 'center',
                                                        //                     backgroundColor: '#FF671C',
                                                        //                     // filter: `hue-rotate(${i * (i + 20)}deg)`,
                                                        //                     padding: "1rem 0.25rem"
                                                        //                 }}>
                                                        //                     <h1 style={{
                                                        //                         fontSize: '1.829rem',
                                                        //                         fontWeight: '750',
                                                        //                         fontFamily: 'Montserrat',
                                                        //                         color: 'white'
                                                        //                     }}>

                                                        //                         {
                                                        //                             ele?.Type === "PERCENTAGE" ? (
                                                        //                                 `${Number(ele?.Value)?.toFixed(0)}%`
                                                        //                             ) : `₹${Number(ele?.Value)?.toFixed(0)}`
                                                        //                         }
                                                        //                     </h1>
                                                        //                 </div>
                                                        //                 <div style={{
                                                        //                     display: 'flex',
                                                        //                     flexDirection: 'column',
                                                        //                     justifyContent: 'flex-end',
                                                        //                     alignItems: 'center'
                                                        //                 }}>
                                                        //                     <button type="button" style={{
                                                        //                         color: '#FF671C',
                                                        //                         // filter: `hue-rotate(${i * (i + 20)}deg)`,
                                                        //                         fontSize: '0.65rem',
                                                        //                         fontWeight: '700',
                                                        //                         cursor: 'pointer',
                                                        //                         border: '0.75px solid #FF671C',
                                                        //                         borderRadius: '15px',
                                                        //                         padding: '0.195rem',
                                                        //                         backgroundColor: 'transparent',
                                                        //                         textTransform: 'uppercase',
                                                        //                         cursor: 'pointer'
                                                        //                     }}>
                                                        //                         <span >
                                                        //                             Redeem
                                                        //                         </span>
                                                        //                     </button>
                                                        //                 </div>
                                                        //             </div>
                                                        //         </div>
                                                        //         {/* <div style={{
                                                        //             width: '80%',
                                                        //             // margin: '-0.5rem auto',
                                                        //             position: 'absolute',
                                                        //             bottom: "0px",
                                                        //             backgroundColor: 'white',
                                                        //             textAlign: 'center',
                                                        //             padding: '0.1rem 0.1rem',
                                                        //             borderRadius: '10px',
                                                        //             boxShadow: '0 4px 24px 0 rgba(34, 41, 47, 0.15)',
                                                        //             transform: "translate(-50%, 50%)",
                                                        //             left: "50%"
                                                        //         }}>
                                                        //             <span style={{ textTransform: 'lowercase', fontSize: '0.75rem', color: 'black', fontWeight: '300' }}>
                                                        //                 Used xyz times
                                                        //             </span>
                                                        //         </div> */}
                                                        //     </div>
                                                        // </div>
                                                        <span className="position-relative" style={{ cursor: "pointer", outline: `2px solid ${finalObj?.selectedOffers?.some($ => $?.Code === ele.Code) ? "#FF671C" : "rgba(0,0,0,0)"}` }} onClick={() => {
                                                            if (finalObj?.selectedOffers?.some($ => $?.Code === ele.Code)) {
                                                                const newArr = [...finalObj.selectedOffers]
                                                                setFinalObj({ ...finalObj, selectedOffers: [...newArr?.filter(item => item.Code !== ele.Code)] })
                                                            } else {
                                                                setFinalObj({ ...finalObj, selectedOffers: [...finalObj?.selectedOffers, ele] })
                                                            }
                                                        }}>
                                                            {/* {finalObj?.selectedOffers?.some($ => $?.Code === ele?.Code) && <span style={{ position: "absolute", inset: "0px 0px auto auto", transform: `translateX(35%) translateY(-35%)`, width: "25px", aspectRatio: "1", display: "flex", justifyContent: "center", alignItems: "center", color: "#FF671C", backgroundColor: "white", borderRadius: "100px", zIndex: "99999999999", border: "2px solid #FF671C" }}>{(finalObj?.selectedOffers?.findIndex($ => $?.Code === ele.Code)) + 1}</span>} */}
                                                            <ReturnOfferHtml details={ele} key={key} theme={offerTheme} colors={finalObj?.offerProperties?.colors} />
                                                        </span>
                                                    )
                                                }) : (
                                                    <div className="d-flex justify-content-center align-items-center" style={{ inset: "0px", backgroundColor: "rgba(255,255,255,0.5)" }}>
                                                        <Spinner />
                                                    </div>
                                                )}
                                                <div><button onClick={() => navigate("/merchant/SuperLeadz/create_offers/")} className="btn btn-dark w-100">Add{allOffers?.length >= 1 ? " more" : ""} offers</button></div>
                                            </AccordionBody>
                                        </AccordionItem>
                                    </UncontrolledAccordion>
                                </div>
                            )}
                            {/* Offer Section */}

                            {/* Criteria section */}
                            {sideNav === "criteria" && <div style={{ transition: "0.3s ease-in-out", overflow: "hidden", width: "240px", transform: `translateX(${sideNav === "criteria" ? "0px" : "-240px"})`, position: "absolute", inset: "0px" }}>
                                <UncontrolledAccordion defaultOpen={['1', '2']} stayOpen>
                                    <AccordionItem className='bg-white border-bottom'>
                                        <AccordionHeader className='acc-header border-bottom' targetId='1'>
                                            <p className='m-0 fw-bolder text-black text-uppercase' style={{ fontSize: "0.75rem" }}>Campaign Duration</p>
                                        </AccordionHeader>
                                        <AccordionBody accordionId='1'>
                                            <div className='p-0 mx-0 my-1'>
                                                <label htmlFor="" className='form-control-label' style={{ fontSize: "0.85rem" }} >Start Date</label>
                                                <PickerDefault picker={campaignStart} minDate={"today"} maxDate={campaignEnd} dateFormat={"Y-m-d h:i K"} enableTime={true} setPicker={setCampaignStart} />
                                                <div className="form-check d-flex align-items-center gap-1 mx-0 p-0 my-2">
                                                    <label style={{ fontSize: "0.85rem" }} htmlFor="endDateCheck" className="form-check-label m-0 p-0">Set end date</label><input id='endDateCheck' checked={finalObj.campaignHasEndDate} type="checkbox" onChange={e => setFinalObj({ ...finalObj, campaignHasEndDate: e.target.checked })} className="form-check-input m-0 cursor-pointer" />
                                                </div>
                                                {finalObj.campaignHasEndDate && (
                                                    <>
                                                        <label htmlFor="" className='form-control-label' style={{ fontSize: "0.85rem" }} >End Date</label>
                                                        <PickerDefault picker={campaignEnd} minDate={campaignStart} dateFormat={"Y-m-d h:i K"} enableTime={true} setPicker={setCampaignEnd} />
                                                    </>
                                                )}
                                            </div>
                                        </AccordionBody>
                                    </AccordionItem>
                                    {/* <AccordionItem className='bg-white border-bottom'>
                                        <AccordionHeader className='acc-header border-bottom' targetId='2'>
                                            <p className='m-0 fw-bolder text-black text-uppercase' style={{ fontSize: "0.75rem" }}>Frequency</p>
                                        </AccordionHeader>
                                        <AccordionBody accordionId='2'>
                                            <div className='p-0 mx-0 my-1'>
                                                <label htmlFor="" className='form-control-label' style={{ fontSize: "0.85rem" }} >Pop-up frequency: (appears {finalObj?.behaviour?.frequency ? finalObj?.behaviour?.frequency : "1"} time(s))</label>
                                                <input value={finalObj?.behaviour?.frequency || 1} min={1} max={10} type="range" onChange={e => {
                                                    setFinalObj({ ...finalObj, behaviour: { ...finalObj.behaviour, frequency: e.target.value } })
                                                }} />
                                            </div>
                                        </AccordionBody>
                                    </AccordionItem> */}
                                    {/* <AccordionItem className='bg-white border-bottom'>
                                        <AccordionHeader className='acc-header border-bottom' targetId='2'>
                                        <p className='m-0 fw-bolder text-black' style={{ fontSize: "0.9rem"  }}>Show Pop-up To</p>
                                        </AccordionHeader>
                                        <AccordionBody accordionId='2'>
                                        <div className='p-0 mx-0 my-1'>
                                        <Select options={[
                                        { value: 'chocolate', label: 'All Visitors' },
                                        { value: 'strawberry', label: 'First Time Visitors' },
                                        { value: 'vanilla', label: 'Returning Visitors' },
                                        { value: 'blueberry', label: 'Registered Users' }
                                        ]} />
                                        
                                        </div>
                                        </AccordionBody>
                                    </AccordionItem> */}

                                    {/* <AccordionItem className='bg-white border-bottom'>
                                        <AccordionHeader className='acc-header border-bottom' targetId='3'>
                                            <p className='m-0 fw-bolder text-black text-uppercase' style={{ fontSize: "0.75rem" }}>User Verification</p>
                                        </AccordionHeader>
                                        <AccordionBody accordionId='3'>
                                            <div className='p-0 mx-0 my-1'>
                                                <div className='d-flex p-0 justify-content-between align-items-center form-check form-switch form-check-dark'>
                                                    <label style={{ fontSize: "0.85rem" }} className='form-check-label'>Skip user verification? </label>
                                                    <input type='checkbox' className='form-check-input' style={{ cursor: 'pointer' }} />
                                                </div>
                                            </div>
                                        </AccordionBody>
                                    </AccordionItem> */}
                                </UncontrolledAccordion>
                            </div>}
                            {/* Criteria section */}
                        </div>

                    </div>
                    {/* Section Drawer */}
                    {/* Theme Preview */}
                    <div className="d-flex flex-column flex-grow-1 align-items-center bg-light-secondary">
                        <div className="flex-grow-1 w-100 preview-section border-end d-flex justify-content-center align-items-stretch p-1 bg-white position-relative overflow-auto overflow-x-hidden">
                            <div style={{ width: isMobile ? "300px" : '100%' }} className="h-100 border d-flex flex-column align-items-stretch justify-content-start m-auto">
                                <div className='nav-bar d-flex justify-content-between align-items-center rounded-top gap-2' style={{ backgroundColor: '#D7DBDF', padding: '0.5rem' }}>
                                    <div className="d-flex justify-content-start align-items-center flex-grow-1">
                                        <div className='d-flex justify-content-start align-items-center bg-white rounded-pill w-100' style={{ marginLeft: '1.5rem', padding: '0.25rem 1.25rem', gap: '0.5rem', width: '30rem' }}><Lock size={12} /><span style={{ fontSize: '0.9rem' }}>{outletData[0]?.web_url || ""}</span></div>
                                    </div>
                                    {!isMobile && <div className='d-flex justify-content-end align-items-center' style={{ gap: '0.75rem', marginRight: '1.25rem' }}>
                                        <div className='rounded-circle' style={{ padding: '0.5rem', backgroundColor: '#22c55e' }}></div>
                                        <div className='rounded-circle' style={{ padding: '0.5rem', backgroundColor: '#f59e0b' }}></div>
                                        <div className='rounded-circle' style={{ padding: '0.5rem', backgroundColor: '#ef4444' }}></div>
                                    </div>}
                                </div>
                                <div className="flex-grow-1 position-relative" style={{ backgroundImage: 'url("https://miro.medium.com/v2/resize:fit:678/1*ZPvzUShTe448VPDukHiskw.png")' }}>
                                    <div className="flex-grow-1 position-relative h-100" style={{ backgroundImage: 'url("https://miro.medium.com/v2/resize:fit:678/1*ZPvzUShTe448VPDukHiskw.png")', backgroundSize: 'contain', backgroundPosition: 'top center', overflowY: "auto", position: "relative", ...bgsettings, backgroundImage: currPage === "button" ? "none" : bgsettings?.backgroundImage, backgroundColor: currPage === "button" ? "none" : bgsettings?.backgroundColor, display: "flex", flexDirection: "column" }}>
                                        {/* {outletData[0]?.web_url && <iframe src={outletData[0]?.web_url} className='w-100 h-100' style={{position: "absolute", inset: "0px", zIndex: "-1"}} frameborder="0"></iframe>} */}
                                        {/* <div style={{inset: "0px", zIndex: "0", backgroundColor: "rgba(0,0,0,0.25)", position: "sticky", width: "100%", height: "100%"}}></div> */}
                                        <div id='preview_section' onClick={() => {
                                            setCurrPosition({ ...currPosition, selectedType: "navMenuStyles" })
                                            setIndexes({ cur: 0, curElem: "left", subElem: "grandparent" })
                                        }} style={{ width: "100%", height: "100%", position: "relative", overflowY: "auto", display: "flex", justifyContent: popPosition?.includes("L") ? "start" : popPosition?.includes("C") ? "center" : "end", alignItems: popPosition?.includes("T") ? "start" : popPosition?.includes("M") ? "center" : "end", flexGrow: "1" }}>
                                            {currPage !== "button" ? (
                                                <div style={{ position: "relative", width: bgStyles?.width, maxWidth: bgStyles?.maxWidth, maxHeight: "100%", minHeight: bgStyles?.minHeight, marginTop: bgStyles?.marginTop, marginRight: bgStyles?.marginRight, marginBottom: bgStyles?.marginBottom, marginLeft: bgStyles?.marginLeft, borderRadius: bgStyles?.borderRadius }}>
                                                    <X size={crossStyle?.width} height={crossStyle?.height} color={crossStyle?.color} style={{ position: "absolute", inset: "0px 0px auto auto", zIndex: "350", backgroundColor: crossStyle?.backgroundColor, borderRadius: crossStyle?.borderRadius, padding: `3px`, marginBottom: crossStyle?.marginBottom, transform: `translateX(${crossStyle?.translateX}) translateY(${crossStyle?.translateY})` }} onClick={(e) => {
                                                        e.stopPropagation()
                                                        setCurrPosition({ ...currPosition, selectedType: "cross" })
                                                    }} />
                                                    <div id="dropZoneParent" onClick={(e) => {
                                                        e.stopPropagation()
                                                        setCurrPosition({ ...currPosition, selectedType: "main" })
                                                    }} onDragOver={(e) => {
                                                        handleDragOver(e)
                                                    }}
                                                        onDrop={(e) => {
                                                            const transferType = e.dataTransfer.getData("type")
                                                            if (transferType !== "") {
                                                                handleLayoutDrop(e)
                                                                setIndexes(transferType.includes("col") ? { cur: colWise.length, curElem: "parent", subElem: "grandparent" } : { cur: colWise.length, curElem: "left", subElem: 0 })
                                                                setCurrPosition({ ...currPosition, id: colWise.length, selectedType: transferType.includes("col") ? "block" : transferType })
                                                                setValues(elementStyles[transferType.includes("col") ? "block" : transferType])
                                                            }
                                                        }} className="pop-up" style={{ position: 'relative', zIndex: '300', overflow: "visible", ...bgStyles, backgroundColor: bgStyles?.backgroundColor, backgroundImage: bgStyles?.backgroundImage, width: "100%", maxWidth: "100%", marginTop: "0px", marginRight: "0px", marginBottom: "0px", marginLeft: "0px", position: "relative" }}>
                                                        <style>{`
                                                        .ql-editor {
                                                        padding: 0px !important;
                                                        text-align: center !important
                                                        }
                                                        #dropZoneParent::-webkit-scrollbar, .nav-sidebar::-webkit-scrollbar {
                                                            display: none;
                                                        }
                                                        #dropZoneParent p {
                                                            margin: 0px;
                                                        }
                                                    `}</style>
                                                        {showBrand && <div className="branding" style={{ position: "absolute", inset: "auto 0px 0px auto", zIndex: "9999999999999999999999999", ...brandStyles }}><span className="cursor-pointer" onClick={e => {
                                                            e.preventDefault()
                                                            e.stopPropagation()
                                                            setCurrPosition({ ...currPosition, selectedType: "brand" })
                                                        }}>Powered by <span onClick={e => {
                                                            e.stopPropagation()
                                                            navigate("/")
                                                        }} className="text-decoration-underline">XIRCLS</span></span></div>}
                                                        {/* render layout Here */}
                                                        {
                                                            colWise?.map((cur, key) => {
                                                                return <div style={{ ...cur?.style, display: "flex", justifyContent: "center", alignItems: "center", position: "relative" }} key={key}
                                                                    onClick={(e) => {
                                                                        e.stopPropagation()
                                                                        makActive(e, cur, "parent", "parent", key, "parent", "parent")
                                                                        setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                        setIndexes({ cur: key, curElem: "parent", subElem: "grandparent" })
                                                                        setValues(cur?.style)
                                                                        // setShowActive(!isEqual({ ...indexes }, { cur: key, curElem: "parent", subElem: "grandparent" }))
                                                                    }}
                                                                    onMouseEnter={(e) => {
                                                                        e.stopPropagation()
                                                                        setMouseEnterIndex({ cur: key, curElem: "parent", subElem: "grandparent" })
                                                                    }}
                                                                    onMouseLeave={(e) => {
                                                                        e.stopPropagation()
                                                                        setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                    }}
                                                                    id={`${currPage}-${key}-parent-grandparent`}
                                                                    className={`${isEqual({ cur: key, curElem: "parent", subElem: "grandparent" }, { ...indexes }) ? "active-elem" : ""}`}
                                                                >
                                                                    {isEqual({ cur: key, curElem: "parent", subElem: "grandparent" }, { ...indexes }) && <span className="d-flex" style={{ backgroundColor: "#727272", position: "absolute", top: "0px", left: "0px", transform: "translateY(-100%)", zIndex: "99999999999999999999999999999999999999" }}>
                                                                        <Trash color="#ffffff" size={30} className="cursor-pointer" style={{ padding: "0.5rem" }} onClick={(e) => {
                                                                            e.stopPropagation()
                                                                            if (colWise.length <= 1) {
                                                                                // setCurrPosition({ ...currPosition, selectedType: "main" })
                                                                                setIndexes({ cur: 0, curElem: "left", subElem: "grandparent" })
                                                                            } else {
                                                                                // setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                                setIndexes({ cur: key - 1, curElem: "left", subElem: "grandparent" })
                                                                            }
                                                                            const arr = [...colWise]
                                                                            arr.splice(key, 1)
                                                                            setcolWise([...arr])
                                                                            setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                        }} />
                                                                        <Copy color="#ffffff" size={30} className="cursor-pointer" style={{ padding: "0.5rem" }} onClick={(e) => {
                                                                            e.stopPropagation()
                                                                            setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                            setIndexes({ cur: key + 1, curElem: "left", subElem: "grandparent" })
                                                                            const arr = [...colWise]
                                                                            arr.splice(key, 0, cur)
                                                                            setcolWise([...arr])
                                                                            setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                        }} />
                                                                    </span>}
                                                                    {isEqual({ ...mouseEnterIndex }, { cur: key, curElem: "parent", subElem: "grandparent" }) && <div className="position-absolute" style={{ inset: "0px", outline: "2px solid #727272", pointerEvents: "none", zIndex: "5", backgroundColor: "rgba(0,0,0,0.5)" }}></div>}
                                                                    <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "center", alignItems: "stretch", position: "relative", width: "100%", zIndex: "1" }}
                                                                    >
                                                                        {
                                                                            cur?.elements?.map((curElem, i) => {
                                                                                return (
                                                                                    <div style={{ ...curElem?.style, position: "relative", width: isMobile ? "100%" : curElem?.style?.width }} onClick={(e) => {
                                                                                        e.stopPropagation()
                                                                                        // setActiveRow("none")
                                                                                        makActive(e, cur, curElem, curElem?.positionType, key, i, "parent")
                                                                                        setCurrPosition({ ...currPosition, selectedType: "column" })
                                                                                        setIndexes({ cur: key, curElem: curElem?.positionType, subElem: "parent" })
                                                                                        setValues(curElem?.style)
                                                                                    }}
                                                                                        onMouseEnter={(e) => {
                                                                                            e.stopPropagation()
                                                                                            setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: "parent" })
                                                                                        }}
                                                                                        onMouseLeave={(e) => {
                                                                                            e.stopPropagation()
                                                                                            setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                        }}
                                                                                        onDrop={e => {
                                                                                            e.stopPropagation()
                                                                                            handleColDrop(e, key, curElem?.positionType, curElem?.element?.length, i)
                                                                                            const transferType = e.dataTransfer.getData("type")
                                                                                            setCurrPosition({ ...currPosition, j: curElem?.element?.length, selectedType: transferType })
                                                                                        }}
                                                                                        id={`${currPage}-${key}-${curElem.positionType}-parent`}
                                                                                        className={`${isEqual({ cur: key, curElem: curElem.positionType, subElem: "parent" }, { ...indexes }) ? "active-elem" : ""}`}>

                                                                                        {isEqual({ ...mouseEnterIndex }, { cur: key, curElem: curElem?.positionType, subElem: "parent" }) && <div className="position-absolute" style={{ inset: "0px", outline: "2px solid #727272", pointerEvents: "none", zIndex: "6", backgroundColor: "rgba(0,0,0,0.5)" }}></div>}
                                                                                        {curElem?.element?.map((subElem, j) => {
                                                                                            switch (subElem?.type) {
                                                                                                case 'text':
                                                                                                    // return <span contentEditable="true" className="text-secondary p-1 rounded-2 " style={{ fontSize: '14.4px', border: '1px solid black' }} onClick={(e) => makActive(e, cur)} >Text Element</span>
                                                                                                    return (
                                                                                                        <div id={`${currPage}-${key}-${curElem?.positionType}-${j}`} draggable={!isEqual({ cur: key, curElem: curElem?.positionType, subElem: j }, { ...indexes })} onDragStart={(e) => {
                                                                                                            e.stopPropagation()
                                                                                                            e.dataTransfer.setData("type", "rearrange_text")
                                                                                                            setTransfered("rearrange_text")
                                                                                                            setIndexes({ cur: key, curElem: curElem.positionType, subElem: j })
                                                                                                            setDragStartIndex({ cur: key, curElem: curElem.positionType, subElem: j })
                                                                                                        }} style={{ ...subElem?.style, width: "100%", position: "relative", display: "flex", justifyContent: "center", alignItems: "center", fontFamily: subElem?.isInitialFont ? finalObj?.fontFamilies?.[subElem.textType] : subElem?.style?.fontFamily, zIndex: isEqual({ ...indexes }, { cur: key, curElem: curElem.positionType, subElem: j }) ? "2" : "1" }}
                                                                                                            onClick={e => {
                                                                                                                e.stopPropagation()
                                                                                                                makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                setCurrPosition({ ...currPosition, selectedType: "text" })
                                                                                                                setIndexes({ cur: key, curElem: curElem.positionType, subElem: j })
                                                                                                                setValues(subElem?.style)
                                                                                                            }}
                                                                                                            onDrop={e => {
                                                                                                                e.stopPropagation()
                                                                                                                const transferType = e.dataTransfer.getData("type")
                                                                                                                if (!transferType.includes("rearrange")) {
                                                                                                                    handleColDrop(e, key, curElem.positionType, j + 1, i)
                                                                                                                    setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                } else {
                                                                                                                    handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }
                                                                                                            }}
                                                                                                            onMouseEnter={(e) => {
                                                                                                                e.stopPropagation()
                                                                                                                setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                            }}
                                                                                                            onMouseLeave={(e) => {
                                                                                                                e.stopPropagation()
                                                                                                                setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                            }}
                                                                                                            onDragOver={e => {
                                                                                                                e.preventDefault()
                                                                                                                e.stopPropagation()
                                                                                                                setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                setMousePos({ ...mousePos, y: e.clientY, x: e.clientX })
                                                                                                            }}
                                                                                                            className={`${isEqual({ cur: key, curElem: curElem?.positionType, subElem: j }, { ...indexes }) ? "active-elem" : ""}`}>
                                                                                                            {isEqual({ cur: key, curElem: curElem.positionType, subElem: j }, { ...indexes }) && <span className="d-flex" style={{ backgroundColor: "#727272", position: "absolute", top: "0px", left: "0px", transform: "translateY(-100%)", zIndex: "99999999999999999999999999999999999999" }}>
                                                                                                                <Trash color="#ffffff" size={30} className="cursor-pointer" style={{ padding: "0.5rem" }} onClick={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    if (colWise.length <= 1) {
                                                                                                                        setCurrPosition({ ...currPosition, selectedType: "main" })
                                                                                                                        setIndexes({ cur: 0, curElem: "left", subElem: "grandparent" })
                                                                                                                    } else {
                                                                                                                        setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                                                                        setIndexes({ cur: key - 1, curElem: "left", subElem: "grandparent" })
                                                                                                                    }
                                                                                                                    const arr = [...colWise]
                                                                                                                    if (curElem?.element?.length <= 1 && cur?.elements?.length <= 1) {
                                                                                                                        arr.splice(key, 1)
                                                                                                                    } else if (curElem?.element?.length <= 1 && cur?.elements?.length >= 1) {
                                                                                                                        arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 1, { ...commonObj })
                                                                                                                    } else {
                                                                                                                        arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 1)
                                                                                                                    }
                                                                                                                    setcolWise([...arr])
                                                                                                                }} />
                                                                                                                <Copy color="#ffffff" size={30} className="cursor-pointer" style={{ padding: "0.5rem" }} onClick={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                                                                    setIndexes({ cur: key + 1, curElem: "left", subElem: "grandparent" })
                                                                                                                    const arr = [...colWise]
                                                                                                                    arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 0, subElem)
                                                                                                                    setcolWise([...arr])
                                                                                                                }} />
                                                                                                            </span>}
                                                                                                            {isEqual({ ...mouseEnterIndex }, { cur: key, curElem: curElem?.positionType, subElem: j }) && <div className="position-absolute" style={{ inset: "0px", outline: "2px solid #727272", pointerEvents: "none", zIndex: "7", backgroundColor: "rgba(0,0,0,0.5)" }}></div>}
                                                                                                            <div style={{ width: "100%" }} id={`textField-${key}-${curElem?.positionType}-${j}`} className="text-field" dangerouslySetInnerHTML={{ __html: subElem?.textValue }} />
                                                                                                            {/* <ReactQuill
                                                                                                                id={`textField-${key}-${curElem.positionType}-${j}`}
                                                                                                                style={{ width: '100%', color: "black", zIndex: "5" }}
                                                                                                                theme='bubble'
                                                                                                                // defaultValue={"Enter Text"}
                                                                                                                value={subElem.textValue}
                                                                                                                onChange={e => {
                                                                                                                    const dupText = [...colWise]
                                                                                                                    dupText[key].elements[i].element[j].textValue = e
                                                                                                                    setcolWise(dupText)
                                                                                                                }}
                                                                                                                modules={{
                                                                                                                    toolbar: [
                                                                                                                        [{ header: [1, 2, 3, 4, false] }],
                                                                                                                        ['bold', 'italic', 'underline'],
                                                                                                                        [{ size: [] }],
                                                                                                                        ['align', 'strike'],
                                                                                                                        [{ color: [] }],
                                                                                                                        [{ list: 'ordered' }, { list: 'bullet' }]
                                                                                                                    ]
                                                                                                                }}
                                                                                                                formats={[
                                                                                                                    'header',
                                                                                                                    'bold',
                                                                                                                    'italic',
                                                                                                                    'underline',
                                                                                                                    'size',
                                                                                                                    'align',
                                                                                                                    'strike',
                                                                                                                    'blockquote',
                                                                                                                    'color',
                                                                                                                    'list',
                                                                                                                    'bullet'
                                                                                                                ]} /> */}
                                                                                                            {/* <SunEditor
                                                                                                                setOptions={SunEditorConfig}
                                                                                                                id={`textField-${key}-${curElem.positionType}-${j}`}
                                                                                                                value={subElem.textValue || ''}
                                                                                                                onChange={(content) => {
                                                                                                                    const dupText = [...colWise]
                                                                                                                    dupText[key].elements[i].element[j].textValue = content
                                                                                                                    setcolWise(dupText)
                                                                                                                }}
                                                                                                            /> */}
                                                                                                        </div>
                                                                                                    )
                                                                                                case 'image':
                                                                                                    // const imageSelector = document.getElementById("hidden-image-input")
                                                                                                    if (subElem.src !== "") {
                                                                                                        return (
                                                                                                            <div id={`${currPage}-${key}-${curElem?.positionType}-${j}`} draggable style={{ width: "100%", ...subElem?.style, position: "relative", display: "flex", justifyContent: "center", alignItems: "center" }}
                                                                                                                onDragStart={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    e.dataTransfer.setData("type", "rearrange_image")
                                                                                                                    setTransfered("rearrange_image")
                                                                                                                    setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }}
                                                                                                                onMouseEnter={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }}
                                                                                                                onMouseLeave={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                                }}
                                                                                                                onClick={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                    setCurrPosition({ ...currPosition, selectedType: "image" })
                                                                                                                    setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setValues(subElem?.style)
                                                                                                                }}
                                                                                                                onDrop={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    const transferType = e.dataTransfer.getData("type")
                                                                                                                    if (!transferType.includes("rearrange")) {
                                                                                                                        handleColDrop(e, key, curElem?.positionType, j + 1, i)
                                                                                                                        setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                    } else {
                                                                                                                        handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    }
                                                                                                                }}
                                                                                                                onDragOver={e => {
                                                                                                                    e.preventDefault()
                                                                                                                    e.stopPropagation()
                                                                                                                    setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setMousePos({ ...mousePos, y: e.clientY })
                                                                                                                }}
                                                                                                                className={`${isEqual({ cur: key, curElem: curElem?.positionType, subElem: j }, { ...indexes }) ? "active-elem" : ""}`}>
                                                                                                                {isEqual({ cur: key, curElem: curElem.positionType, subElem: j }, { ...indexes }) && <span className="d-flex" style={{ backgroundColor: "#727272", position: "absolute", top: "0px", left: "0px", transform: "translateY(-100%)", zIndex: "99999999999999999999999999999999999999" }}>
                                                                                                                    <Trash color="#ffffff" size={30} className="cursor-pointer" style={{ padding: "0.5rem" }} onClick={(e) => {
                                                                                                                        e.stopPropagation()
                                                                                                                        if (colWise.length <= 1) {
                                                                                                                            setCurrPosition({ ...currPosition, selectedType: "main" })
                                                                                                                            setIndexes({ cur: 0, curElem: "left", subElem: "grandparent" })
                                                                                                                        } else {
                                                                                                                            setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                                                                            setIndexes({ cur: key - 1, curElem: "left", subElem: "grandparent" })
                                                                                                                        }
                                                                                                                        const arr = [...colWise]
                                                                                                                        if (curElem?.element?.length <= 1 && cur?.elements?.length <= 1) {
                                                                                                                            arr.splice(key, 1)
                                                                                                                        } else if (curElem?.element?.length <= 1 && cur?.elements?.length >= 1) {
                                                                                                                            arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 1, { ...commonObj })
                                                                                                                        } else {
                                                                                                                            arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 1)
                                                                                                                        }
                                                                                                                        setcolWise([...arr])
                                                                                                                    }} />
                                                                                                                    <Copy color="#ffffff" size={30} className="cursor-pointer" style={{ padding: "0.5rem" }} onClick={(e) => {
                                                                                                                        e.stopPropagation()
                                                                                                                        setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                                                                        setIndexes({ cur: key + 1, curElem: "left", subElem: "grandparent" })
                                                                                                                        const arr = [...colWise]
                                                                                                                        arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 0, subElem)
                                                                                                                        setcolWise([...arr])
                                                                                                                    }} />
                                                                                                                </span>}
                                                                                                                {isEqual({ ...mouseEnterIndex }, { cur: key, curElem: curElem?.positionType, subElem: j }) && <div className="position-absolute" style={{ inset: "0px", outline: "2px solid #727272", pointerEvents: "none", zIndex: "7", backgroundColor: "rgba(0,0,0,0.5)" }}></div>}
                                                                                                                <img
                                                                                                                    className="img-fluid"
                                                                                                                    src={subElem.src}
                                                                                                                    alt={`Selected Image ${i}`}
                                                                                                                    style={{ width: "100%" }}
                                                                                                                />
                                                                                                            </div>
                                                                                                        )
                                                                                                    } else {
                                                                                                        setCurrPosition({ ...currPosition, j })
                                                                                                        // imageSelector.click()
                                                                                                        triggerImage()
                                                                                                        const dupArray = [...colWise]
                                                                                                        dupArray[key].elements[i].element[j].src = "http://www.palmares.lemondeduchiffre.fr/images/joomlart/demo/default.jpg"
                                                                                                        setcolWise([...dupArray])
                                                                                                    }
                                                                                                case 'button':
                                                                                                    return (
                                                                                                        <div id={`${currPage}-${key}-${curElem?.positionType}-${j}`} draggable style={{ width: "100%", display: "flex", justifyContent: subElem?.style?.alignType, position: "relative", display: "flex", alignItems: "center" }}
                                                                                                            onDragStart={e => {
                                                                                                                e.stopPropagation()
                                                                                                                e.dataTransfer.setData("type", "rearrange_button")
                                                                                                                setTransfered("rearrange_button")
                                                                                                                setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                            }}
                                                                                                            onClick={e => {
                                                                                                                e.stopPropagation()
                                                                                                                makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                setCurrPosition({ ...currPosition, selectedType: "button" })
                                                                                                                setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                setValues(subElem?.style)
                                                                                                            }}
                                                                                                            onDrop={e => {
                                                                                                                e.stopPropagation()
                                                                                                                const transferType = e.dataTransfer.getData("type")
                                                                                                                if (!transferType.includes("rearrange")) {
                                                                                                                    handleColDrop(e, key, curElem?.positionType, j + 1, i)
                                                                                                                    setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                } else {
                                                                                                                    handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }
                                                                                                            }}
                                                                                                            onMouseEnter={(e) => {
                                                                                                                e.stopPropagation()
                                                                                                                setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                            }}
                                                                                                            onMouseLeave={(e) => {
                                                                                                                e.stopPropagation()
                                                                                                                setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                            }}
                                                                                                            onDragOver={e => {
                                                                                                                e.preventDefault()
                                                                                                                e.stopPropagation()
                                                                                                                setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                setMousePos({ ...mousePos, y: e.clientY })
                                                                                                            }}
                                                                                                            className={`${isEqual({ cur: key, curElem: curElem?.positionType, subElem: j }, { ...indexes }) ? "active-elem" : ""}`}>
                                                                                                            {isEqual({ cur: key, curElem: curElem.positionType, subElem: j }, { ...indexes }) && <span className="d-flex" style={{ backgroundColor: "#727272", position: "absolute", top: "0px", left: "0px", transform: "translateY(-100%)", zIndex: "99999999999999999999999999999999999999" }}>
                                                                                                                <Trash color="#ffffff" size={30} className="cursor-pointer" style={{ padding: "0.5rem" }} onClick={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    if (colWise.length <= 1) {
                                                                                                                        setCurrPosition({ ...currPosition, selectedType: "main" })
                                                                                                                        setIndexes({ cur: 0, curElem: "left", subElem: "grandparent" })
                                                                                                                    } else {
                                                                                                                        setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                                                                        setIndexes({ cur: key - 1, curElem: "left", subElem: "grandparent" })
                                                                                                                    }
                                                                                                                    const arr = [...colWise]
                                                                                                                    if (curElem?.element?.length <= 1 && cur?.elements?.length <= 1) {
                                                                                                                        arr.splice(key, 1)
                                                                                                                    } else if (curElem?.element?.length <= 1 && cur?.elements?.length >= 1) {
                                                                                                                        arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 1, { ...commonObj })
                                                                                                                    } else {
                                                                                                                        arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 1)
                                                                                                                    }
                                                                                                                    setcolWise([...arr])
                                                                                                                }} />
                                                                                                                <Copy color="#ffffff" size={30} className="cursor-pointer" style={{ padding: "0.5rem" }} onClick={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                                                                    setIndexes({ cur: key + 1, curElem: "left", subElem: "grandparent" })
                                                                                                                    const arr = [...colWise]
                                                                                                                    arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 0, subElem)
                                                                                                                    setcolWise([...arr])
                                                                                                                }} />
                                                                                                            </span>}
                                                                                                            {isEqual({ ...mouseEnterIndex }, { cur: key, curElem: curElem?.positionType, subElem: j }) && <div className="position-absolute" style={{ inset: "0px", outline: "2px solid #727272", pointerEvents: "none", zIndex: "7", backgroundColor: "rgba(0,0,0,0.5)" }}></div>}
                                                                                                            <div style={{ ...subElem?.style, height: Number(subElem?.style?.height) === 0 ? "auto" : `${subElem?.style?.height}px`, display: "inline-flex", justifyContent: "center", alignItems: "center", fontFamily: subElem?.isInitialFont ? finalObj?.fontFamilies?.[subElem.textType] : subElem?.style?.fontFamily }} >
                                                                                                                <span onDragStart={e => e.stopPropagation()} id={`textField-${key}-${curElem?.positionType}-${j}`}>
                                                                                                                    {/* <ReactQuill
                                                                                                                id={`textField-${key}-${curElem.positionType}-${j}`}
                                                                                                                style={{ width: '100%', color: "black", zIndex: "5" }}
                                                                                                                theme='bubble'
                                                                                                                // defaultValue={"Enter Text"}
                                                                                                                value={subElem.textValue}
                                                                                                                onChange={e => {
                                                                                                                    const dupText = [...colWise]
                                                                                                                    dupText[key].elements[i].element[j].textValue = e
                                                                                                                    setcolWise(dupText)
                                                                                                                }}
                                                                                                                modules={{
                                                                                                                    toolbar: [
                                                                                                                        [{ header: [1, 2, 3, 4, false] }],
                                                                                                                        ['bold', 'italic', 'underline'],
                                                                                                                        [{ size: [] }],
                                                                                                                        ['align', 'strike'],
                                                                                                                        [{ color: [] }],
                                                                                                                        [{ list: 'ordered' }, { list: 'bullet' }]
                                                                                                                    ]
                                                                                                                }}
                                                                                                                formats={[
                                                                                                                    'header',
                                                                                                                    'bold',
                                                                                                                    'italic',
                                                                                                                    'underline',
                                                                                                                    'size',
                                                                                                                    'align',
                                                                                                                    'strike',
                                                                                                                    'blockquote',
                                                                                                                    'color',
                                                                                                                    'list',
                                                                                                                    'bullet'
                                                                                                                ]} /> */}
                                                                                                                    {/* <SunEditor
                                                                                                                    setOptions={SunEditorConfig}
                                                                                                                    
                                                                                                                    value={subElem.textValue || ''}
                                                                                                                    onChange={(content) => {
                                                                                                                        const dupText = [...colWise]
                                                                                                                        dupText[key].elements[i].element[j].textValue = content
                                                                                                                        setcolWise(dupText)
                                                                                                                    }}
                                                                                                                /> */}
                                                                                                                    <div className="text-field" dangerouslySetInnerHTML={{ __html: subElem?.textValue }} />
                                                                                                                </span>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    )
                                                                                                case 'input':
                                                                                                    return (
                                                                                                        <div id={`${currPage}-${key}-${curElem?.positionType}-${j}`} draggable style={{ width: "100%", display: "flex", justifyContent: subElem?.style?.alignType, position: "relative", alignItems: "center" }}
                                                                                                            onDragStart={e => {
                                                                                                                e.stopPropagation()
                                                                                                                e.dataTransfer.setData("type", "rearrange_input")
                                                                                                                setTransfered("rearrange_input")
                                                                                                                setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                            }}
                                                                                                            onClick={e => {
                                                                                                                e.stopPropagation()
                                                                                                                makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                setCurrPosition({ ...currPosition, selectedType: "input" })
                                                                                                                setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                setValues(subElem.style)
                                                                                                            }}
                                                                                                            onDrop={e => {
                                                                                                                e.stopPropagation()
                                                                                                                const transferType = e.dataTransfer.getData("type")
                                                                                                                if (!transferType.includes("rearrange")) {
                                                                                                                    handleColDrop(e, key, curElem?.positionType, j + 1, i)
                                                                                                                    setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                } else {
                                                                                                                    handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }
                                                                                                            }}
                                                                                                            onMouseEnter={(e) => {
                                                                                                                e.stopPropagation()
                                                                                                                setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                            }}
                                                                                                            onMouseLeave={(e) => {
                                                                                                                e.stopPropagation()
                                                                                                                setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                            }}
                                                                                                            onDragOver={e => {
                                                                                                                e.preventDefault()
                                                                                                                e.stopPropagation()
                                                                                                                setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                setMousePos({ ...mousePos, y: e.clientY })
                                                                                                            }}
                                                                                                            className={`${isEqual({ cur: key, curElem: curElem?.positionType, subElem: j }, { ...indexes }) ? "active-elem" : ""}`}>
                                                                                                            {isEqual({ cur: key, curElem: curElem.positionType, subElem: j }, { ...indexes }) && <span className="d-flex" style={{ backgroundColor: "#727272", position: "absolute", top: "0px", left: "0px", transform: "translateY(-100%)", zIndex: "99999999999999999999999999999999999999" }}>
                                                                                                                <Trash color="#ffffff" size={30} className="cursor-pointer" style={{ padding: "0.5rem" }} onClick={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    if (colWise.length <= 1) {
                                                                                                                        setCurrPosition({ ...currPosition, selectedType: "main" })
                                                                                                                        setIndexes({ cur: 0, curElem: "left", subElem: "grandparent" })
                                                                                                                    } else {
                                                                                                                        setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                                                                        setIndexes({ cur: key - 1, curElem: "left", subElem: "grandparent" })
                                                                                                                    }
                                                                                                                    const arr = [...colWise]
                                                                                                                    if (curElem?.element?.length <= 1 && cur?.elements?.length <= 1) {
                                                                                                                        arr.splice(key, 1)
                                                                                                                    } else if (curElem?.element?.length <= 1 && cur?.elements?.length >= 1) {
                                                                                                                        arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 1, { ...commonObj })
                                                                                                                    } else {
                                                                                                                        arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 1)
                                                                                                                    }
                                                                                                                    setcolWise([...arr])
                                                                                                                }} />
                                                                                                                <Copy color="#ffffff" size={30} className="cursor-pointer" style={{ padding: "0.5rem" }} onClick={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                                                                    setIndexes({ cur: key + 1, curElem: "left", subElem: "grandparent" })
                                                                                                                    const arr = [...colWise]
                                                                                                                    arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 0, subElem)
                                                                                                                    setcolWise([...arr])
                                                                                                                }} />
                                                                                                            </span>}
                                                                                                            {isEqual({ ...mouseEnterIndex }, { cur: key, curElem: curElem?.positionType, subElem: j }) && <div className="position-absolute" style={{ inset: "0px", outline: "2px solid #727272", pointerEvents: "none", zIndex: "7", backgroundColor: "rgba(0,0,0,0.5)" }}></div>}
                                                                                                            <div style={{ width: subElem?.style?.width }}>
                                                                                                                {subElem?.hasLabel && (<label style={{ color: subElem?.style?.color, fontFamily: subElem?.style?.fontFamily }}>{subElem?.labelText}</label>)}
                                                                                                                <input placeholder={subElem?.placeholder} type="text" style={{ ...subElem?.style, width: "100%" }} readOnly />
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    )
                                                                                                case 'offer':
                                                                                                    return (
                                                                                                        <div
                                                                                                            onDragStart={e => {
                                                                                                                e.stopPropagation()
                                                                                                                e.dataTransfer.setData("type", "rearrange_offer")
                                                                                                                setTransfered("rearrange_offer")
                                                                                                                setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                            }}
                                                                                                            onMouseEnter={(e) => {
                                                                                                                e.stopPropagation()
                                                                                                                setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                            }}
                                                                                                            onMouseLeave={(e) => {
                                                                                                                e.stopPropagation()
                                                                                                                setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                            }}
                                                                                                            onClick={e => {
                                                                                                                e.stopPropagation()
                                                                                                                makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                setCurrPosition({ ...currPosition, selectedType: "offer" })
                                                                                                                setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                setValues(subElem?.style)
                                                                                                            }}
                                                                                                            onDrop={e => {
                                                                                                                e.stopPropagation()
                                                                                                                const transferType = e.dataTransfer.getData("type")
                                                                                                                if (!transferType.includes("rearrange")) {
                                                                                                                    handleColDrop(e, key, curElem?.positionType, j + 1, i)
                                                                                                                    setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                } else {
                                                                                                                    handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }
                                                                                                            }}
                                                                                                            onDragOver={e => {
                                                                                                                e.preventDefault()
                                                                                                                e.stopPropagation()
                                                                                                                setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                setMousePos({ ...mousePos, y: e.clientY })
                                                                                                            }} style={{ ...subElem?.style, position: "relative", fontFamily: subElem?.isInitialFont ? finalObj?.fontFamilies?.[subElem.textType] : subElem?.style?.fontFamily }}
                                                                                                            id={`${currPage}-${key}-${curElem.positionType}-${j}`}
                                                                                                            className={`${isEqual({ cur: key, curElem: curElem.positionType, subElem: j }, { ...indexes }) ? "active-elem" : ""}`}>
                                                                                                            {isEqual({ cur: key, curElem: curElem.positionType, subElem: j }, { ...indexes }) && <span className="d-flex" style={{ backgroundColor: "#727272", position: "absolute", top: "0px", left: "0px", transform: "translateY(-100%)", zIndex: "99999999999999999999999999999999999999" }}>
                                                                                                                <Trash color="#ffffff" size={30} className="cursor-pointer" style={{ padding: "0.5rem" }} onClick={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    if (colWise.length <= 1) {
                                                                                                                        setCurrPosition({ ...currPosition, selectedType: "main" })
                                                                                                                        setIndexes({ cur: 0, curElem: "left", subElem: "grandparent" })
                                                                                                                    } else {
                                                                                                                        setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                                                                        setIndexes({ cur: key - 1, curElem: "left", subElem: "grandparent" })
                                                                                                                    }
                                                                                                                    const arr = [...colWise]
                                                                                                                    if (curElem?.element?.length <= 1 && cur?.elements?.length <= 1) {
                                                                                                                        arr.splice(key, 1)
                                                                                                                    } else if (curElem?.element?.length <= 1 && cur?.elements?.length >= 1) {
                                                                                                                        arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 1, { ...commonObj })
                                                                                                                    } else {
                                                                                                                        arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 1)
                                                                                                                    }
                                                                                                                    setcolWise([...arr])
                                                                                                                }} />
                                                                                                                <Copy color="#ffffff" size={30} className="cursor-pointer" style={{ padding: "0.5rem" }} onClick={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                                                                    setIndexes({ cur: key + 1, curElem: "left", subElem: "grandparent" })
                                                                                                                    const arr = [...colWise]
                                                                                                                    arr[key].elements[arr[key].elements.findIndex($ => $?.positionType === curElem.positionType)].element.splice(j, 0, subElem)
                                                                                                                    setcolWise([...arr])
                                                                                                                }} />
                                                                                                            </span>}
                                                                                                            {isEqual({ ...mouseEnterIndex }, { cur: key, curElem: curElem?.positionType, subElem: j }) && <div className="position-absolute" style={{ inset: "0px", outline: "2px solid #727272", pointerEvents: "none", zIndex: "7", backgroundColor: "rgba(0,0,0,0.5)" }}></div>}
                                                                                                            {gotOffers ? finalObj?.selectedOffers?.map((ele, key) => {
                                                                                                                return (
                                                                                                                    <>
                                                                                                                        {/* <div key={key} style={{ margin: "10px 0px 20px" }}>
                                                                                                                        <div style={{
                                                                                                                            flexDirection: 'column',
                                                                                                                            justifyContent: 'center',
                                                                                                                            alignItems: 'center',
                                                                                                                            position: "relative"
                                                                                                                        }}>
                                                                                                                            <div style={{
                                                                                                                                width: '100%',
                                                                                                                                minHeight: '100%',
                                                                                                                                justifyContent: 'center',
                                                                                                                                // boxShadow: 'rgba(0, 0, 0, 0.125) 10px 2px 5px',
                                                                                                                                filter: 'drop-shadow(rgba(0, 0, 0, 0.2) 0px 0px 10px',
                                                                                                                                borderRadius: '10px',
                                                                                                                                display: 'flex',
                                                                                                                                position: "relative",
                                                                                                                                backgroundColor: finalObj?.offerProperties?.colors?.primaryBg
                                                                                                                            }}>
                                                                                                                                <div className='flex-grow-1 d-flex flex-column justify-content-between' style={{ padding: '15px' }}>
                                                                                                                                    <div style={{ text: 'wrap' }}>
                                                                                                                                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'start', justifyContent: 'start', textTransform: 'uppercase' }}>
                                                                                                                                            <h2 style={{ fontWeight: 'bolder', fontSize: '0.9rem', color: finalObj?.offerProperties?.colors?.code }}>
                                                                                                                                                {ele?.Code}
                                                                                                                                            </h2>
                                                                                                                                            {finalObj?.offerProperties?.showSections?.includes("description") && <span style={{ textTransform: 'lowercase', fontSize: '0.75rem', color: finalObj?.offerProperties?.colors?.description }}>
                                                                                                                                                {ele?.Summary}
                                                                                                                                            </span>}
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                    {finalObj?.offerProperties?.showSections?.includes("validity") && <div>
                                                                                                                                        <div style={{ paddingTop: '0.5rem' }}>
                                                                                                                                            <span style={{ color: finalObj?.offerProperties?.colors?.validity, textTransform: 'uppercase', fontWeight: '500', fontSize: '0.65rem' }}>
                                                                                                                                                valid until: {ele?.ValidityPeriod?.end ? moment(ele?.ValidityPeriod?.end).format('L') : "Never ending"}
                                                                                                                                            </span>
                                                                                                                                        </div>
                                                                                                                                    </div>}
                                                                                                                                </div>
                                                                                                                                <div style={{ display: 'flex', flexDirection: 'column', gap: "0.5rem", padding: "0px 15px 15px" }}>
                                                                                                                                    <div style={{
                                                                                                                                        position: 'relative',
                                                                                                                                        display: 'flex',
                                                                                                                                        flexDirection: 'column',
                                                                                                                                        justifyContent: 'space-between',
                                                                                                                                        alignItems: 'center',
                                                                                                                                        backgroundColor: finalObj?.offerProperties?.colors?.secondaryBg,
                                                                                                                                        // filter: `hue-rotate(${i * (i + 20)}deg)`,
                                                                                                                                        padding: "1rem 0.25rem",
                                                                                                                                        borderRadius: "0px 0px 5px 5px"
                                                                                                                                    }}>
                                                                                                                                        <h1 style={{
                                                                                                                                            fontSize: '1.829rem',
                                                                                                                                            fontWeight: '750',
                                                                                                                                            fontFamily: 'Montserrat',
                                                                                                                                            color: finalObj?.offerProperties?.colors?.value
                                                                                                                                        }}>
                                                                                                                                            {
                                                                                                                                                ele?.Type === "PERCENTAGE" ? (
                                                                                                                                                    `${Number(ele?.Value).toFixed(0)}%`
                                                                                                                                                ) : `₹${Number(ele?.Value).toFixed(0)}`
                                                                                                                                            }
                                                                                                                                        </h1>
                                                                                                                                    </div>
                                                                                                                                    <div style={{
                                                                                                                                        display: 'flex',
                                                                                                                                        flexDirection: 'column',
                                                                                                                                        justifyContent: 'flex-end',
                                                                                                                                        alignItems: 'center'
                                                                                                                                    }}>
                                                                                                                                        <button type="button" style={{
                                                                                                                                            color: finalObj?.offerProperties?.colors?.button,
                                                                                                                                            // filter: `hue-rotate(${i * (i + 20)}deg)`,
                                                                                                                                            fontSize: '0.65rem',
                                                                                                                                            fontWeight: '700',
                                                                                                                                            cursor: 'pointer',
                                                                                                                                            border: `0.75px solid ${finalObj?.offerProperties?.colors?.button}`,
                                                                                                                                            borderRadius: '15px',
                                                                                                                                            padding: '0.195rem',
                                                                                                                                            backgroundColor: 'transparent',
                                                                                                                                            textTransform: 'uppercase',
                                                                                                                                            cursor: 'pointer'
                                                                                                                                        }}>
                                                                                                                                            <span >
                                                                                                                                                Redeem
                                                                                                                                            </span>
                                                                                                                                        </button>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                            {finalObj?.offerProperties?.showSections?.includes("usage") && <div style={{
                                                                                                                                width: 'auto',
                                                                                                                                // margin: '-0.5rem auto',
                                                                                                                                position: 'absolute',
                                                                                                                                bottom: "0px",
                                                                                                                                backgroundColor: 'white',
                                                                                                                                textAlign: 'center',
                                                                                                                                padding: '0.25rem 0.5rem',
                                                                                                                                borderRadius: '10px',
                                                                                                                                boxShadow: '0 4px 24px 0 rgba(34, 41, 47, 0.15)',
                                                                                                                                transform: "translate(-50%, 50%)",
                                                                                                                                left: "50%"
                                                                                                                            }}>
                                                                                                                                <span style={{ textTransform: 'lowercase', fontSize: '0.75rem', color: finalObj.offerProperties.colors.usage, backgroundColor: finalObj.offerProperties.colors.primaryBg, fontWeight: '300', whiteSpace: "nowrap" }}>
                                                                                                                                    Used xyz times
                                                                                                                                </span>
                                                                                                                            </div>}
                                                                                                                        </div>
                                                                                                                    </div> */}
                                                                                                                        <ReturnOfferHtml details={ele} key={key} theme={offerTheme} colors={finalObj?.offerProperties?.colors} />
                                                                                                                    </>
                                                                                                                )
                                                                                                            }) : (
                                                                                                                <div className="d-flex justify-content-center align-items-center" style={{ inset: "0px", backgroundColor: "rgba(255,255,255,0.5)" }}>
                                                                                                                    <Spinner />
                                                                                                                </div>
                                                                                                            )}
                                                                                                        </div>
                                                                                                    )
                                                                                                case 'icon':
                                                                                                    return (
                                                                                                        <div>icon</div>
                                                                                                    )
                                                                                                default:
                                                                                                    return <div key={i} className='' style={{ display: "flex", justifyContent: "center", alignItems: "center", width: "100%", padding: "1rem" }}
                                                                                                        // onClick={(e) => makActive(e, cur)}
                                                                                                        onDragOver={(e) => {
                                                                                                            e.preventDefault()
                                                                                                            e.stopPropagation()
                                                                                                            makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                            handleDragOver(e)
                                                                                                            setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                            setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                        }}
                                                                                                        onClick={(e) => {
                                                                                                            makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                        }}
                                                                                                        onDrop={(e) => {
                                                                                                            e.stopPropagation()
                                                                                                            makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                            handleElementDrop(e, curElem?.positionType, key, i, curElem, j)
                                                                                                        }}>
                                                                                                        <Download size={10} style={{ color: 'grey' }} />
                                                                                                        <p style={{ margin: '0px', fontSize: '10px', color: 'grey' }}>Drop an element here</p>
                                                                                                    </div>
                                                                                            }
                                                                                        })}
                                                                                    </div>
                                                                                )
                                                                            })
                                                                        }
                                                                    </div>
                                                                </div>
                                                            })
                                                        }
                                                    </div>
                                                </div>
                                            ) : (
                                                <div style={{ marginTop: btnStyles?.marginTop, marginRight: btnStyles?.marginRight, marginBottom: btnStyles?.marginBottom, marginLeft: btnStyles?.marginLeft, display: "flex", alignItems: "center" }}>
                                                    <div style={{ flexGrow: "1" }}>
                                                        <div id="dropZoneParent" onClick={() => {
                                                            setCurrPosition({ ...currPosition, selectedType: "main" })
                                                        }} onDragOver={(e) => {
                                                            handleDragOver(e)
                                                        }}
                                                            onDrop={(e) => {
                                                                const transferType = e.dataTransfer.getData("type")
                                                                if (transferType !== "") {
                                                                    handleLayoutDrop(e)
                                                                    setIndexes(transferType?.includes("col") ? { cur: colWise.length, curElem: "parent", subElem: "grandparent" } : { cur: colWise?.length, curElem: "left", subElem: 0 })
                                                                    setCurrPosition({ ...currPosition, id: colWise?.length, selectedType: transferType?.includes("col") ? "block" : transferType })
                                                                    setValues(elementStyles?.[transferType.includes("col") ? "block" : transferType])
                                                                }
                                                            }} className="pop-up" style={{ position: 'relative', zIndex: '300', overflow: "visible", backgroundColor: "white", ...btnStyles, marginTop: "0px", marginRight: "0px", marginBottom: "0px", marginLeft: "0px", backgroundImage: btnStyles?.backgroundImage, width: btnStyles?.width, maxWidth: btnStyles?.maxWidth }}>
                                                            <style>
                                                                {`
                                                        .ql-editor {
                                                        padding: 0px !important;
                                                        text-align: center !important
                                                        }
                                                        #dropZoneParent::-webkit-scrollbar, .nav-sidebar::-webkit-scrollbar {
                                                            display: none;
                                                        }
                                                        #dropZoneParent p {
                                                            margin: 0px;
                                                        }
                                                    `}
                                                            </style>
                                                            {/* render layout Here */}
                                                            {
                                                                colWise?.map((cur, key) => {
                                                                    return <div style={{ ...cur?.style, backgroundImage: cur?.style?.backgroundImage, display: "flex", justifyContent: "center", alignItems: "center", position: "relative" }} key={key}
                                                                        onClick={(e) => {
                                                                            e.stopPropagation()
                                                                            makActive(e, cur, "parent", "parent", key, "parent", "parent")
                                                                            setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                            setIndexes({ cur: key, curElem: "parent", subElem: "grandparent" })
                                                                            setValues(cur?.style)
                                                                        }}
                                                                        onMouseEnter={() => {
                                                                            setMouseEnterIndex({ cur: key, curElem: "parent", subElem: "grandparent" })
                                                                        }}
                                                                        onMouseLeave={() => {
                                                                            setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                        }}
                                                                    >
                                                                        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", position: "relative", width: "100%", zIndex: "1" }}
                                                                        >
                                                                            {
                                                                                cur?.elements?.map((curElem, i) => {
                                                                                    return (
                                                                                        <div style={{ ...curElem?.style, backgroundImage: curElem?.style?.backgroundImage }} onClick={(e) => {
                                                                                            e.stopPropagation()
                                                                                            // setActiveRow("none")
                                                                                            makActive(e, cur, curElem, curElem?.positionType, key, i, "parent")
                                                                                            setCurrPosition({ ...currPosition, selectedType: "column" })
                                                                                            setIndexes({ cur: key, curElem: curElem?.positionType, subElem: "parent" })
                                                                                            setValues(curElem.style)
                                                                                        }}
                                                                                            onDrop={e => {
                                                                                                e.stopPropagation()
                                                                                                handleColDrop(e, key, curElem?.positionType, curElem?.element?.length)
                                                                                                const transferType = e.dataTransfer.getData("type")
                                                                                                setCurrPosition({ ...currPosition, j: curElem?.element?.length, selectedType: transferType })
                                                                                            }}>
                                                                                            {curElem?.element?.map((subElem, j) => {
                                                                                                switch (subElem?.type) {
                                                                                                    case 'text':
                                                                                                        // return <span contentEditable="true" className="text-secondary p-1 rounded-2 " style={{ fontSize: '14.4px', border: '1px solid black' }} onClick={(e) => makActive(e, cur)} >Text Element</span>
                                                                                                        return (
                                                                                                            <div id={`button-${key}-${curElem?.positionType}-${j}`} draggable={!isEqual({ cur: key, curElem: curElem?.positionType, subElem: j }, { ...indexes })} onDragStart={(e) => {
                                                                                                                e.stopPropagation()
                                                                                                                e.dataTransfer.setData("type", "rearrange_text")
                                                                                                                setTransfered("rearrange_text")
                                                                                                                setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                            }} style={{ ...subElem.style, backgroundImage: subElem?.style?.backgroundImage, width: "100%", position: "relative", display: "flex", justifyContent: "center", alignItems: "center" }}
                                                                                                                onClick={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                    setCurrPosition({ ...currPosition, selectedType: "text" })
                                                                                                                    setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setValues(subElem.style)
                                                                                                                }}
                                                                                                                onDrop={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    const transferType = e.dataTransfer.getData("type")
                                                                                                                    if (!transferType.includes("rearrange")) {
                                                                                                                        handleColDrop(e, key, curElem?.positionType, j + 1)
                                                                                                                        setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                    }
                                                                                                                }}
                                                                                                                onMouseEnter={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }}
                                                                                                                onMouseLeave={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                                }}
                                                                                                                onDragOver={e => {
                                                                                                                    e.preventDefault()
                                                                                                                    e.stopPropagation()
                                                                                                                    if (transfered.includes("rearrange")) {
                                                                                                                        handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    }
                                                                                                                    setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setMousePos({ ...mousePos, y: e.clientY, x: e.clientX })
                                                                                                                }}>
                                                                                                                <div style={{ width: "100%" }} id={`textField-${key}-${curElem?.positionType}-${j}`} dangerouslySetInnerHTML={{ __html: subElem?.textValue }} />
                                                                                                                {/* <ReactQuill
                                                                                                                id={`textField-${key}-${curElem.positionType}-${j}`}
                                                                                                                style={{ width: '100%', color: "black", zIndex: "5" }}
                                                                                                                theme='bubble'
                                                                                                                // defaultValue={"Enter Text"}
                                                                                                                value={subElem.textValue}
                                                                                                                onChange={e => {
                                                                                                                    const dupText = [...colWise]
                                                                                                                    dupText[key].elements[i].element[j].textValue = e
                                                                                                                    setcolWise(dupText)
                                                                                                                }}
                                                                                                                modules={{
                                                                                                                    toolbar: [
                                                                                                                        [{ header: [1, 2, 3, 4, false] }],
                                                                                                                        ['bold', 'italic', 'underline'],
                                                                                                                        [{ size: [] }],
                                                                                                                        ['align', 'strike'],
                                                                                                                        [{ color: [] }],
                                                                                                                        [{ list: 'ordered' }, { list: 'bullet' }]
                                                                                                                    ]
                                                                                                                }}
                                                                                                                formats={[
                                                                                                                    'header',
                                                                                                                    'bold',
                                                                                                                    'italic',
                                                                                                                    'underline',
                                                                                                                    'size',
                                                                                                                    'align',
                                                                                                                    'strike',
                                                                                                                    'blockquote',s
                                                                                                                    'color',
                                                                                                                    'list',
                                                                                                                    'bullet'
                                                                                                                ]} /> */}
                                                                                                                {/* <SunEditor
                                                                                                                setOptions={SunEditorConfig}
                                                                                                                id={`textField-${key}-${curElem.positionType}-${j}`}
                                                                                                                value={subElem.textValue || ''}
                                                                                                                onChange={(content) => {
                                                                                                                    const dupText = [...colWise]
                                                                                                                    dupText[key].elements[i].element[j].textValue = content
                                                                                                                    setcolWise(dupText)
                                                                                                                }}
                                                                                                            /> */}
                                                                                                                {(`${currPage}-${key}-${curElem.positionType}-${j}` === `${currPage}-${indexes.cur}-${indexes.curElem}-${indexes.subElem}`) && <div style={{ position: "absolute", width: "calc(100% + 5px)", height: "calc(100% + 7.5px)", outline: "2px solid #727272", pointerEvents: "none" }}></div>}
                                                                                                                {(`${currPage}-${key}-${curElem.positionType}-${j}` === `${currPage}-${mouseEnterIndex.cur}-${mouseEnterIndex.curElem}-${mouseEnterIndex.subElem}`) && <div style={{ position: "absolute", width: "100%", height: "100%", outline: "2px solid #727272", backgroundColor: "rgba(0,0,0,0.5)", pointerEvents: "none", zIndex: "999999999999999999999999999999999999999999999", inset: "0px" }}>
                                                                                                                    <div style={{ position: "relative", width: "100%", height: "100%" }}>
                                                                                                                    </div>
                                                                                                                </div>}
                                                                                                            </div>
                                                                                                        )
                                                                                                    case 'image':
                                                                                                        // const imageSelector = document.getElementById("hidden-image-input")
                                                                                                        if (subElem.src !== "") {
                                                                                                            return (
                                                                                                                <div id={`button-${key}-${curElem?.positionType}-${j}`} draggable style={{ width: "100%", ...subElem?.style, backgroundImage: subElem?.style?.backgroundImage, overflow: "hidden", position: "relative", display: "flex", justifyContent: "center", alignItems: "center" }}
                                                                                                                    onDragStart={e => {
                                                                                                                        e.stopPropagation()
                                                                                                                        e.dataTransfer.setData("type", "rearrange_image")
                                                                                                                        setTransfered("rearrange_image")
                                                                                                                        setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                        setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    }}
                                                                                                                    onMouseEnter={(e) => {
                                                                                                                        e.stopPropagation()
                                                                                                                        setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    }}
                                                                                                                    onMouseLeave={(e) => {
                                                                                                                        e.stopPropagation()
                                                                                                                        setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                                    }}
                                                                                                                    onClick={e => {
                                                                                                                        e.stopPropagation()
                                                                                                                        makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                        setCurrPosition({ ...currPosition, selectedType: "image" })
                                                                                                                        setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                        setValues(subElem?.style)
                                                                                                                    }}
                                                                                                                    onDrop={e => {
                                                                                                                        e.stopPropagation()
                                                                                                                        const transferType = e.dataTransfer.getData("type")
                                                                                                                        if (!transferType.includes("rearrange")) {
                                                                                                                            handleColDrop(e, key, curElem?.positionType, j + 1)
                                                                                                                            setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                        }
                                                                                                                    }}
                                                                                                                    onDragOver={e => {
                                                                                                                        e.preventDefault()
                                                                                                                        e.stopPropagation()
                                                                                                                        if (transfered.includes("rearrange")) {
                                                                                                                            handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                        }
                                                                                                                        setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                        setMousePos({ ...mousePos, y: e.clientY })
                                                                                                                    }}
                                                                                                                >
                                                                                                                    <img
                                                                                                                        className="img-fluid"
                                                                                                                        src={subElem.src}
                                                                                                                        alt={`Selected Image ${i}`}
                                                                                                                        style={{ width: "100%" }}
                                                                                                                    />
                                                                                                                    {(`${currPage}-${key}-${curElem?.positionType}-${j}` === `${currPage}-${indexes?.cur}-${indexes?.curElem}-${indexes?.subElem}`) && <div style={{ position: "absolute", width: "calc(100% + 5px)", height: "calc(100% + 7.5px)", outline: "2px solid #727272", pointerEvents: "none" }}></div>}
                                                                                                                    {(`${currPage}-${key}-${curElem?.positionType}-${j}` === `${currPage}-${mouseEnterIndex?.cur}-${mouseEnterIndex?.curElem}-${mouseEnterIndex?.subElem}`) && <div style={{ position: "absolute", width: "100%", height: "100%", outline: "2px solid #727272", backgroundColor: "rgba(0,0,0,0.5)", pointerEvents: "none", zIndex: "999999999999999999999999999999999999999999999", inset: "0px" }}>
                                                                                                                        <div style={{ position: "relative", width: "100%", height: "100%" }}>
                                                                                                                        </div>
                                                                                                                    </div>}
                                                                                                                </div>
                                                                                                            )
                                                                                                        } else {
                                                                                                            setCurrPosition({ ...currPosition, j })
                                                                                                            // imageSelector.click()
                                                                                                            triggerImage()
                                                                                                            const dupArray = [...colWise]
                                                                                                            dupArray[key].elements[i].element[j].type = ""
                                                                                                            setcolWise([...dupArray])
                                                                                                        }
                                                                                                    case 'button':
                                                                                                        return (
                                                                                                            <div id={`button-${key}-${curElem?.positionType}-${j}`} draggable style={{ width: "100%", display: "flex", justifyContent: subElem?.style?.alignType, position: "relative", display: "flex", alignItems: "center" }}
                                                                                                                onDragStart={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    e.dataTransfer.setData("type", "rearrange_button")
                                                                                                                    setTransfered("rearrange_button")
                                                                                                                    setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }}
                                                                                                                onClick={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                    setCurrPosition({ ...currPosition, selectedType: "button" })
                                                                                                                    setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setValues(subElem?.style)
                                                                                                                }}
                                                                                                                onDrop={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    const transferType = e.dataTransfer.getData("type")
                                                                                                                    if (!transferType.includes("rearrange")) {
                                                                                                                        handleColDrop(e, key, curElem?.positionType, j + 1)
                                                                                                                        setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                    }
                                                                                                                }}
                                                                                                                onMouseEnter={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }}
                                                                                                                onMouseLeave={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                                }}
                                                                                                                onDragOver={e => {
                                                                                                                    e.preventDefault()
                                                                                                                    e.stopPropagation()
                                                                                                                    if (transfered.includes("rearrange")) {
                                                                                                                        handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    }
                                                                                                                    setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setMousePos({ ...mousePos, y: e.clientY })
                                                                                                                }}>
                                                                                                                <div style={{ ...subElem?.style, backgroundImage: subElem?.style?.backgroundImage, height: Number(subElem?.style?.height) === 0 ? "auto" : `${subElem?.style?.height}px`, display: "inline-flex", justifyContent: "center", alignItems: "center" }} >
                                                                                                                    <span onDragStart={e => e.stopPropagation()} id={`textField-${key}-${curElem?.positionType}-${j}`}>
                                                                                                                        {/* <ReactQuill
                                                                                                                id={`textField-${key}-${curElem.positionType}-${j}`}
                                                                                                                style={{ width: '100%', color: "black", zIndex: "5" }}
                                                                                                                theme='bubble'
                                                                                                                // defaultValue={"Enter Text"}
                                                                                                                value={subElem.textValue}
                                                                                                                onChange={e => {
                                                                                                                    const dupText = [...colWise]
                                                                                                                    dupText[key].elements[i].element[j].textValue = e
                                                                                                                    setcolWise(dupText)
                                                                                                                }}
                                                                                                                modules={{
                                                                                                                    toolbar: [
                                                                                                                        [{ header: [1, 2, 3, 4, false] }],
                                                                                                                        ['bold', 'italic', 'underline'],
                                                                                                                        [{ size: [] }],
                                                                                                                        ['align', 'strike'],
                                                                                                                        [{ color: [] }],
                                                                                                                        [{ list: 'ordered' }, { list: 'bullet' }]
                                                                                                                    ]
                                                                                                                }}
                                                                                                                formats={[
                                                                                                                    'header',
                                                                                                                    'bold',
                                                                                                                    'italic',
                                                                                                                    'underline',
                                                                                                                    'size',
                                                                                                                    'align',
                                                                                                                    'strike',
                                                                                                                    'blockquote',
                                                                                                                    'color',
                                                                                                                    'list',
                                                                                                                    'bullet'
                                                                                                                ]} /> */}
                                                                                                                        {/* <SunEditor
                                                                                                                    setOptions={SunEditorConfig}
                                                                                                                    
                                                                                                                    value={subElem.textValue || ''}
                                                                                                                    onChange={(content) => {
                                                                                                                        const dupText = [...colWise]
                                                                                                                        dupText[key].elements[i].element[j].textValue = content
                                                                                                                        setcolWise(dupText)
                                                                                                                    }}
                                                                                                                /> */}
                                                                                                                        <div dangerouslySetInnerHTML={{ __html: subElem?.textValue }} />
                                                                                                                    </span>
                                                                                                                </div>
                                                                                                                {(`${currPage}-${key}-${curElem.positionType}-${j}` === `${currPage}-${indexes?.cur}-${indexes?.curElem}-${indexes?.subElem}`) && <div style={{ position: "absolute", width: "calc(100% + 5px)", height: "calc(100% + 7.5px)", outline: "2px solid #727272", pointerEvents: "none" }}></div>}
                                                                                                                {(`${currPage}-${key}-${curElem.positionType}-${j}` === `${currPage}-${mouseEnterIndex?.cur}-${mouseEnterIndex?.curElem}-${mouseEnterIndex?.subElem}`) && <div style={{ position: "absolute", width: "100%", height: "100%", outline: "2px solid #727272", backgroundColor: "rgba(0,0,0,0.5)", pointerEvents: "none", zIndex: "999999999999999999999999999999999999999999999", inset: "0px" }}>
                                                                                                                    <div style={{ position: "relative", width: "100%", height: "100%" }}>
                                                                                                                    </div>
                                                                                                                </div>}
                                                                                                            </div>
                                                                                                        )
                                                                                                    case 'input':
                                                                                                        return (
                                                                                                            <div id={`button-${key}-${curElem.positionType}-${j}`} draggable style={{ width: "100%", display: "flex", justifyContent: subElem?.style?.alignType, position: "relative", display: "flex", justifyContent: "center", alignItems: "center" }}
                                                                                                                onDragStart={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    e.dataTransfer.setData("type", "rearrange_input")
                                                                                                                    setTransfered("rearrange_input")
                                                                                                                    setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }}
                                                                                                                onClick={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                    setCurrPosition({ ...currPosition, selectedType: "input" })
                                                                                                                    setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setValues(subElem?.style)
                                                                                                                }}
                                                                                                                onDrop={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    const transferType = e.dataTransfer.getData("type")
                                                                                                                    if (!transferType.includes("rearrange")) {
                                                                                                                        handleColDrop(e, key, curElem?.positionType, j + 1)
                                                                                                                        setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                    }
                                                                                                                }}
                                                                                                                onMouseEnter={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }}
                                                                                                                onMouseLeave={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                                }}
                                                                                                                onDragOver={e => {
                                                                                                                    e.preventDefault()
                                                                                                                    e.stopPropagation()
                                                                                                                    if (transfered.includes("rearrange")) {
                                                                                                                        handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    }
                                                                                                                    setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j + 1 })
                                                                                                                    setMousePos({ ...mousePos, y: e.clientY })
                                                                                                                }}>
                                                                                                                <div style={{ width: subElem?.style?.width }}>
                                                                                                                    {subElem?.hasLabel && (<label>{subElem?.labelText}</label>)}
                                                                                                                    <input placeholder={subElem?.placeholder} type="text" style={{ ...subElem?.style, backgroundImage: subElem?.style?.backgroundImage, width: "100%" }} />
                                                                                                                </div>
                                                                                                                {(`${currPage}-${key}-${curElem?.positionType}-${j}` === `${currPage}-${indexes?.cur}-${indexes?.curElem}-${indexes?.subElem}`) && <div style={{ position: "absolute", width: "calc(100% + 5px)", height: "calc(100% + 7.5px)", zIndex: "999999999999999999999999999999999999999999999", outline: "2px solid #727272", inset: "0px" }}></div>}
                                                                                                                {(`${currPage}-${key}-${curElem?.positionType}-${j}` === `${currPage}-${mouseEnterIndex?.cur}-${mouseEnterIndex?.curElem}-${mouseEnterIndex?.subElem}`) && <div style={{ position: "absolute", width: "100%", height: "100%", outline: "2px solid #727272", backgroundColor: "rgba(0,0,0,0.5)", pointerEvents: "none", zIndex: "999999999999999999999999999999999999999999999", inset: "0px" }}>
                                                                                                                    <div style={{ position: "relative", width: "100%", height: "100%" }}>
                                                                                                                    </div>
                                                                                                                </div>}
                                                                                                            </div>
                                                                                                        )
                                                                                                    case 'offer':
                                                                                                        return (

                                                                                                            <div
                                                                                                                onDragStart={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    e.dataTransfer.setData("type", "rearrange_offer")
                                                                                                                    setTransfered("rearrange_offer")
                                                                                                                    setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }}
                                                                                                                onMouseEnter={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }}
                                                                                                                onMouseLeave={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                                }}
                                                                                                                onClick={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                    setCurrPosition({ ...currPosition, selectedType: "offer" })
                                                                                                                    setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setValues(subElem.style)
                                                                                                                }}
                                                                                                                onDrop={e => {
                                                                                                                    e.stopPropagation()
                                                                                                                    const transferType = e.dataTransfer.getData("type")
                                                                                                                    if (!transferType.includes("rearrange")) {
                                                                                                                        handleColDrop(e, key, curElem?.positionType, j + 1)
                                                                                                                        setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                    }
                                                                                                                }}
                                                                                                                onDragEnd={e => {
                                                                                                                    handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                }}
                                                                                                                onDragOver={e => {
                                                                                                                    e.preventDefault()
                                                                                                                    e.stopPropagation()
                                                                                                                    setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                    setMousePos({ ...mousePos, y: e.clientY })
                                                                                                                }} className='p-1' style={{ ...values }}>
                                                                                                                {gotOffers ? finalObj?.selectedOffers?.map((ele) => {
                                                                                                                    return (
                                                                                                                        <div className='p-0 mx-0 mt-1 mb-2'>
                                                                                                                            <div style={{
                                                                                                                                flexDirection: 'column',
                                                                                                                                justifyContent: 'center',
                                                                                                                                alignItems: 'center',
                                                                                                                                position: "relative"
                                                                                                                            }}>
                                                                                                                                <div style={{
                                                                                                                                    width: '100%',
                                                                                                                                    minHeight: '100%',
                                                                                                                                    justifyContent: 'center',
                                                                                                                                    // boxShadow: 'rgba(0, 0, 0, 0.125) 10px 2px 5px',
                                                                                                                                    filter: 'drop-shadow(rgba(0, 0, 0, 0.2) 0px 0px 10px',
                                                                                                                                    borderRadius: '10px',
                                                                                                                                    display: 'flex',
                                                                                                                                    position: "relative",
                                                                                                                                    backgroundColor: 'white'
                                                                                                                                }}>
                                                                                                                                    <div className='flex-grow-1 d-flex flex-column justify-content-between' style={{ padding: '15px' }}>
                                                                                                                                        <div style={{ text: 'wrap' }}>
                                                                                                                                            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'start', justifyContent: 'start', textTransform: 'uppercase' }}>
                                                                                                                                                <h2 style={{ fontWeight: 'bolder', fontSize: '0.9rem', color: '#FF671C' }}>
                                                                                                                                                    {ele?.Code}
                                                                                                                                                </h2>
                                                                                                                                                <span style={{ textTransform: 'lowercase', fontSize: '0.75rem', color: 'black' }}>
                                                                                                                                                    {ele?.Summary}
                                                                                                                                                </span>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                        <div>
                                                                                                                                            <div style={{ paddingTop: '0.5rem' }}>
                                                                                                                                                <span style={{ color: 'black', textTransform: 'uppercase', fontWeight: '500', fontSize: '0.65rem' }}>
                                                                                                                                                    valid until: {ele?.ValidityPeriod?.end ? moment(ele?.ValidityPeriod?.end).format('L') : "Never ending"}
                                                                                                                                                </span>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                    <div style={{ display: 'flex', flexDirection: 'column', gap: "0.5rem", padding: "0px 15px 15px" }}>
                                                                                                                                        <div style={{
                                                                                                                                            position: 'relative',
                                                                                                                                            display: 'flex',
                                                                                                                                            flexDirection: 'column',
                                                                                                                                            justifyContent: 'space-between',
                                                                                                                                            alignItems: 'center',
                                                                                                                                            backgroundColor: '#FF671C',
                                                                                                                                            // filter: `hue-rotate(${i * (i + 20)}deg)`,
                                                                                                                                            padding: "1rem 0.25rem",
                                                                                                                                            borderRadius: "0px 0px 5px 5px"
                                                                                                                                        }}>
                                                                                                                                            <h1 style={{
                                                                                                                                                fontSize: '1.829rem',
                                                                                                                                                fontWeight: '750',
                                                                                                                                                fontFamily: 'Montserrat',
                                                                                                                                                color: 'white'
                                                                                                                                            }}>
                                                                                                                                                {
                                                                                                                                                    ele?.Type === "PERCENTAGE" ? (
                                                                                                                                                        `${Number(ele?.Value)?.toFixed(0)}%`
                                                                                                                                                    ) : `₹${Number(ele?.Value)?.toFixed(0)}`
                                                                                                                                                }
                                                                                                                                            </h1>
                                                                                                                                        </div>
                                                                                                                                        <div style={{
                                                                                                                                            display: 'flex',
                                                                                                                                            flexDirection: 'column',
                                                                                                                                            justifyContent: 'flex-end',
                                                                                                                                            alignItems: 'center'
                                                                                                                                        }}>
                                                                                                                                            <button type="button" style={{
                                                                                                                                                color: '#FF671C',
                                                                                                                                                // filter: `hue-rotate(${i * (i + 20)}deg)`,
                                                                                                                                                fontSize: '0.65rem',
                                                                                                                                                fontWeight: '700',
                                                                                                                                                cursor: 'pointer',
                                                                                                                                                border: '0.75px solid #FF671C',
                                                                                                                                                borderRadius: '15px',
                                                                                                                                                padding: '0.195rem',
                                                                                                                                                backgroundColor: 'transparent',
                                                                                                                                                textTransform: 'uppercase',
                                                                                                                                                cursor: 'pointer'
                                                                                                                                            }}>
                                                                                                                                                <span >
                                                                                                                                                    Redeem
                                                                                                                                                </span>
                                                                                                                                            </button>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                                <div style={{
                                                                                                                                    width: 'auto',
                                                                                                                                    // margin: '-0.5rem auto',
                                                                                                                                    position: 'absolute',
                                                                                                                                    bottom: "0px",
                                                                                                                                    backgroundColor: 'white',
                                                                                                                                    textAlign: 'center',
                                                                                                                                    padding: '0.25rem 0.5rem',
                                                                                                                                    borderRadius: '10px',
                                                                                                                                    boxShadow: '0 4px 24px 0 rgba(34, 41, 47, 0.15)',
                                                                                                                                    transform: "translate(-50%, 50%)",
                                                                                                                                    left: "50%"
                                                                                                                                }}>
                                                                                                                                    <span style={{ textTransform: 'lowercase', fontSize: '0.75rem', color: 'black', fontWeight: '300', whiteSpace: "nowrap" }}>
                                                                                                                                        Used xyz times
                                                                                                                                    </span>
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                    )
                                                                                                                }) : (
                                                                                                                    <div className="d-flex justify-content-center align-items-center" style={{ inset: "0px", backgroundColor: "rgba(255,255,255,0.5)" }}>
                                                                                                                        <Spinner />
                                                                                                                    </div>
                                                                                                                )}
                                                                                                            </div>
                                                                                                        )
                                                                                                    default:
                                                                                                        return <div key={i} className='' style={{ display: "flex", justifyContent: "center", alignItems: "center", width: "100%", padding: "1rem" }}
                                                                                                            // onClick={(e) => makActive(e, cur)}
                                                                                                            onDragOver={(e) => {
                                                                                                                e.preventDefault()
                                                                                                                e.stopPropagation()
                                                                                                                makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                handleDragOver(e)
                                                                                                                setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                            }}
                                                                                                            onClick={(e) => {
                                                                                                                makActive(e, cur, curElem, curElem.positionType, key, i, j)
                                                                                                            }}
                                                                                                            onDrop={(e) => {
                                                                                                                e.stopPropagation()
                                                                                                                makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                handleElementDrop(e, curElem?.positionType, key, i, curElem, j)
                                                                                                            }}>
                                                                                                            <Download size={10} style={{ color: 'grey' }} />
                                                                                                            <p style={{ margin: '0px', fontSize: '10px', color: 'grey' }}>Drop an element here</p>
                                                                                                        </div>
                                                                                                }
                                                                                            })}
                                                                                        </div>
                                                                                    )
                                                                                })
                                                                            }
                                                                        </div>
                                                                        {(`${currPage}-${key}-${"parent"}-${"grandparent"}` === `${currPage}-${indexes?.cur}-${indexes?.curElem}-${indexes?.subElem}`) && <div style={{ position: "absolute", width: "calc(100% + 5px)", height: "calc(100% + 7.5px)", outline: "2px solid #727272", pointerEvents: "none" }}></div>}
                                                                        {(`${currPage}-${key}-${"parent"}-${"grandparent"}` === `${currPage}-${mouseEnterIndex?.cur}-${mouseEnterIndex?.curElem}-${mouseEnterIndex?.subElem}`) && <div style={{ position: "absolute", width: "100%", height: "100%", outline: "2px solid #727272", backgroundColor: "rgba(0,0,0,0.5)", pointerEvents: "none", zIndex: "999999999999999999999999999999999999999999999", inset: "0px" }}>
                                                                            <div style={{ position: "relative", width: "100%", height: "100%" }}>
                                                                            </div>
                                                                        </div>}
                                                                    </div>
                                                                })
                                                            }
                                                        </div>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                        {/* <div className="w-100 h-100 position-relative" style={{ display: "flex", justifyContent: popPosition?.includes("L") ? "start" : popPosition?.includes("C") ? "center" : "end", alignItems: popPosition?.includes("T") ? "start" : popPosition?.includes("M") ? "center" : "end", zIndex: "1"}}>
                                    <div className={`position-relative ${isMobile ? "w-100 d-flex justify-content-center" : ""}`}>
                                    </div>
                                    </div> */}
                                        <div style={{ zIndex: "50000000", filter: `drop-shadow(0px 0px 15px rgba(0,0,0,0.5))`, transition: "0.3s ease-in-out", maxWidth: "100%", width: "100%" }}>
                                            <div className="position-relative" style={{ width: "auto" }}>
                                                <span onClick={() => setOpenPage(!openPage)} className="position-absolute d-flex justify-content-center align-items-center cursor-pointer" style={{ top: "0px", left: "50%", transform: `translateX(-50%) translateY(-100%)`, padding: "0.25rem", aspectRatio: "30/9", width: "50px", borderRadius: "10px 10px 0px 0px", backgroundColor: "rgba(0, 0, 0, 0.3)" }}>
                                                    <ChevronUp style={{ rotate: openPage ? "-540deg" : "0deg", transition: "0.3s ease-in-out" }} size={12.5} color='#ffffff' />
                                                </span>
                                                <div id='page-selector' style={{ overflowX: "auto", margin: "auto", borderRadius: "10px 10px 0px 0px", backgroundColor: "rgba(0, 0, 0, 0.35)" }}>
                                                    <Swiper
                                                        breakpoints={{
                                                            0: {
                                                                slidesPerView: 1
                                                            },
                                                            980: {
                                                                slidesPerView: 2
                                                            },
                                                            1440: {
                                                                slidesPerView: finalObj?.pages?.length + 1
                                                            }
                                                        }}
                                                        spaceBetween={0}
                                                        navigation={true}
                                                        loop={false}
                                                        modules={[Pagination, Navigation]}
                                                        className="mySwiper"
                                                        initialSlide={0}>
                                                        {finalObj?.[`${mobileCondition}pages`]?.map((ele, key) => {
                                                            const elem = <div key={key} className="cursor-pointer pt-1">
                                                                <div onClick={() => {
                                                                    if (finalObj?.verificationEnabled || ele?.id !== "user_verification") {
                                                                        setCurrPage(ele?.id)
                                                                        setSideNav("add-elements")
                                                                        const pageIndex = finalObj?.[`${mobileCondition}pages`]?.findIndex($ => $?.id === ele.id)
                                                                        setcolWise([...finalObj?.[`${mobileCondition}pages`][pageIndex]?.values])
                                                                        setPopPosition(finalObj?.positions?.[`${mobileCondition}main`])
                                                                        setIndexes(({ cur: 0, curElem: "left", subElem: "grandparent" }))
                                                                        setCurrPosition({ ...currPosition, selectedType: "navMenuStyles" })
                                                                        setFinalObj({ ...finalObj, backgroundStyles: { ...finalObj?.backgroundStyles, [`${mobileCondition}main`]: bgStyles } })
                                                                    }
                                                                }} className={`overflow-hidden rounded position-relative bg-light-secondary ${currPage === ele.id && openPage ? "border-dark" : ""} ${ele.id === "user_verification" && !finalObj.verificationEnabled ? "opacity-25" : currPage !== ele.id && openPage ? "opacity-50" : ""} m-auto`} style={{ width: '150px', height: openPage ? "84px" : "0px", transition: "0.3s ease-in-out", boxShadow: `0px 0px ${currPage === ele.id && openPage ? "20px" : "0px"} rgba(0,0,0,0.75)` }}>
                                                                    {/* <div className="position-absolute d-flex justify-content-center align-items-center rounded-full" style={{ aspectRatio: "5/2", width: "20px", inset: "0px 0px auto auto", zIndex: "3" }}>
                                                        <UncontrolledDropdown className='more-options-dropdown'>
                                                            <DropdownToggle className={`btn-icon cursor-pointer p-0`} color='transparent' size='sm'>
                                                                <MoreHorizontal style={{ filter: "drop-shadow(0px 0px 1px rgba(0,0,0,1))" }} color={"#ffffff"} size={17.5} />
                                                            </DropdownToggle>
                                                            <DropdownMenu start>
                                                                <DropdownItem
                                                                    onClick={(e) => {
                                                                        e.stopPropagation()
                                                                        console.log("Rename")
                                                                    }} className='w-100'>
                                                                    <div className="d-flex align-items-center" style={{ gap: "0.5rem" }}>
                                                                        <Edit2 stroke='blue' size={"15px"} className='cursor-pointer' /> <span className='fw-bold text-black' style={{ fontSize: "0.75rem" }}>Rename</span>
                                                                    </div>
                                                                </DropdownItem>
                                                            </DropdownMenu>
                                                        </UncontrolledDropdown>
                                                    </div> */}
                                                                    <div className={`overflow-hidden d-flex justify-content-center align-items-center w-100 h-100`}>
                                                                        <div className="position-absolute" style={{ scale: "0.215", marginLeft: "10%", pointerEvents: "none", width: isMobile ? "325px" : "auto" }}>
                                                                            <div style={{ position: "relative", width: bgStyles.width, maxWidth: bgStyles.maxWidth, maxHeight: "100%", minHeight: bgStyles.minHeight }}>
                                                                                <span style={{ position: "absolute", inset: "0px 0px auto auto", zIndex: "350" }}><X size={18} /></span>
                                                                                <div id="dropZoneParent" className="pop-up" style={{ position: 'relative', zIndex: '300', overflow: "auto", backgroundColor: "white", ...bgStyles, backgroundImage: bgStyles?.backgroundImage, width: "100%", maxWidth: "100%" }}>
                                                                                    <style>
                                                                                        {`
                                                                        .ql-editor {
                                                                        padding: 0px !important;
                                                                        text-align: center !important
                                                                        }
                                                                        #dropZoneParent::-webkit-scrollbar, .nav-sidebar::-webkit-scrollbar {
                                                                            display: none;
                                                                        }
                                                                    `}
                                                                                    </style>
                                                                                    {/* render layout Here */}
                                                                                    {
                                                                                        ele.values?.map((cur, key) => {
                                                                                            return <div style={{ ...cur?.style, display: "flex", justifyContent: "center", alignItems: "center", position: "relative" }} key={key}
                                                                                                onClick={(e) => {
                                                                                                    e.stopPropagation()
                                                                                                    makActive(e, cur, "parent", "parent", key, "parent", "parent")
                                                                                                    setCurrPosition({ ...currPosition, selectedType: "block" })
                                                                                                    setIndexes({ cur: key, curElem: "parent", subElem: "grandparent" })
                                                                                                    setValues(cur?.style)
                                                                                                    // setShowActive(!isEqual({ ...indexes }, { cur: key, curElem: "parent", subElem: "grandparent" }))
                                                                                                }}
                                                                                                onMouseEnter={(e) => {
                                                                                                    e.stopPropagation()
                                                                                                    setMouseEnterIndex({ cur: key, curElem: "parent", subElem: "grandparent" })
                                                                                                }}
                                                                                                onMouseLeave={(e) => {
                                                                                                    e.stopPropagation()
                                                                                                    setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                }}
                                                                                                id={`${currPage}-${key}-parent-grandparent`}
                                                                                                className={`${isEqual({ cur: key, curElem: "parent", subElem: "grandparent" }, { ...indexes }) ? "active-elem" : ""}`}
                                                                                            >
                                                                                                <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "center", alignItems: "stretch", position: "relative", width: "100%", zIndex: "1" }}
                                                                                                >
                                                                                                    {
                                                                                                        cur?.elements?.map((curElem, i) => {
                                                                                                            return (
                                                                                                                <div style={{ ...curElem?.style, position: "relative", width: isMobile ? "100%" : curElem?.style?.width }} onClick={(e) => {
                                                                                                                    e.stopPropagation()
                                                                                                                    // setActiveRow("none")
                                                                                                                    makActive(e, cur, curElem, curElem?.positionType, key, i, "parent")
                                                                                                                    setCurrPosition({ ...currPosition, selectedType: "column" })
                                                                                                                    setIndexes({ cur: key, curElem: curElem?.positionType, subElem: "parent" })
                                                                                                                    setValues(curElem?.style)
                                                                                                                }}
                                                                                                                    onMouseEnter={(e) => {
                                                                                                                        e.stopPropagation()
                                                                                                                        setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: "parent" })
                                                                                                                    }}
                                                                                                                    onMouseLeave={(e) => {
                                                                                                                        e.stopPropagation()
                                                                                                                        setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                                    }}
                                                                                                                    onDrop={e => {
                                                                                                                        e.stopPropagation()
                                                                                                                        handleColDrop(e, key, curElem?.positionType, curElem?.element?.length, i)
                                                                                                                        const transferType = e.dataTransfer.getData("type")
                                                                                                                        setCurrPosition({ ...currPosition, j: curElem?.element?.length, selectedType: transferType })
                                                                                                                    }}
                                                                                                                    id={`${currPage}-${key}-${curElem.positionType}-parent`}
                                                                                                                    className={`${isEqual({ cur: key, curElem: curElem.positionType, subElem: "parent" }, { ...indexes }) ? "active-elem" : ""}`}>
                                                                                                                    {curElem?.element?.map((subElem, j) => {
                                                                                                                        switch (subElem?.type) {
                                                                                                                            case 'text':
                                                                                                                                // return <span contentEditable="true" className="text-secondary p-1 rounded-2 " style={{ fontSize: '14.4px', border: '1px solid black' }} onClick={(e) => makActive(e, cur)} >Text Element</span>
                                                                                                                                return (
                                                                                                                                    <div id={`${currPage}-${key}-${curElem?.positionType}-${j}`} draggable={!isEqual({ cur: key, curElem: curElem?.positionType, subElem: j }, { ...indexes })} onDragStart={(e) => {
                                                                                                                                        e.stopPropagation()
                                                                                                                                        e.dataTransfer.setData("type", "rearrange_text")
                                                                                                                                        setTransfered("rearrange_text")
                                                                                                                                        setIndexes({ cur: key, curElem: curElem.positionType, subElem: j })
                                                                                                                                        setDragStartIndex({ cur: key, curElem: curElem.positionType, subElem: j })
                                                                                                                                    }} style={{ ...subElem?.style, width: "100%", position: "relative", display: "flex", justifyContent: "center", alignItems: "center", fontFamily: subElem?.isInitialFont ? finalObj?.fontFamilies?.[subElem.textType] : subElem?.style?.fontFamily, zIndex: isEqual({ ...indexes }, { cur: key, curElem: curElem.positionType, subElem: j }) ? "2" : "1" }}
                                                                                                                                        onClick={e => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                                            setCurrPosition({ ...currPosition, selectedType: "text" })
                                                                                                                                            setIndexes({ cur: key, curElem: curElem.positionType, subElem: j })
                                                                                                                                            setValues(subElem?.style)
                                                                                                                                        }}
                                                                                                                                        onDrop={e => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            const transferType = e.dataTransfer.getData("type")
                                                                                                                                            if (!transferType.includes("rearrange")) {
                                                                                                                                                handleColDrop(e, key, curElem.positionType, j + 1, i)
                                                                                                                                                setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                                            } else {
                                                                                                                                                handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            }
                                                                                                                                        }}
                                                                                                                                        onMouseEnter={(e) => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                        }}
                                                                                                                                        onMouseLeave={(e) => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                                                        }}
                                                                                                                                        onDragOver={e => {
                                                                                                                                            e.preventDefault()
                                                                                                                                            e.stopPropagation()
                                                                                                                                            setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            setMousePos({ ...mousePos, y: e.clientY, x: e.clientX })
                                                                                                                                        }}
                                                                                                                                        className={`${isEqual({ cur: key, curElem: curElem?.positionType, subElem: j }, { ...indexes }) ? "active-elem" : ""}`}>
                                                                                                                                        <div style={{ width: "100%" }} id={`textField-${key}-${curElem?.positionType}-${j}`} className="text-field" dangerouslySetInnerHTML={{ __html: subElem?.textValue }} />
                                                                                                                                        {/* <ReactQuill
                                                                                                                                id={`textField-${key}-${curElem.positionType}-${j}`}
                                                                                                                                style={{ width: '100%', color: "black", zIndex: "5" }}
                                                                                                                                theme='bubble'
                                                                                                                                // defaultValue={"Enter Text"}
                                                                                                                                value={subElem.textValue}
                                                                                                                                onChange={e => {
                                                                                                                                    const dupText = [...colWise]
                                                                                                                                    dupText[key].elements[i].element[j].textValue = e
                                                                                                                                    setcolWise(dupText)
                                                                                                                                }}
                                                                                                                                modules={{
                                                                                                                                    toolbar: [
                                                                                                                                        [{ header: [1, 2, 3, 4, false] }],
                                                                                                                                        ['bold', 'italic', 'underline'],
                                                                                                                                        [{ size: [] }],
                                                                                                                                        ['align', 'strike'],
                                                                                                                                        [{ color: [] }],
                                                                                                                                        [{ list: 'ordered' }, { list: 'bullet' }]
                                                                                                                                    ]
                                                                                                                                }}
                                                                                                                                formats={[
                                                                                                                                    'header',
                                                                                                                                    'bold',
                                                                                                                                    'italic',
                                                                                                                                    'underline',
                                                                                                                                    'size',
                                                                                                                                    'align',
                                                                                                                                    'strike',
                                                                                                                                    'blockquote',
                                                                                                                                    'color',
                                                                                                                                    'list',
                                                                                                                                    'bullet'
                                                                                                                                ]} /> */}
                                                                                                                                        {/* <SunEditor
                                                                                                                                setOptions={SunEditorConfig}
                                                                                                                                id={`textField-${key}-${curElem.positionType}-${j}`}
                                                                                                                                value={subElem.textValue || ''}
                                                                                                                                onChange={(content) => {
                                                                                                                                    const dupText = [...colWise]
                                                                                                                                    dupText[key].elements[i].element[j].textValue = content
                                                                                                                                    setcolWise(dupText)
                                                                                                                                }}
                                                                                                                            /> */}
                                                                                                                                    </div>
                                                                                                                                )
                                                                                                                            case 'image':
                                                                                                                                // const imageSelector = document.getElementById("hidden-image-input")
                                                                                                                                if (subElem.src !== "") {
                                                                                                                                    return (
                                                                                                                                        <div id={`${currPage}-${key}-${curElem?.positionType}-${j}`} draggable style={{ width: "100%", ...subElem?.style, position: "relative", display: "flex", justifyContent: "center", alignItems: "center" }}
                                                                                                                                            onDragStart={e => {
                                                                                                                                                e.stopPropagation()
                                                                                                                                                e.dataTransfer.setData("type", "rearrange_image")
                                                                                                                                                setTransfered("rearrange_image")
                                                                                                                                                setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                                setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            }}
                                                                                                                                            onMouseEnter={(e) => {
                                                                                                                                                e.stopPropagation()
                                                                                                                                                setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            }}
                                                                                                                                            onMouseLeave={(e) => {
                                                                                                                                                e.stopPropagation()
                                                                                                                                                setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                                                            }}
                                                                                                                                            onClick={e => {
                                                                                                                                                e.stopPropagation()
                                                                                                                                                makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                                                setCurrPosition({ ...currPosition, selectedType: "image" })
                                                                                                                                                setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                                setValues(subElem?.style)
                                                                                                                                            }}
                                                                                                                                            onDrop={e => {
                                                                                                                                                e.stopPropagation()
                                                                                                                                                const transferType = e.dataTransfer.getData("type")
                                                                                                                                                if (!transferType.includes("rearrange")) {
                                                                                                                                                    handleColDrop(e, key, curElem?.positionType, j + 1, i)
                                                                                                                                                    setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                                                } else {
                                                                                                                                                    handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                                }
                                                                                                                                            }}
                                                                                                                                            onDragOver={e => {
                                                                                                                                                e.preventDefault()
                                                                                                                                                e.stopPropagation()
                                                                                                                                                setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                                setMousePos({ ...mousePos, y: e.clientY })
                                                                                                                                            }}
                                                                                                                                            className={`${isEqual({ cur: key, curElem: curElem?.positionType, subElem: j }, { ...indexes }) ? "active-elem" : ""}`}>
                                                                                                                                            <img
                                                                                                                                                className="img-fluid"
                                                                                                                                                src={subElem.src}
                                                                                                                                                alt={`Selected Image ${i}`}
                                                                                                                                                style={{ width: "100%" }}
                                                                                                                                            />
                                                                                                                                        </div>
                                                                                                                                    )
                                                                                                                                } else {
                                                                                                                                    setCurrPosition({ ...currPosition, j })
                                                                                                                                    // imageSelector.click()
                                                                                                                                    triggerImage()
                                                                                                                                    const dupArray = [...colWise]
                                                                                                                                    dupArray[key].elements[i].element[j].src = "http://www.palmares.lemondeduchiffre.fr/images/joomlart/demo/default.jpg"
                                                                                                                                    setcolWise([...dupArray])
                                                                                                                                }
                                                                                                                            case 'button':
                                                                                                                                return (
                                                                                                                                    <div id={`${currPage}-${key}-${curElem?.positionType}-${j}`} draggable style={{ width: "100%", display: "flex", justifyContent: subElem?.style?.alignType, position: "relative", display: "flex", alignItems: "center" }}
                                                                                                                                        onDragStart={e => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            e.dataTransfer.setData("type", "rearrange_button")
                                                                                                                                            setTransfered("rearrange_button")
                                                                                                                                            setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                        }}
                                                                                                                                        onClick={e => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                                            setCurrPosition({ ...currPosition, selectedType: "button" })
                                                                                                                                            setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            setValues(subElem.style)
                                                                                                                                        }}
                                                                                                                                        onDrop={e => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            const transferType = e.dataTransfer.getData("type")
                                                                                                                                            if (!transferType.includes("rearrange")) {
                                                                                                                                                handleColDrop(e, key, curElem?.positionType, j + 1, i)
                                                                                                                                                setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                                            } else {
                                                                                                                                                handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            }
                                                                                                                                        }}
                                                                                                                                        onMouseEnter={(e) => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                        }}
                                                                                                                                        onMouseLeave={(e) => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                                                        }}
                                                                                                                                        onDragOver={e => {
                                                                                                                                            e.preventDefault()
                                                                                                                                            e.stopPropagation()
                                                                                                                                            setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            setMousePos({ ...mousePos, y: e.clientY })
                                                                                                                                        }}
                                                                                                                                        className={`${isEqual({ cur: key, curElem: curElem?.positionType, subElem: j }, { ...indexes }) ? "active-elem" : ""}`}>
                                                                                                                                        <div style={{ ...subElem?.style, height: Number(subElem?.style?.height) === 0 ? "auto" : `${subElem?.style?.height}px`, display: "inline-flex", justifyContent: "center", alignItems: "center", fontFamily: subElem?.isInitialFont ? finalObj?.fontFamilies?.[subElem.textType] : subElem?.style?.fontFamily }} >
                                                                                                                                            <span onDragStart={e => e.stopPropagation()} id={`textField-${key}-${curElem?.positionType}-${j}`}>
                                                                                                                                                {/* <ReactQuill
                                                                                                                                id={`textField-${key}-${curElem.positionType}-${j}`}
                                                                                                                                style={{ width: '100%', color: "black", zIndex: "5" }}
                                                                                                                                theme='bubble'
                                                                                                                                // defaultValue={"Enter Text"}
                                                                                                                                value={subElem.textValue}
                                                                                                                                onChange={e => {
                                                                                                                                    const dupText = [...colWise]
                                                                                                                                    dupText[key].elements[i].element[j].textValue = e
                                                                                                                                    setcolWise(dupText)
                                                                                                                                }}
                                                                                                                                modules={{
                                                                                                                                    toolbar: [
                                                                                                                                        [{ header: [1, 2, 3, 4, false] }],
                                                                                                                                        ['bold', 'italic', 'underline'],
                                                                                                                                        [{ size: [] }],
                                                                                                                                        ['align', 'strike'],
                                                                                                                                        [{ color: [] }],
                                                                                                                                        [{ list: 'ordered' }, { list: 'bullet' }]
                                                                                                                                    ]
                                                                                                                                }}
                                                                                                                                formats={[
                                                                                                                                    'header',
                                                                                                                                    'bold',
                                                                                                                                    'italic',
                                                                                                                                    'underline',
                                                                                                                                    'size',
                                                                                                                                    'align',
                                                                                                                                    'strike',
                                                                                                                                    'blockquote',
                                                                                                                                    'color',
                                                                                                                                    'list',
                                                                                                                                    'bullet'
                                                                                                                                ]} /> */}
                                                                                                                                                {/* <SunEditor
                                                                                                                                    setOptions={SunEditorConfig}
                                                        
                                                                                                                                    value={subElem.textValue || ''}
                                                                                                                                    onChange={(content) => {
                                                                                                                                        const dupText = [...colWise]
                                                                                                                                        dupText[key].elements[i].element[j].textValue = content
                                                                                                                                        setcolWise(dupText)
                                                                                                                                    }}
                                                                                                                                /> */}
                                                                                                                                                <div className="text-field" dangerouslySetInnerHTML={{ __html: subElem?.textValue }} />
                                                                                                                                            </span>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                )
                                                                                                                            case 'input':
                                                                                                                                return (
                                                                                                                                    <div id={`${currPage}-${key}-${curElem?.positionType}-${j}`} draggable style={{ width: "100%", display: "flex", justifyContent: subElem?.style?.alignType, position: "relative", alignItems: "center" }}
                                                                                                                                        onDragStart={e => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            e.dataTransfer.setData("type", "rearrange_input")
                                                                                                                                            setTransfered("rearrange_input")
                                                                                                                                            setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                        }}
                                                                                                                                        onClick={e => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                                            setCurrPosition({ ...currPosition, selectedType: "input" })
                                                                                                                                            setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            setValues(subElem.style)
                                                                                                                                        }}
                                                                                                                                        onDrop={e => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            const transferType = e.dataTransfer.getData("type")
                                                                                                                                            if (!transferType.includes("rearrange")) {
                                                                                                                                                handleColDrop(e, key, curElem?.positionType, j + 1, i)
                                                                                                                                                setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                                            } else {
                                                                                                                                                handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            }
                                                                                                                                        }}
                                                                                                                                        onMouseEnter={(e) => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                        }}
                                                                                                                                        onMouseLeave={(e) => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                                                        }}
                                                                                                                                        onDragOver={e => {
                                                                                                                                            e.preventDefault()
                                                                                                                                            e.stopPropagation()
                                                                                                                                            setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j + 1 })
                                                                                                                                            setMousePos({ ...mousePos, y: e.clientY })
                                                                                                                                        }}
                                                                                                                                        className={`${isEqual({ cur: key, curElem: curElem?.positionType, subElem: j }, { ...indexes }) ? "active-elem" : ""}`}>
                                                                                                                                        <div style={{ width: subElem?.style?.width }}>
                                                                                                                                            {subElem?.hasLabel && (<label style={{ color: subElem?.style?.color, fontFamily: subElem?.style?.fontFamily }}>{subElem?.labelText}</label>)}
                                                                                                                                            <input placeholder={subElem?.placeholder} type="text" style={{ ...subElem?.style, width: "100%" }} disabled />
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                )
                                                                                                                            case 'offer':
                                                                                                                                return (
                                                                                                                                    <div
                                                                                                                                        onDragStart={e => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            e.dataTransfer.setData("type", "rearrange_offer")
                                                                                                                                            setTransfered("rearrange_offer")
                                                                                                                                            setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            setDragStartIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                        }}
                                                                                                                                        onMouseEnter={(e) => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            setMouseEnterIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                        }}
                                                                                                                                        onMouseLeave={(e) => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            setMouseEnterIndex({ cur: false, curElem: false, subElem: false })
                                                                                                                                        }}
                                                                                                                                        onClick={e => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                                            setCurrPosition({ ...currPosition, selectedType: "offer" })
                                                                                                                                            setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            setValues(subElem?.style)
                                                                                                                                        }}
                                                                                                                                        onDrop={e => {
                                                                                                                                            e.stopPropagation()
                                                                                                                                            const transferType = e.dataTransfer.getData("type")
                                                                                                                                            if (!transferType.includes("rearrange")) {
                                                                                                                                                handleColDrop(e, key, curElem?.positionType, j + 1, i)
                                                                                                                                                setCurrPosition({ ...currPosition, j: j + 1, selectedType: transferType })
                                                                                                                                            } else {
                                                                                                                                                handleRearrangeElement(e, { cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            }
                                                                                                                                        }}
                                                                                                                                        onDragOver={e => {
                                                                                                                                            e.preventDefault()
                                                                                                                                            e.stopPropagation()
                                                                                                                                            setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                            setMousePos({ ...mousePos, y: e.clientY })
                                                                                                                                        }} style={{ ...subElem?.style, ...values, position: "relative", fontFamily: subElem?.isInitialFont ? finalObj?.fontFamilies?.[subElem.textType] : subElem?.style?.fontFamily }}
                                                                                                                                        id={`${currPage}-${key}-${curElem.positionType}-${j}`}
                                                                                                                                        className={`${isEqual({ cur: key, curElem: curElem.positionType, subElem: j }, { ...indexes }) ? "active-elem" : ""}`}>
                                                                                                                                        {gotOffers ? finalObj?.selectedOffers?.map((ele) => {
                                                                                                                                            return (
                                                                                                                                                <ReturnOfferHtml details={ele} key={key} theme={offerTheme} colors={finalObj?.offerProperties?.colors} />
                                                                                                                                                // <div style={{ margin: "10px 0px 20px" }}>
                                                                                                                                                //     <div style={{
                                                                                                                                                //         flexDirection: 'column',
                                                                                                                                                //         justifyContent: 'center',
                                                                                                                                                //         alignItems: 'center',
                                                                                                                                                //         position: "relative"
                                                                                                                                                //     }}>
                                                                                                                                                //         <div style={{
                                                                                                                                                //             width: '100%',
                                                                                                                                                //             minHeight: '100%',
                                                                                                                                                //             justifyContent: 'center',
                                                                                                                                                //             // boxShadow: 'rgba(0, 0, 0, 0.125) 10px 2px 5px',
                                                                                                                                                //             filter: 'drop-shadow(rgba(0, 0, 0, 0.2) 0px 0px 10px',
                                                                                                                                                //             borderRadius: '10px',
                                                                                                                                                //             display: 'flex',
                                                                                                                                                //             position: "relative",
                                                                                                                                                //             backgroundColor: finalObj?.offerProperties?.colors?.primaryBg
                                                                                                                                                //         }}>
                                                                                                                                                //             <div className='flex-grow-1 d-flex flex-column justify-content-between' style={{ padding: '15px' }}>
                                                                                                                                                //                 <div style={{ text: 'wrap' }}>
                                                                                                                                                //                     <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'start', justifyContent: 'start', textTransform: 'uppercase' }}>
                                                                                                                                                //                         <h2 style={{ fontWeight: 'bolder', fontSize: '0.9rem', color: finalObj?.offerProperties?.colors?.code }}>
                                                                                                                                                //                             {ele?.Code}
                                                                                                                                                //                         </h2>
                                                                                                                                                //                         {finalObj?.offerProperties?.showSections?.includes("description") && <span style={{ textTransform: 'lowercase', fontSize: '0.75rem', color: finalObj?.offerProperties?.colors?.description }}>
                                                                                                                                                //                             {ele?.Summary}
                                                                                                                                                //                         </span>}
                                                                                                                                                //                     </div>
                                                                                                                                                //                 </div>
                                                                                                                                                //                 {finalObj?.offerProperties?.showSections?.includes("validity") && <div>
                                                                                                                                                //                     <div style={{ paddingTop: '0.5rem' }}>
                                                                                                                                                //                         <span style={{ color: finalObj?.offerProperties?.colors?.validity, textTransform: 'uppercase', fontWeight: '500', fontSize: '0.65rem' }}>
                                                                                                                                                //                             valid until: {ele?.ValidityPeriod?.end ? moment(ele?.ValidityPeriod?.end).format('L') : "Never ending"}
                                                                                                                                                //                         </span>
                                                                                                                                                //                     </div>
                                                                                                                                                //                 </div>}
                                                                                                                                                //             </div>
                                                                                                                                                //             <div style={{ display: 'flex', flexDirection: 'column', gap: "0.5rem", padding: "0px 15px 15px" }}>
                                                                                                                                                //                 <div style={{
                                                                                                                                                //                     position: 'relative',
                                                                                                                                                //                     display: 'flex',
                                                                                                                                                //                     flexDirection: 'column',
                                                                                                                                                //                     justifyContent: 'space-between',
                                                                                                                                                //                     alignItems: 'center',
                                                                                                                                                //                     backgroundColor: finalObj?.offerProperties?.colors?.secondaryBg,
                                                                                                                                                //                     // filter: `hue-rotate(${i * (i + 20)}deg)`,
                                                                                                                                                //                     padding: "1rem 0.25rem",
                                                                                                                                                //                     borderRadius: "0px 0px 5px 5px"
                                                                                                                                                //                 }}>
                                                                                                                                                //                     <h1 style={{
                                                                                                                                                //                         fontSize: '1.829rem',
                                                                                                                                                //                         fontWeight: '750',
                                                                                                                                                //                         fontFamily: 'Montserrat',
                                                                                                                                                //                         color: finalObj?.offerProperties?.colors?.value
                                                                                                                                                //                     }}>
                                                                                                                                                //                         {
                                                                                                                                                //                             ele?.Type === "PERCENTAGE" ? (
                                                                                                                                                //                                 `${Number(ele?.Value).toFixed(0)}%`
                                                                                                                                                //                             ) : `₹${Number(ele?.Value).toFixed(0)}`
                                                                                                                                                //                         }
                                                                                                                                                //                     </h1>
                                                                                                                                                //                 </div>
                                                                                                                                                //                 <div style={{
                                                                                                                                                //                     display: 'flex',
                                                                                                                                                //                     flexDirection: 'column',
                                                                                                                                                //                     justifyContent: 'flex-end',
                                                                                                                                                //                     alignItems: 'center'
                                                                                                                                                //                 }}>
                                                                                                                                                //                     <button type="button" style={{
                                                                                                                                                //                         color: finalObj?.offerProperties?.colors?.button,
                                                                                                                                                //                         // filter: `hue-rotate(${i * (i + 20)}deg)`,
                                                                                                                                                //                         fontSize: '0.65rem',
                                                                                                                                                //                         fontWeight: '700',
                                                                                                                                                //                         cursor: 'pointer',
                                                                                                                                                //                         border: `0.75px solid ${finalObj?.offerProperties?.colors?.button}`,
                                                                                                                                                //                         borderRadius: '15px',
                                                                                                                                                //                         padding: '0.195rem',
                                                                                                                                                //                         backgroundColor: 'transparent',
                                                                                                                                                //                         textTransform: 'uppercase',
                                                                                                                                                //                         cursor: 'pointer'
                                                                                                                                                //                     }}>
                                                                                                                                                //                         <span >
                                                                                                                                                //                             Redeem
                                                                                                                                                //                         </span>
                                                                                                                                                //                     </button>
                                                                                                                                                //                 </div>
                                                                                                                                                //             </div>
                                                                                                                                                //         </div>
                                                                                                                                                //         {finalObj?.offerProperties?.showSections?.includes("usage") && <div style={{
                                                                                                                                                //             width: 'auto',
                                                                                                                                                //             // margin: '-0.5rem auto',
                                                                                                                                                //             position: 'absolute',
                                                                                                                                                //             bottom: "0px",
                                                                                                                                                //             backgroundColor: 'white',
                                                                                                                                                //             textAlign: 'center',
                                                                                                                                                //             padding: '0.25rem 0.5rem',
                                                                                                                                                //             borderRadius: '10px',
                                                                                                                                                //             boxShadow: '0 4px 24px 0 rgba(34, 41, 47, 0.15)',
                                                                                                                                                //             transform: "translate(-50%, 50%)",
                                                                                                                                                //             left: "50%"
                                                                                                                                                //         }}>
                                                                                                                                                //             <span style={{ textTransform: 'lowercase', fontSize: '0.75rem', color: finalObj.offerProperties.colors.usage, backgroundColor: finalObj.offerProperties.colors.primaryBg, fontWeight: '300', whiteSpace: "nowrap" }}>
                                                                                                                                                //                 Used xyz times
                                                                                                                                                //             </span>
                                                                                                                                                //         </div>}
                                                                                                                                                //     </div>
                                                                                                                                                // </div>
                                                                                                                                            )
                                                                                                                                        }) : (
                                                                                                                                            <div className="d-flex justify-content-center align-items-center" style={{ inset: "0px", backgroundColor: "rgba(255,255,255,0.5)" }}>
                                                                                                                                                <Spinner />
                                                                                                                                            </div>
                                                                                                                                        )}
                                                                                                                                    </div>
                                                                                                                                )
                                                                                                                            default:
                                                                                                                                return <div key={i} className='' style={{ display: "flex", justifyContent: "center", alignItems: "center", width: "100%", padding: "1rem" }}
                                                                                                                                    // onClick={(e) => makActive(e, cur)}
                                                                                                                                    onDragOver={(e) => {
                                                                                                                                        e.preventDefault()
                                                                                                                                        e.stopPropagation()
                                                                                                                                        makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                                        handleDragOver(e)
                                                                                                                                        setDragOverIndex({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                        setIndexes({ cur: key, curElem: curElem?.positionType, subElem: j })
                                                                                                                                    }}
                                                                                                                                    onClick={(e) => {
                                                                                                                                        makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                                    }}
                                                                                                                                    onDrop={(e) => {
                                                                                                                                        e.stopPropagation()
                                                                                                                                        makActive(e, cur, curElem, curElem?.positionType, key, i, j)
                                                                                                                                        handleElementDrop(e, curElem?.positionType, key, i, curElem, j)
                                                                                                                                    }}>
                                                                                                                                    <Download size={10} style={{ color: 'grey' }} />
                                                                                                                                    <p style={{ margin: '0px', fontSize: '10px', color: 'grey' }}>Drop an element here</p>
                                                                                                                                </div>
                                                                                                                        }
                                                                                                                    })}
                                                                                                                </div>
                                                                                                            )
                                                                                                        })
                                                                                                    }
                                                                                                </div>
                                                                                            </div>
                                                                                        })
                                                                                    }
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="d-flex justify-content-center align-items-center form-check form-switch form-check-dark p-0" style={{ gap: "0.0125rem" }}>
                                                                    <p onClick={() => {
                                                                        if (finalObj?.verificationEnabled || ele.id !== "user_verification") {
                                                                            setCurrPage(ele.id)
                                                                            setSideNav("add-elements")
                                                                            const pageIndex = finalObj?.[`${mobileCondition}pages`]?.findIndex($ => $?.id === ele.id)
                                                                            setcolWise([...finalObj?.[`${mobileCondition}pages`][pageIndex]?.values])
                                                                            setPopPosition(finalObj.positions[`${mobileCondition}main`])
                                                                            setIndexes(({ cur: 0, curElem: "left", subElem: "grandparent" }))
                                                                            setCurrPosition({ ...currPosition, selectedType: "navMenuStyles" })
                                                                            setFinalObj({ ...finalObj, backgroundStyles: { ...finalObj?.backgroundStyles, [`${mobileCondition}main`]: bgStyles } })
                                                                        }
                                                                    }} className={`text-center m-0 fw-bold ${currPage === ele?.id ? "text-white" : "dark"} ${ele?.id === "user_verification" && !finalObj?.verificationEnabled ? "opacity-50" : ""}`} style={{ fontSize: "12px", padding: "0.5rem" }}>{ele?.pageName}</p>
                                                                    {(ele.id === "user_verification") && <input checked={finalObj?.verificationEnabled} onChange={e => {
                                                                        if (!e.target.checked && (currPage === "user_verification")) {
                                                                            setCurrPage(finalObj?.[`${mobileCondition}pages`][0]?.id)
                                                                            setcolWise(finalObj?.[`${mobileCondition}pages`][0]?.values)
                                                                            setPopPosition(finalObj?.positions?.[`${mobileCondition}main`])
                                                                            setCurrPosition({ ...currPosition, selectedType: "navMenuStyles" })
                                                                        }
                                                                        setFinalObj({ ...finalObj, verificationEnabled: e.target.checked })
                                                                    }} style={{ width: "30px", height: "15px" }} type="checkbox" className="form-check-input m-0 cursor-pointer" />}
                                                                </div>
                                                            </div>
                                                            return (
                                                                <SwiperSlide>{elem}</SwiperSlide>
                                                            )
                                                        })}
                                                        <SwiperSlide>
                                                            <div className='cursor-pointer pt-1'>
                                                                <div onClick={() => {
                                                                    if (finalObj?.teaserEnabled) {
                                                                        setCurrPage("button")
                                                                        setSideNav(sideNav === "display" ? "display" : "button")
                                                                        setcolWise([...finalObj?.button])
                                                                        setPopPosition(finalObj?.positions?.button)
                                                                        setCurrPosition({ ...currPosition, selectedType: "navMenuStyles" })
                                                                    }
                                                                }} className={`m-auto rounded d-flex justify-content-center align-items-center bg-light-secondary ${!finalObj?.teaserEnabled ? "opacity-25" : currPage !== "button" ? "opacity-50" : "border-dark"}`} style={{ width: '150px', height: openPage ? "84px" : "0px", transition: "0.3s ease-in-out", boxShadow: `0px 0px ${currPage === "button" && openPage ? "20px" : "0px"} rgba(0,0,0,0.75)` }}>
                                                                    <div className="position-absolute" style={{ scale: "0.5", pointerEvents: "none", overflow: "hidden", transition: "0.3s ease-in-out", opacity: openPage ? "1" : "0" }}>
                                                                        <div style={{ position: "relative", width: finalObj?.backgroundStyles?.[`${mobileCondition}button`]?.width, maxWidth: finalObj?.backgroundStyles?.[`${mobileCondition}button`]?.maxWidth, maxHeight: "100%", minHeight: finalObj?.backgroundStyles?.[`${mobileCondition}button`]?.minHeight }}>
                                                                            {/* <span style={{ position: "absolute", inset: "0px 0px auto auto", zIndex: "350" }}><X size={18} /></span> */}
                                                                            <div id="dropZoneParent" className="pop-up" style={{ position: 'relative', zIndex: '300', overflow: "auto", backgroundColor: "white", ...finalObj?.backgroundStyles[`${mobileCondition}button`], backgroundImage: finalObj?.backgroundStyles[`${mobileCondition}button`]?.backgroundImage, width: "100%", maxWidth: "100%" }}>
                                                                                <style>
                                                                                    {`
                                                                    .ql-editor {
                                                                    padding: 0px !important;
                                                                    text-align: center !important
                                                                    }
                                                                    #dropZoneParent::-webkit-scrollbar, .nav-sidebar::-webkit-scrollbar {
                                                                        display: none;
                                                                    }
                                                                `}
                                                                                </style>
                                                                                {/* render layout Here */}
                                                                                {
                                                                                    finalObj[`${mobileCondition}button`]?.map((cur, key) => {
                                                                                        return <div style={{ ...cur?.style, backgroundImage: cur?.style?.backgroundImage, display: "flex", justifyContent: "center", alignItems: "center", position: "relative" }} key={key}
                                                                                        >
                                                                                            <div style={{ display: "flex", justifyContent: "center", alignItems: "center", position: "relative", width: "100%", zIndex: "1" }}
                                                                                            >
                                                                                                {
                                                                                                    cur?.elements?.map((curElem, i) => {
                                                                                                        return (
                                                                                                            <div style={{ ...curElem?.style, backgroundImage: curElem?.style?.backgroundImage }}>
                                                                                                                {curElem?.element?.map((subElem, j) => {
                                                                                                                    switch (subElem?.type) {
                                                                                                                        case 'text':
                                                                                                                            // return <span contentEditable="true" className="text-secondary p-1 rounded-2 " style={{ fontSize: '14.4px', border: '1px solid black' }} onClick={(e) => makActive(e, cur)} >Text Element</span>
                                                                                                                            return (
                                                                                                                                <div id={`button-${key}-${curElem?.positionType}-${j}`} style={{ ...subElem.style, backgroundImage: subElem?.style?.backgroundImage, width: "100%", position: "relative", display: "flex", justifyContent: "center", alignItems: "center" }}>
                                                                                                                                    <div style={{ width: "100%" }} id={`textField-${key}-${curElem?.positionType}-${j}`} dangerouslySetInnerHTML={{ __html: subElem?.textValue }} />
                                                                                                                                    {/* <ReactQuill
                                                                                                                        id={`textField-${key}-${curElem.positionType}-${j}`}
                                                                                                                        style={{ width: '100%', color: "black", zIndex: "5" }}
                                                                                                                        theme='bubble'
                                                                                                                        // defaultValue={"Enter Text"}
                                                                                                                        value={subElem.textValue}
                                                                                                                        onChange={e => {
                                                                                                                            const dupText = [...colWise]
                                                                                                                            dupText[key].elements[i].element[j].textValue = e
                                                                                                                            setcolWise(dupText)
                                                                                                                        }}
                                                                                                                        modules={{
                                                                                                                            toolbar: [
                                                                                                                                [{ header: [1, 2, 3, 4, false] }],
                                                                                                                                ['bold', 'italic', 'underline'],
                                                                                                                                [{ size: [] }],
                                                                                                                                ['align', 'strike'],
                                                                                                                                [{ color: [] }],
                                                                                                                                [{ list: 'ordered' }, { list: 'bullet' }]
                                                                                                                            ]
                                                                                                                        }}
                                                                                                                        formats={[
                                                                                                                            'header',
                                                                                                                            'bold',
                                                                                                                            'italic',
                                                                                                                            'underline',
                                                                                                                            'size',
                                                                                                                            'align',
                                                                                                                            'strike',
                                                                                                                            'blockquote',
                                                                                                                            'color',
                                                                                                                            'list',
                                                                                                                            'bullet'
                                                                                                                        ]} /> */}
                                                                                                                                    {/* <SunEditor
                                                                                                                        setOptions={SunEditorConfig}
                                                                                                                        id={`textField-${key}-${curElem.positionType}-${j}`}
                                                                                                                        value={subElem.textValue || ''}
                                                                                                                        onChange={(content) => {
                                                                                                                            const dupText = [...colWise]
                                                                                                                            dupText[key].elements[i].element[j].textValue = content
                                                                                                                            setcolWise(dupText)
                                                                                                                        }}
                                                                                                                    /> */}
                                                                                                                                </div>
                                                                                                                            )
                                                                                                                        case 'image':
                                                                                                                            // const imageSelector = document.getElementById("hidden-image-input")
                                                                                                                            if (subElem.src !== "") {
                                                                                                                                return (
                                                                                                                                    <div id={`button-${key}-${curElem?.positionType}-${j}`} draggable style={{ width: "100%", ...subElem?.style, backgroundImage: subElem?.style?.backgroundImage, overflow: "hidden", position: "relative", display: "flex", justifyContent: "center", alignItems: "center" }}>
                                                                                                                                        <img
                                                                                                                                            className="img-fluid"
                                                                                                                                            src={subElem.src}
                                                                                                                                            alt={`Selected Image ${i}`}
                                                                                                                                            style={{ width: "100%" }}
                                                                                                                                        />
                                                                                                                                    </div>
                                                                                                                                )
                                                                                                                            } else {
                                                                                                                                setCurrPosition({ ...currPosition, j })
                                                                                                                                // imageSelector.click()
                                                                                                                                triggerImage()
                                                                                                                                const dupArray = [...colWise]
                                                                                                                                dupArray[key].elements[i].element[j].type = ""
                                                                                                                                setcolWise([...dupArray])
                                                                                                                            }
                                                                                                                        case 'button':
                                                                                                                            return (
                                                                                                                                <div id={`button-${key}-${curElem?.positionType}-${j}`} draggable style={{ width: "100%", display: "flex", justifyContent: subElem?.style?.alignType, position: "relative", display: "flex", alignItems: "center" }}>
                                                                                                                                    <div style={{ ...subElem?.style, backgroundImage: subElem?.style?.backgroundImage, height: Number(subElem?.style?.height) === 0 ? "auto" : `${subElem?.style?.height}px`, display: "inline-flex", justifyContent: "center", alignItems: "center" }} >
                                                                                                                                        <span onDragStart={e => e.stopPropagation()} id={`textField-${key}-${curElem?.positionType}-${j}`}>
                                                                                                                                            {/* <ReactQuill
                                                                                                                        id={`textField-${key}-${curElem.positionType}-${j}`}
                                                                                                                        style={{ width: '100%', color: "black", zIndex: "5" }}
                                                                                                                        theme='bubble'
                                                                                                                        // defaultValue={"Enter Text"}
                                                                                                                        value={subElem.textValue}
                                                                                                                        onChange={e => {
                                                                                                                            const dupText = [...colWise]
                                                                                                                            dupText[key].elements[i].element[j].textValue = e
                                                                                                                            setcolWise(dupText)
                                                                                                                        }}
                                                                                                                        modules={{
                                                                                                                            toolbar: [
                                                                                                                                [{ header: [1, 2, 3, 4, false] }],
                                                                                                                                ['bold', 'italic', 'underline'],
                                                                                                                                [{ size: [] }],
                                                                                                                                ['align', 'strike'],
                                                                                                                                [{ color: [] }],
                                                                                                                                [{ list: 'ordered' }, { list: 'bullet' }]
                                                                                                                            ]
                                                                                                                        }}
                                                                                                                        formats={[
                                                                                                                            'header',
                                                                                                                            'bold',
                                                                                                                            'italic',
                                                                                                                            'underline',
                                                                                                                            'size',
                                                                                                                            'align',
                                                                                                                            'strike',
                                                                                                                            'blockquote',
                                                                                                                            'color',
                                                                                                                            'list',
                                                                                                                            'bullet'
                                                                                                                        ]} /> */}
                                                                                                                                            {/* <SunEditor
                                                                                                                            setOptions={SunEditorConfig}
                                                                                                                            
                                                                                                                            value={subElem.textValue || ''}
                                                                                                                            onChange={(content) => {
                                                                                                                                const dupText = [...colWise]
                                                                                                                                dupText[key].elements[i].element[j].textValue = content
                                                                                                                                setcolWise(dupText)
                                                                                                                            }}
                                                                                                                        /> */}
                                                                                                                                            <div dangerouslySetInnerHTML={{ __html: subElem?.textValue }} />
                                                                                                                                        </span>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                            )
                                                                                                                        case 'input':
                                                                                                                            return (
                                                                                                                                <div id={`button-${key}-${curElem.positionType}-${j}`} draggable style={{ width: "100%", display: "flex", justifyContent: subElem?.style?.alignType, position: "relative", display: "flex", justifyContent: "center", alignItems: "center" }}>
                                                                                                                                    <div style={{ width: subElem?.style?.width }}>
                                                                                                                                        {subElem?.hasLabel && (<label>{subElem?.labelText}</label>)}
                                                                                                                                        <input placeholder={subElem?.placeholder} type="text" style={{ ...subElem?.style, backgroundImage: subElem?.style?.backgroundImage, width: "100%" }} />
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                            )
                                                                                                                        case 'offer':
                                                                                                                            return (

                                                                                                                                <div className='p-1' style={{ ...values }}>
                                                                                                                                    {gotOffers ? finalObj?.selectedOffers?.map((ele) => {
                                                                                                                                        return (
                                                                                                                                            <div className='p-0 mx-0 mt-1 mb-2'>
                                                                                                                                                <div style={{
                                                                                                                                                    flexDirection: 'column',
                                                                                                                                                    justifyContent: 'center',
                                                                                                                                                    alignItems: 'center',
                                                                                                                                                    position: "relative"
                                                                                                                                                }}>
                                                                                                                                                    <div style={{
                                                                                                                                                        width: '100%',
                                                                                                                                                        minHeight: '100%',
                                                                                                                                                        justifyContent: 'center',
                                                                                                                                                        // boxShadow: 'rgba(0, 0, 0, 0.125) 10px 2px 5px',
                                                                                                                                                        filter: 'drop-shadow(rgba(0, 0, 0, 0.2) 0px 0px 10px',
                                                                                                                                                        borderRadius: '10px',
                                                                                                                                                        display: 'flex',
                                                                                                                                                        position: "relative",
                                                                                                                                                        backgroundColor: 'white'
                                                                                                                                                    }}>
                                                                                                                                                        <div className='flex-grow-1 d-flex flex-column justify-content-between' style={{ padding: '15px' }}>
                                                                                                                                                            <div style={{ text: 'wrap' }}>
                                                                                                                                                                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'start', justifyContent: 'start', textTransform: 'uppercase' }}>
                                                                                                                                                                    <h2 style={{ fontWeight: 'bolder', fontSize: '0.9rem', color: '#FF671C' }}>
                                                                                                                                                                        {ele?.Code}
                                                                                                                                                                    </h2>
                                                                                                                                                                    <span style={{ textTransform: 'lowercase', fontSize: '0.75rem', color: 'black' }}>
                                                                                                                                                                        {ele?.Summary}
                                                                                                                                                                    </span>
                                                                                                                                                                </div>
                                                                                                                                                            </div>
                                                                                                                                                            <div>
                                                                                                                                                                <div style={{ paddingTop: '0.5rem' }}>
                                                                                                                                                                    <span style={{ color: 'black', textTransform: 'uppercase', fontWeight: '500', fontSize: '0.65rem' }}>
                                                                                                                                                                        valid until: {ele?.ValidityPeriod?.end ? moment(ele?.ValidityPeriod?.end).format('L') : "Never ending"}
                                                                                                                                                                    </span>
                                                                                                                                                                </div>
                                                                                                                                                            </div>
                                                                                                                                                        </div>
                                                                                                                                                        <div style={{ display: 'flex', flexDirection: 'column', gap: "0.5rem", padding: "0px 15px 15px" }}>
                                                                                                                                                            <div style={{
                                                                                                                                                                position: 'relative',
                                                                                                                                                                display: 'flex',
                                                                                                                                                                flexDirection: 'column',
                                                                                                                                                                justifyContent: 'space-between',
                                                                                                                                                                alignItems: 'center',
                                                                                                                                                                backgroundColor: '#FF671C',
                                                                                                                                                                // filter: `hue-rotate(${i * (i + 20)}deg)`,
                                                                                                                                                                padding: "1rem 0.25rem",
                                                                                                                                                                borderRadius: "0px 0px 5px 5px"
                                                                                                                                                            }}>
                                                                                                                                                                <h1 style={{
                                                                                                                                                                    fontSize: '1.829rem',
                                                                                                                                                                    fontWeight: '750',
                                                                                                                                                                    fontFamily: 'Montserrat',
                                                                                                                                                                    color: 'white'
                                                                                                                                                                }}>
                                                                                                                                                                    {
                                                                                                                                                                        ele?.Type === "PERCENTAGE" ? (
                                                                                                                                                                            `${Number(ele?.Value)?.toFixed(0)}%`
                                                                                                                                                                        ) : `₹${Number(ele?.Value)?.toFixed(0)}`
                                                                                                                                                                    }
                                                                                                                                                                </h1>
                                                                                                                                                            </div>
                                                                                                                                                            <div style={{
                                                                                                                                                                display: 'flex',
                                                                                                                                                                flexDirection: 'column',
                                                                                                                                                                justifyContent: 'flex-end',
                                                                                                                                                                alignItems: 'center'
                                                                                                                                                            }}>
                                                                                                                                                                <button type="button" style={{
                                                                                                                                                                    color: '#FF671C',
                                                                                                                                                                    // filter: `hue-rotate(${i * (i + 20)}deg)`,
                                                                                                                                                                    fontSize: '0.65rem',
                                                                                                                                                                    fontWeight: '700',
                                                                                                                                                                    cursor: 'pointer',
                                                                                                                                                                    border: '0.75px solid #FF671C',
                                                                                                                                                                    borderRadius: '15px',
                                                                                                                                                                    padding: '0.195rem',
                                                                                                                                                                    backgroundColor: 'transparent',
                                                                                                                                                                    textTransform: 'uppercase',
                                                                                                                                                                    cursor: 'pointer'
                                                                                                                                                                }}>
                                                                                                                                                                    <span >
                                                                                                                                                                        Redeem
                                                                                                                                                                    </span>
                                                                                                                                                                </button>
                                                                                                                                                            </div>
                                                                                                                                                        </div>
                                                                                                                                                    </div>
                                                                                                                                                    <div style={{
                                                                                                                                                        width: 'auto',
                                                                                                                                                        // margin: '-0.5rem auto',
                                                                                                                                                        position: 'absolute',
                                                                                                                                                        bottom: "0px",
                                                                                                                                                        backgroundColor: 'white',
                                                                                                                                                        textAlign: 'center',
                                                                                                                                                        padding: '0.25rem 0.5rem',
                                                                                                                                                        borderRadius: '10px',
                                                                                                                                                        boxShadow: '0 4px 24px 0 rgba(34, 41, 47, 0.15)',
                                                                                                                                                        transform: "translate(-50%, 50%)",
                                                                                                                                                        left: "50%"
                                                                                                                                                    }}>
                                                                                                                                                        <span style={{ textTransform: 'lowercase', fontSize: '0.75rem', color: 'black', fontWeight: '300', whiteSpace: "nowrap" }}>
                                                                                                                                                            Used xyz times
                                                                                                                                                        </span>
                                                                                                                                                    </div>
                                                                                                                                                </div>
                                                                                                                                            </div>
                                                                                                                                        )
                                                                                                                                    }) : (
                                                                                                                                        <div className="d-flex justify-content-center align-items-center" style={{ inset: "0px", backgroundColor: "rgba(255,255,255,0.5)" }}>
                                                                                                                                            <Spinner />
                                                                                                                                        </div>
                                                                                                                                    )}
                                                                                                                                </div>
                                                                                                                            )
                                                                                                                    }
                                                                                                                })}
                                                                                                            </div>
                                                                                                        )
                                                                                                    })
                                                                                                }
                                                                                            </div>
                                                                                        </div>
                                                                                    })
                                                                                }
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="d-flex justify-content-center align-items-center form-check form-switch form-check-dark p-0" style={{ gap: "0.0125rem" }}>
                                                                    <p onClick={() => {
                                                                        if (finalObj?.teaserEnabled) {
                                                                            setCurrPage("button")
                                                                            setSideNav(sideNav === "display" ? "display" : "button")
                                                                            setcolWise([...finalObj?.button])
                                                                            setPopPosition(finalObj?.positions?.button)
                                                                            setCurrPosition({ ...currPosition, selectedType: "navMenuStyles" })
                                                                        }
                                                                    }} className={`form-check-label m-0 fw-bold ${currPage === "button" ? "text-white" : "dark"} ${finalObj?.teaserEnabled ? "" : "opacity-50"}`} style={{ fontSize: "12px", padding: "0.5rem" }}>Button</p> <input checked={finalObj?.teaserEnabled} onChange={e => {
                                                                        if (!e.target.checked && currPage === "button") {
                                                                            setCurrPage(finalObj?.[`${mobileCondition}pages`][0]?.id)
                                                                            setcolWise(finalObj?.[`${mobileCondition}pages`][0]?.values)
                                                                            setPopPosition(finalObj?.positions?.[`${mobileCondition}main`])
                                                                            setCurrPosition({ ...currPosition, selectedType: "navMenuStyles" })
                                                                        }
                                                                        setFinalObj({ ...finalObj, teaserEnabled: e.target.checked })
                                                                    }} style={{ width: "30px", height: "15px" }} type="checkbox" className="form-check-input m-0 cursor-pointer" />
                                                                </div>
                                                            </div>
                                                        </SwiperSlide>
                                                        <SwiperSlide>
                                                            <div onClick={() => {
                                                                setFinalObj({ ...finalObj, [`${mobileCondition}pages`]: [...finalObj?.[`${mobileCondition}pages`], { pageName: `Page${finalObj[`${mobileCondition}pages`]?.length + 1}`, id: `Page${finalObj[`${mobileCondition}pages`]?.length + 1}`, values: [] }] })
                                                                setCurrPage(`Page${finalObj[`${mobileCondition}pages`]?.length + 1}`)
                                                                setCurrPosition({ ...currPosition, selectedType: "navMenuStyles" })
                                                            }} className="cursor-pointer pt-1">
                                                                <div className="m-auto bg-light-secondary d-flex justify-content-center align-items-center rounded overflow-hidden" style={{ width: '150px', height: openPage ? "84px" : "0px", transition: "0.3s ease-in-out" }}>
                                                                    <PlusCircle size={25} color='#000' />
                                                                </div>
                                                                <p className='text-center m-0' style={{ fontSize: "12px", padding: "0.5rem" }}>Add Page</p>
                                                            </div>
                                                        </SwiperSlide>
                                                    </Swiper>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* Theme Preview */}
                    {/* Edit Section */}
                    <div className="edit-section h-100" style={{ width: currPosition?.selectedType !== "" ? "300px" : "0px", overflow: "auto", transition: "0.3s ease-in-out" }}>
                        {currPosition?.selectedType !== "" && renderElems()}
                    </div>
                    {/* Edit Section */}
                </div>
                {/* Preview and Edit Section */}

                {/*Modals */}
                <Modal onClick={() => setBgModal0(!bgModal0)} toggle={() => setBgModal0(!bgModal0)} className='hide-backdrop' isOpen={bgModal0} style={{ width: "300px", maxWidth: "90%", margin: "0px" }}>
                    <BgModifier closeState={bgModal0} setCloseState={setBgModal0} styles={values} setStyles={setValues} />
                </Modal>
                <Modal onClick={() => setBgModal(!bgModal)} toggle={() => setBgModal(!bgModal)} className='hide-backdrop' isOpen={bgModal} style={{ width: "300px", maxWidth: "90%", margin: "0px" }}>
                    <BgModifier closeState={bgModal} setCloseState={setBgModal} styles={bgsettings} setStyles={setBgSettings} />
                </Modal>
                <Modal onClick={() => setBgModal2(!bgModal2)} toggle={() => setBgModal2(!bgModal2)} className='hide-backdrop' isOpen={bgModal2} style={{ width: "300px", maxWidth: "90%", margin: "0px" }}>
                    <BgModifier closeState={bgModal2} setCloseState={setBgModal2} styles={bgStyles} setStyles={setBgStyles} />
                </Modal>
                <Modal onClick={() => setBgModal3(!bgModal3)} toggle={() => setBgModal3(!bgModal3)} className='hide-backdrop' isOpen={bgModal3} style={{ width: "300px", maxWidth: "90%", margin: "0px" }}>
                    <BgModifier closeState={bgModal3} setCloseState={setBgModal3} styles={btnStyles} setStyles={setBtnStyles} />
                </Modal>
                <Modal onClick={() => setBgModal4(!bgModal4)} toggle={() => setBgModal4(!bgModal4)} className='hide-backdrop' isOpen={bgModal4} style={{ width: "300px", maxWidth: "90%", margin: "0px" }}>
                    <CustomColorModifier styles={offerColors} setStyles={setOfferColors} colorType={currOfferColor} />
                </Modal>
                <Modal onClick={() => setCustomColorModal(!customColorModal)} toggle={() => setCustomColorModal(!customColorModal)} className='hide-backdrop' isOpen={customColorModal} style={{ width: "300px", maxWidth: "90%", margin: "0px" }}>
                    <CustomColorModifier styles={crossStyle} setStyles={setCrossStyle} colorType={colorType} />
                </Modal>
                <Modal onClick={() => setCustomColorModal2(!customColorModal2)} toggle={() => setCustomColorModal2(!customColorModal2)} className='hide-backdrop' isOpen={customColorModal2} style={{ width: "300px", maxWidth: "90%", margin: "0px" }}>
                    <CustomColorModifier styles={defColors} setStyles={setDefColors} colorType={currColor} />
                </Modal>
                <Modal style={{ filter: "drop-shadow(0px 0px 15px rgba(0,0,0,0.75))" }} isOpen={imgModal} toggle={() => setImgModal(!imgModal)} size='xl'>
                    <div className="w-100 p-1 d-flex justify-content-between align-items-center">
                        <h3 className='m-0'>Select Image</h3> <span className='cursor-pointer' onClick={() => setImgModal(!imgModal)}><X /></span>
                    </div>
                    <ModalBody className='position-relative' style={{ height: "75vh", overflowY: "scroll" }}>

                        {imgLoading && <div className="position-fixed d-flex justify-content-center align-items-center" style={{ inset: "0px", backgroundColor: "rgba(255,255,255,0.5)" }}>
                            <Spinner />
                        </div>}
                        <div className="p-1 pt-0 d-flex justify-content-center border-bottom">
                            <label htmlFor='uploadImg' className="btn btn-dark">Upload an Image <input onChange={e => {
                                setImgLoading(true)
                                const form_data = new FormData()
                                form_data.append("shop", outletData[0]?.web_url)
                                form_data.append("app", "superleadz")
                                form_data.append("images", e.target.files[0])
                                const imgUrl = new URL(`${SuperLeadzBaseURL}/api/v1/bucket_images/`)
                                axios({
                                    method: "POST",
                                    url: imgUrl,
                                    data: form_data
                                })
                                    .then((data) => {
                                        if (data.status === 200) {
                                            triggerImage()
                                            toast.success("Image uploaded successfully!")
                                        } else {
                                            setImgLoading(false)
                                            toast.error("The image could not be uploaded. Try again later.")
                                        }
                                    })

                            }} type="file" className="d-none" id='uploadImg' accept='image/*' /></label>
                        </div>
                        <div className="p-1 row">
                            {allImages.length >= 0 ? allImages.map((ele, key) => {
                                return (
                                    <div key={key} className="col-2 img-array-item" style={{ padding: "0.5rem" }}>
                                        <div style={{ aspectRatio: "1", backgroundImage: `url(${ele?.image})`, backgroundSize: "contain", boxShadow: "0px 5px 7.5px rgba(0,0,0,0.25)", backgroundRepeat: "no-repeat", backgroundPosition: "center" }} className="w-100 h-100 rounded-3 border overflow-hidden">
                                            <div className="revealSection w-100 h-100 d-flex flex-column gap-1 justify-content-between align-items-center p-2" style={{ backgroundColor: "rgba(0,0,0,0.5)" }}>
                                                <div className="p-1 bg-white text-black rounded-3 w-100">{ele?.image?.split("/")?.at("-1")}</div>
                                                <button className="btn btn-dark w-100" onClick={() => {
                                                    const arr = [...colWise]
                                                    if (arr[indexes.cur].elements[colWise[indexes.cur].elements.findIndex($ => $?.positionType === indexes.curElem)].element[indexes.subElem].type) {
                                                        arr[indexes.cur].elements[colWise[indexes.cur].elements.findIndex($ => $?.positionType === indexes.curElem)].element[indexes.subElem].type = "image"
                                                    }
                                                    if (arr[indexes.cur].elements[colWise[indexes.cur].elements.findIndex($ => $?.positionType === indexes.curElem)].element[indexes.subElem].src) {
                                                        arr[indexes.cur].elements[colWise[indexes.cur].elements.findIndex($ => $?.positionType === indexes.curElem)].element[indexes.subElem].src = ele.image
                                                    }
                                                    const newFinalObj = finalObj
                                                    currPage === "button" ? newFinalObj[`${mobileCondition}button`] = arr : newFinalObj[`${mobileCondition}pages`][finalObj[`${mobileCondition}pages`].findIndex($ => $?.id === currPage)].values = arr
                                                    setFinalObj(newFinalObj)
                                                    setcolWise(currPage === "button" ? newFinalObj?.[`${mobileCondition}button`] : newFinalObj?.[`${mobileCondition}pages`]?.[finalObj?.[`${mobileCondition}pages`]?.findIndex($ => $?.id === currPage)]?.values)
                                                    setImgModal(!imgModal)
                                                }}>Use Image</button>
                                                <Trash2 className='cursor-pointer' fill='#fff' stroke='#000' strokeWidth={"1px"} size={35} onClick={() => {
                                                    setImgLoading(true)
                                                    const form_data = new FormData()
                                                    form_data.append("shop", outletData[0]?.web_url)
                                                    form_data.append("app", "superleadz")
                                                    const imgUrl = new URL(`${SuperLeadzBaseURL}/api/v1/delete_bucket_image/?shop=${outletData[0]?.web_url}&app=superleadz&image_id=${ele.id}`)
                                                    axios({
                                                        method: "DELETE",
                                                        url: imgUrl,
                                                        data: form_data
                                                    })
                                                        .then((data) => {
                                                            if (data.status === 200) {
                                                                triggerImage()
                                                            }
                                                        })
                                                }} color='white' />
                                            </div>
                                        </div>
                                    </div>
                                )
                            }) : (
                                <div className="d-flex justify-content-center align-items-center">
                                    <span>No images to show. Try uploading more images</span>
                                </div>
                            )}
                        </div>
                    </ModalBody>
                    {/* <div className="p-1 d-flex justify-content-end align-items-center gap-1">
                        <button className="btn" onClick={e => {
                        }}>Cancel</button>
                    </div> */}
                </Modal>
                <Modal toggle={() => setCancelCust(!cancelCust)} isOpen={cancelCust} size='md'>
                    <Card className='m-0'>
                        <h5 className="d-flex justify-content-between align-items-center p-1">
                            Confirm cancellation of the process <X onClick={() => setCancelCust(!cancelCust)} size={15} className='cursor-pointer' />
                        </h5>
                        <p className='px-1'>Do you want to cancel? All of your progress will be deleted</p>
                        <div className="p-1 d-flex justify-content-end align-items-center gap-1">
                            <button onClick={() => setCancelCust(!cancelCust)} className="btn btn-outline-dark">No</button><button onClick={() => {
                                cancelAction()
                                navigate("/merchant/SuperLeadz/all_campaigns/")
                            }} className="btn btn-dark">Yes</button>
                        </div>
                    </Card>
                </Modal>
                <Modal toggle={() => setOffersModal(!offersModal)} isOpen={offersModal} size='lg'>
                    <ModalBody className='m-0'>
                        <h5 className="d-flex justify-content-between align-items-center p-1">
                            Select Offer Design <X onClick={() => setOffersModal(!offersModal)} size={15} className='cursor-pointer' />
                        </h5>

                        <Container>
                            <Row className="match-height">
                                {defaultOfferStyles?.map((ele, key) => {
                                    return (
                                        <Col key={key} md={6}>
                                            <div onClick={() => {
                                                setOfferTheme(ele?.id)
                                                setOffersModal(!offersModal)
                                            }} className={`p-2 h-100 d-flex justify-content-center align-items-center rounded cursor-pointer`} style={{ outline: `${Number(offerTheme) === Number(ele.id) ? "1px" : "0px"} solid black` }}>
                                                <div className="flex-grow-1" dangerouslySetInnerHTML={{ __html: ele?.html }} />
                                            </div>
                                        </Col>
                                    )
                                })}
                            </Row>
                        </Container>
                    </ModalBody>
                </Modal>
                {/*Modals */}
            </div >

            {!isNaN(indexes?.curElem) && !isNaN(indexes?.subElem) && <div id="quillPrev" style={{ ...colWise[indexes?.cur]?.elements[colWise[indexes?.cur]?.elements?.findIndex($ => $?.positionType === indexes.curElem)]?.element[indexes.subElem]?.style, zIndex: "999999", position: "fixed", display: !isNaN(indexes?.curElem) && !isNaN(indexes?.subElem) && currPosition?.selectedType === "text" ? "block" : "none" }}>
                <SunEditor
                    setOptions={SunEditorConfig}
                    defaultValue={colWise[indexes?.cur]?.elements[colWise[indexes?.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)]?.element[indexes?.subElem]?.textValue}
                />
                <div className="edit_here mt-3">
                    <Editor 
                        onChange={(content) => {
                            const dupText = [...colWise]
                            dupText[indexes.cur].elements[colWise[indexes.cur].elements.findIndex($ => $?.positionType === indexes.curElem)].element[indexes.subElem].textValue = content
                            setcolWise(dupText)
                        }}
                        htmlContent={colWise[indexes?.cur]?.elements[colWise[indexes?.cur]?.elements?.findIndex($ => $?.positionType === indexes?.curElem)]?.element[indexes?.subElem]?.textValue}
                    />

                </div>
            </div>}
        </div>
    )
}
export default CustomizationParent