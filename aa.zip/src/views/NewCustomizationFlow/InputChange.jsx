import React, { useEffect, useState } from 'react'
import { Link2 } from 'react-feather'

const InputChange = ({ allValues, setAllValues, type, hideLabel }) => {
  const [linked, setLinked] = useState(false)
  const [lastValue, setLastValue] = useState("")

  console.log(allValues)

  const handleInputChange = (event) => {

    // const numberRegex = /^-?\d+\.?\d*$/
    setLastValue(`${event.target.value}px`)
    if (linked) {
      setAllValues({ ...allValues, [`${type}Top`]: `${event.target.value}px`, [`${type}Left`]: `${event.target.value}px`, [`${type}Bottom`]: `${event.target.value}px`, [`${type}Right`]: `${event.target.value}px` })
    } else {
      setAllValues({ ...allValues, [`${type}${event.target.name}`]: `${event.target.value}px` })
    }
  }

  useEffect(() => {
    if (linked) {
      setAllValues({ ...allValues, [`${type}Top`]: lastValue, [`${type}Left`]: lastValue, [`${type}Bottom`]: lastValue, [`${type}Right`]: lastValue })
    }
  }, [linked])

  return (
    <div>
      <div className='my-1'>
        {!hideLabel && <label className='text-capitalize' style={{ marginBottom: '0.3rem' }}>{type}</label>}
        <div style={{ aspectRatio: '1', gridTemplateColumns: '1fr 1fr 1fr', display: 'grid' }}>
          <div></div>
          <div className="text-center">
            <input
              type="number"
              name={"Top"}
              min="0"
              step="1"
              placeholder="0"
              className="form-control w-100"
              
              onChange={(e) => {
                if (!isNaN(Number(e.target.value))) {
                  handleInputChange(e)
                }
              }}
              value={allValues[`${type}Top`] ? allValues[`${type}Top`].split("px")[0] : "0px"}
            />
            <label className='m-0 p-0' style={{ fontSize: '0.8125rem' }}>Top</label>
          </div>
          <div></div>
          <div className="text-center">
            <input
              type="number"
              name={"Left"}
              min="0"
              step="1"
              placeholder="0"
              className="form-control"
              value={allValues[`${type}Left`] ? allValues[`${type}Left`].split("px")[0] : "0px"}
              onChange={(e) => {
                if (!isNaN(Number(e.target.value))) {
                  handleInputChange(e)
                }
              }}
            />
            <label style={{ fontSize: '0.8125rem' }}>Left</label>
          </div>
          <div onClick={() => setLinked(!linked)} className="d-flex justify-content-center align-items-center">
            <Link2 size={18} strokeWidth={2.5} style={{ transform: 'rotate(-45deg)', color: linked ? '#7367f0' : '' }} />
          </div>
          <div className="text-center">
            <input
              type="number"
              name={"Right"}
              min="0"
              step="1"
              placeholder="0"
              className="form-control"
              value={allValues[`${type}Right`] ? allValues[`${type}Right`].split("px")[0] : "0px"}
              onChange={(e) => {
                if (!isNaN(Number(e.target.value))) {
                  handleInputChange(e)
                }
              }}
            />
            <label style={{ fontSize: '0.8125rem' }}>Right</label>
          </div>
          <div></div>
          <div className="text-center">
            <input
              type="number"
              name={"Bottom"}
              min="0"
              step="1"
              placeholder="0"
              className="form-control"
              value={allValues[`${type}Bottom`] ? allValues[`${type}Bottom`].split("px")[0] : "0px"}
              onChange={(e) => {
                if (!isNaN(Number(e.target.value))) {
                  handleInputChange(e)
                }
              }}
            />
            <label style={{ fontSize: '0.8125rem' }}>Bottom</label>
          </div>
          <div></div>
        </div>
      </div>
    </div>
  )
}

export default InputChange