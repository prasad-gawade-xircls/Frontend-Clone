import React from 'react'

const OfferSelection = () => {
  return (
    <div>OfferSelection</div>
  )
}

export default OfferSelection