import React from 'react'

const OfferBehaviour = () => {
  return (
    <div>OfferBehaviour</div>
  )
}

export default OfferBehaviour