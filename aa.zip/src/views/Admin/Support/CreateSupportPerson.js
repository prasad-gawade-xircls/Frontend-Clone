import React from 'react'
import { Card, CardBody, Row } from 'reactstrap'

const CreateSupportPerson = () => {
  return (
    <>
        <Row>
            <Card>
                <CardBody>
                    
                </CardBody>
            </Card>
        </Row>
    </>
  )
}

export default CreateSupportPerson