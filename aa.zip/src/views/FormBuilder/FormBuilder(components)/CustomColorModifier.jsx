import React from 'react'
import { SketchPicker } from 'react-color'
import { Card, CardBody } from 'reactstrap'

const CustomColorModifier = ({ styles, setStyles, colorType }) => {
    // console.log({styles, colorType})
    const getBgColor = (colorIsThe) => {
        if (colorIsThe) {
            if (colorIsThe.includes("rgb")) {
                const arr = colorIsThe.split("rgba")[1].slice(1, -1).split(",")
                return { r: arr[0], g: arr[1], b: arr[2], a: arr[3] }
            } else if (colorIsThe.includes("hsl")) {
                const arr = colorIsThe.split("hsl")[1].slice(1, -1).split(",")
                return { h: arr[0], s: arr[1], l: arr[2] }
            } else {
                return colorIsThe
            } 
        }
    }

    return (
        <div className="position-relative" style={{ maxWidth: "100%", zIndex: "999999999999999999999999999999999999999999999999999" }} onClick={e => e.stopPropagation()}>
            <style>{`
                .active-on::before {
                    content: "";
                    position: absolute;
                    inset: 0px;
                    z-index: -1;
                    border-bottom: 5px solid #7367f0;
                }
                .sketch-picker {
                    width: auto !important;
                    padding: 0px !important;
                    box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px 0px, rgba(0, 0, 0, 0) 0px 0px 0px !important;
                }
            `}</style>
            <div className="position-relative d-flex justify-content-center align-items-center">
                <div className="position-absolute w-100 h-100" style={{ zIndex: "-1", scale: "0.8", filter: "blur(40px)", ...styles, backgroundImage: styles?.backgroundImage }}></div>
                <Card className='m-0'>
                    <CardBody className='p-0'>
                        <div style={{ padding: "0.75rem" }}>

                            <SketchPicker color={getBgColor(styles[colorType])} onChange={(e) => {
                                const { r, g, b, a } = e.rgb
                                setStyles({...styles, [colorType]: `rgba(${r},${g},${b},${a})`})
                            }} />
                        </div>
                    </CardBody>
                </Card>
            </div>
        </div>
    )
}

export default CustomColorModifier