const templates = [
    {
        id: 1,
        formName: 'Sed ut',
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
        creationDate: '18 Jan 2022',
        coverImage: 'https://source.unsplash.com/random/?nature'    
    },    
    {
        id: 2,
        formName: 'Perspiciatis unde',
        description: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
        creationDate: '18 Jan 2022',
        coverImage: 'https://source.unsplash.com/random/?water'    
    },    
    {
        id: 3,
        formName: 'Omnis iste',
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
        creationDate: '18 Jan 2022',
        coverImage: 'https://source.unsplash.com/random/?sky'    
    },    
    {
        id: 4,
        formName: 'Natus error',
        description: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
        creationDate: '18 Jan 2022',
        coverImage: 'https://source.unsplash.com/random/?mountain'    
    },    
    { 
        id: 5,
        formName: 'Sit voluptatem',
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
        creationDate: '18 Jan 2022',
        coverImage: 'https://source.unsplash.com/random/?flower'    
    },    
    {
        id: 6,
        formName: 'Accusantium dolo',
        description: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
        creationDate: '18 Jan 2022',
        coverImage: 'https://source.unsplash.com/random/?sun'    
    },    
    {
        id: 7,
        formName: 'Totam rem',
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
        creationDate: '18 Jan 2022',
        coverImage: 'https://source.unsplash.com/random/?moon'    
    },    
    {
        id: 8,
        formName: 'Eaque ipsa',
        description: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
        creationDate: '18 Jan 2022',
        coverImage: 'https://source.unsplash.com/random/?cloud'    
    },    
    {
        id: 9,
        formName: 'Ab illo',
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
        creationDate: '18 Jan 2022',
        coverImage: 'https://source.unsplash.com/random/?rain'    
    },    
    {
        id: 10,
        formName: 'Inventore verita',
        description: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
        creationDate: '18 Jan 2022',
        coverImage: 'https://source.unsplash.com/random/?forest'    
    }
  ]

  export { templates }