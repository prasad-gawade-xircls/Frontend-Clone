

const Footer = () => {
  return (
    <></>
  )
}

export default Footer
