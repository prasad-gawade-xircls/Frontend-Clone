import { createContext } from "react"

export const NavTitleContext = createContext({})

export const ThemesProvider = createContext({})

export const PermissionProvider = createContext({})

export const PopupProvider = createContext({})

export const WrapperContext = createContext({})